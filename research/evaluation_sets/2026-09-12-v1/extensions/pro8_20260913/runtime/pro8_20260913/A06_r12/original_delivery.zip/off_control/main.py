"""r12 mechanism-OFF ablation, not a different production r6 binary."""
from pathlib import Path
import importlib.util,json
ROOT=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('_r12_off_codec',ROOT/'policy/agent.py')
codec=importlib.util.module_from_spec(s);s.loader.exec_module(codec)
cfg=json.loads((ROOT/'policy/config.json').read_text());cfg['a06_r12_calendar']=0
instances={}
def agent(observation,configuration=None):
    seat=int(codec._get(observation,'player',0))
    if seat not in instances:instances[seat]=codec.Agent(cfg,ROOT/'policy/a06.so')
    return instances[seat](observation,configuration)
def reset():
    for a in instances.values():a.close()
    instances.clear()
