"""Verify the shipped payload; does not load agents or run matches."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
m=json.loads((root/'MANIFEST.json').read_text())
errors=[]
for rel,expected in m['files'].items():
 p=root/rel
 if not p.is_file():errors.append({'path':rel,'reason':'missing'})
 elif hashlib.sha256(p.read_bytes()).hexdigest()!=expected:errors.append({'path':rel,'reason':'SHA256 mismatch'})
print(json.dumps({'verified':len(m['files'])-len(errors),'errors':errors},ensure_ascii=False,indent=2))
sys.exit(bool(errors))
