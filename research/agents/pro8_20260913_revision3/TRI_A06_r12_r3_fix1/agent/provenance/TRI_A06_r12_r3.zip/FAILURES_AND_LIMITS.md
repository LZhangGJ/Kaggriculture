# Failures, rejected hypotheses and remaining risks

1. A raw fertilizer gap is not sufficient evidence to buy. Internalv1 admitted
   unnecessary purchases that parent collection/recovery could cover. Internalv2
   added a fallback-current-day screen, but supplied runs could still fail to
   attain extra service when too late. Finalv3 requires a feasible positive
   maintenance-profile superset. All variants, commands and unfavorable cash
   outputs remain under `research/` and `logs/`; none replaces root production.
2. One early research-only day20 activation fork was used to inspect a parent
   state after naturalv1 divergence. It is NOT the final root nor a natural
   candidate prefix; its raw scope labels say so. The manual fork's inherited
   build receipt was stale and is retained only as
   `inherited_parent_receipt_NOT_FOR_DAYFORK.json`. Actual manual compile command
   is `logs/dayfork_compile_command.json`. No result from this fork is presented
   as finalv3 natural behavior or a new match.
3. First official replay audit failed a cash-flow assertion: the bounded logger
   hooked ordinary atomic market trades and HIRE, but not the separate BUY_LAND
   function. Four R2narrow final raw trajectories omitted4000 land spending each.
   Actual engine endpoint cash was correct throughout. The corrected audit
   replays actual filled land purchases with before/after money and land masks;
   it does not insert a guessed residual or count requested orders as fills.
   Original raw files are unchanged. See `new_runs_replay_audit_failed_v1.*`,
   `research/audit_new_runs_failed_v1.py`,
   `research/bounded_execution_unlogged_land.py` and reconciled cash ledgers.
4. Interactive exec allocation was unavailable; the exact tool failure is in
   `logs/tool_failures.txt`. One early long bounded batch's transport call timed
   out, while the subprocess finished its recorded18 trajectories. Its outer
   GNU-time log is empty; no peakRSS is invented for that missing receipt.
   Later batches are explicitly split and independently timed. Small exploratory
   output queries also encountered KeyError/TypeError on incorrectly assumed
   diagnostic shapes; these were analysis-query errors, not agent runtime wins,
   tests or valid results. No corresponding phantom test pass is claimed.
5. Two true-game seeds, both seats, produced2wins/2losses against the exact parent;
   one margin worsened by2, three were unchanged. The package therefore does NOT
   claim measured competitive improvement. The two historical narrow wins have
   changed prefixes and lack true-counterpart terminal validation. The moon
   conditional cash losses remain negative; remaining stock is not revenue.
6. Copied current-day admission uses a declared idle counterpart. It cannot
   predict an actual opponent's private resources, new decisions, contested
   purchases or random future. It is an execution guard, not an oracle. Economic
   selection is inherited and may itself be wrong; rejected service and all
   public losses are not solved. Future portfolio opportunity cost and sales
   interaction remain risks. Configuration/cash constraints and investment
   capability are preserved, not proof of correct global valuation.
7. No final central parent1536 report arrived in this turn;917-row progress is
   partial, not a final win rate. The candidate has not run the central12-opponent
   acceptance panel. Required≥1306/1536 strictwins remains unmet/unverified.
