# Provisional calendar R12 evidence for the next author round

These two completed losses were selected within the first 16 seeds of the frozen round-three panel. They are development examples, not a random sample or complete acceptance results. Analysis adds zero games. The complete panel continues; this author round may begin once PROGRESS.json proves mathematical failure.

The parent is `TRI_A06_r12_r2`, native SHA-256 `638626de9398f0aed45e98394742ee22df875dd805f2647dee6d5666eb1c7755`. For each case, Codex reconciled all 719 official transitions and both players' 30 cash ledgers. Own crop re-execution matched all recorded crop states. Only this agent's observations, actions and ledger are in this directory; joint audits remain local.

| Case | Own final cash | Margin | Physical stock discarded | Strawberry produced / harvested / sold | Tomato produced / harvested / sold |
|---|---:|---:|---:|---:|---:|
| market_smart_v8_568422814_seat0 | 82,218 | -9,718 | 3 units | 180 / 180 / 178 | 111 / 111 / 111 |
| submission_56149565_1827852203_seat0 | 95,229 | -965 | 0 units | 269 / 269 / 269 | 274 / 274 / 274 |

Both cases have zero ongoing-crop drought deaths, no standing crop yield destroyed by digging, and no crop capacity loss. Every produced strawberry and tomato was harvested. The first case discarded two strawberries and one fertilizer at step 575: automatic deposit received 103 units into an empty 100-unit shed. The R2 case had no physical stock loss anywhere in the game.

The prior survival-wage fix is not contradicted by these cases. A new task focused only on preventing drought deaths or warehouse loss would leave the observed competitive weakness largely unexplained.

## Economic and calendar questions supported by these cases

Against market_smart, actual revenue included carrot 27,710 from 373 units, strawberry 17,485 from 178, milk 15,257 from 180, and egg 14,888 from 356. Wheat purchases cost 12,318, wages 5,762 and land 3,000. There were 9 strawberry, 2 wool and 27 fertilizer units sold at the price floor. Use the full daily ledger to investigate marginal product choice, forecast market absorption, servicing cost, and time of sale. These totals do not isolate the value of any one decision.

Against R2, 269 strawberries realized 43,259, 274 tomatoes 20,954, 165 milk 9,535 and 155 eggs 6,461. Wheat cost 8,970, wages 6,387 and land 7,000. There were 12 wool and 4 melon units sold at the floor. The narrow defeat has no physical stock loss, so an economic or scheduling improvement is needed to change its result.

Recorded production ticks also show a maintenance question worth evaluating. The public loss had 16 strawberry and one tomato production ticks without a bonus; fertilizer was expired or absent on every one, and five of those ticks were also unwatered. The R2 loss had 25 strawberry and 12 tomato ticks without a bonus, all watered but with expired or absent fertilizer. These counts describe observations, not automatically avoidable loss. Investigate whether a maintenance action was deliberately uneconomic, missing from the calendar, removed during admission, unfunded, or not executed. Charge fertilizer, labor, transport and market impact before deciding to add maintenance.

Codex additionally replayed all 1,438 actions through the exact frozen native and read its existing `td_contract_json` route telemetry after each action. Every returned action matched the recorded parent. On each affected production day, none of the 54 missing-bonus crop instances appeared in a remaining FERTILIZE route. This narrows the investigation toward service choice, preparation and admission before route execution. The read-only export does not expose every intermediate decision, so it does not establish which upstream stage removed the task. Source investigation targets are `set_service()` in `policy/triad.hpp`, the day<15 fertilizer-purchase condition in `policy/executor/policy.hpp`, and its resource-shortage fallback in `reserve()`. Current recovery can still buy fertilizer after day15, so the preparation cutoff must not be described as a universal purchasing ban. In the R2 loss, day20 started with35,909 cash,13 fertilizer in the shed and strawberry price219 versus fertilizer40, yet five watered strawberries missed their bonus; actual day-wide allocation, marginal future price and routing cost still need to be checked before changing policy.

## Evaluate competitive margin

Public same-seed, same-seat outcomes show why own cash alone is insufficient. In the market_smart case, A08 finished with only 69,674 own cash but won by 4,338 because its opponent finished at 65,336; this R12 finished with 82,218 but faced 91,936. In the R2 case, A06 r6 finished with 86,640 and won by 3,168 against 83,472; R12 finished with 95,229 but faced 96,194. These are different complete trajectories, not controlled ablations. They support investigating market interaction and competitive effects rather than maximizing own final cash alone.

Preserve the already verified survival-wage behavior and regression cases. Choose a structural improvement supported by the complete panel and these own-visible traces, and report what was actually validated. Do not add seed-specific rules. Codex will test the revised strategy against all 12 fixed opponents, both seats, on fresh shared seeds. Acceptance is strict overall wins above 85%; no competitive cash threshold applies.
