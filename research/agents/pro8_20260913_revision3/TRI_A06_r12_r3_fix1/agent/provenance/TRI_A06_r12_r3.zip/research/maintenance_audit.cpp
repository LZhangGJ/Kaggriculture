// Read-only research export; not called by the root production entry.
#include "../parent/policy/bridge.cpp"
extern "C" const char* td_maintenance_audit(void*p,const double*input,size_t count){
 auto&h=*static_cast<Handle*>(p);try{
 Cursor r{input,count};int step=r.integer(),day=r.integer(),hour=r.integer(),seat=r.integer();
 auto a=r.farm(),b=r.farm();auto priv=r.priv();fastkag::Market market;
 for(auto&x:market.inventory)x=r.integer();for(auto&x:market.prices)x=r.integer();std::vector<int8_t> shops;
 int n=r.count();for(int i=0;i<n;i++)shops.push_back(r.integer());if(r.i!=count)throw std::runtime_error("trailing");
 dp7::View v{step,day,hour,seat==0?a:b,seat==0?b:a,priv,market,shops};
 const auto&c=h.policy.live;auto core=c.core;auto js=core.jobs(v);auto rs=core.reserve(v,js);
 std::ostringstream j;j.precision(17);j<<"{\"step\":"<<step<<",\"cash\":"<<v.own.money<<",\"phase\":"<<core.phase<<",\"crop_service_day\":"<<core.crop_service_day<<",\"shed_f\":"<<priv.shed[dp7::F]<<",\"daily_need_f\":"<<core.daily_need[dp7::F]<<",\"degraded\":"<<core.resource_degraded<<",\"rows\":[";
 bool comma=false;for(int pos=0;pos<100;pos++){
 const auto&t=v.own.tiles[pos];if(!dp7::plant(t)||!dp7::ongoing(int(t.crop)))continue;
 int k=int(t.crop);competitive::OngoingMaintenanceDP md;md.kind=k;md.birth=t.planted_day;md.mode=2;md.work=c.s.work_price;
 for(int d=0;d<30;d++){md.price[d]=c.prices[d][k];md.fert[d]=c.prices[d][dp7::F];}
 int f=std::clamp(int(t.fertilized_until_day)-day+1,0,3);int dry=std::min(1,int(t.consecutive_unwatered));
 auto choice=md.first(day,dry,f,core.water_due(t),core.fertilize_due(t));
 if(comma)j<<",";comma=true;
 j<<"{\"pos\":"<<pos<<",\"kind\":"<<k<<",\"birth\":"<<t.planted_day<<",\"fert_until\":"<<t.fertilized_until_day<<",\"watered\":"<<t.watered_today<<",\"dry\":"<<dry<<",\"next_production\":"<<md.production(day+1)<<",\"service_water\":"<<int(core.crop_water[pos])<<",\"service_fert\":"<<int(core.crop_fertilize[pos])<<",\"path_fert\":"<<c.paths[pos].f[day][dp7::F]<<",\"path_next_yield\":"<<(day<29?c.paths[pos].f[day+1][k]:0)<<",\"today_f_price\":"<<c.prices[day][dp7::F]<<",\"next_crop_price\":"<<(day<29?c.prices[day+1][k]:0)<<",\"q10\":"<<md.q(day,dry,f,true,false)<<",\"q11\":"<<md.q(day,dry,f,true,true);
 auto ops=[&](const char*name,const auto& jobs){j<<",\""<<name<<"\":[";bool sep=false;for(const auto&x:jobs)if(x.pos==pos)for(auto act:x.actions){if(sep)j<<",";sep=true;j<<int(act.op);}j<<"]";};ops("jobs",js);ops("reserved",rs);j<<"}";
 }
 j<<"],\"selected\":"<<h.policy.last_search<<"}";h.text=j.str();return h.text.c_str();
 }catch(const std::exception&e){h.text=std::string("ERROR: ")+e.what();return h.text.c_str();}
}
