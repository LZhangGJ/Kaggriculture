"""Reconcile recorded new runs with a fresh unmodified official interpreter.
Replays add no matches and do not expose another player's private state to policy.
"""
from pathlib import Path
import json,gzip,sys,copy,time,resource
import bounded_execution as b
w=b.w;results=[];t=time.perf_counter();schemas=0
try:
 import jsonschema
 schema=b.LocalGame(1).engine.specification['action'];validator=jsonschema.Draft7Validator(schema)
except ImportError:validator=None
for path in sorted((w/'logs/parent_duels').glob('*.jsonl.gz')):
 if 'probe' in path.name:continue
 with gzip.open(path,'rt') as f:
  head=json.loads(next(f));g=b.LocalGame(head['seed']);n=0
  for line in f:
   row=json.loads(line)
   if row['type']=='transition':
    assert row['step']==g.t
    for s in (0,1):
     assert g.observation(s)==row['own_observations'][s],(path.name,g.t,s,'prestate')
     if validator:validator.validate(row['actions'][s]);schemas+=1
    g.advance(row['actions']);n+=1
   elif row['type']=='final':
    assert g.t==row['steps']==719 and g.done and row['done'] and not row['errors']
    for s in (0,1):assert g.observation(s)==row['observations'][s]
  assert n==719
 data=json.loads(path.with_suffix('').with_suffix('.json').read_text())
 for s in (0,1):
  rr=[x for x in data['day_cash'] if x['seat']==s];assert len(rr)==30
  assert sum(x['delta'] for x in rr)==data['money'][s]-3000
 results.append({'path':str(path.relative_to(w)),'official_transitions':n,'player_days':60,'state_exact':True})
 print(path.name,n,flush=True)
for path in sorted((w/'logs/bounded_v3').glob('*.json.gz')):
 data=json.loads(gzip.decompress(path.read_bytes()));rr=data['result'];seat=data['initial_own_observation']['player']
 g=b.fork(data['initial_own_observation'],data['configuration'],rr['synthetic_seed'],rr['scenario']);n=0
 for row in data['actions']:
  assert g.observation(seat)==row['own_observation'],(path.name,g.t,'bounded prestate')
  actions=[None,None];actions[seat]=row['own_action'];actions[1-seat]=row['synthetic_rival_action']
  if validator:
   for a in actions:validator.validate(a);schemas+=1
  g.advance(actions);n+=1
  assert g.observation(seat)['farms'][seat]['money']==row['own_cash_after']
  assert g.observation(seat)['farms'][1-seat]['money']==row['rival_cash_after']
 assert g.observation(seat)==data['final_own_observation'] and n==rr['steps']
 assert sum(rr['flow'].values())==rr['own_cash_end']-rr['own_cash_start'],(path.name,'cash ledger')
 results.append({'path':str(path.relative_to(w)),'official_transitions':n,'state_exact':True})
 print(path.name,n,flush=True)
report={'scope':'Fresh-engine replay audit, zero added games','full_duel_replays':6,'bounded_replays':20,'official_transitions':sum(x['official_transitions'] for x in results),'full_game_player_days':360,'action_schemas_checked':schemas,'schema_library':'jsonschema Draft7' if validator else None,'seconds':time.perf_counter()-t,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'results':results}
(w/'logs/new_runs_replay_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='results'}))
