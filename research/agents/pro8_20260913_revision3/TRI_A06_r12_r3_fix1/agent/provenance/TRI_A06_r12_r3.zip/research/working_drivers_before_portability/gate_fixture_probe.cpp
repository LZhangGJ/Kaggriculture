#include "../candidate/policy/triad.hpp"
#include <iostream>
using namespace dp7;
int main(){
 for(int hour:{0,17,18,19,20,21,22,23}){
 Farm own,rival;own.tiles.resize(100);rival.tiles.resize(100);own.unlocked_mask=15;own.farmer={4,4};own.money=1000;
 PrivateState priv;priv.inventories.resize(1);priv.inventory_order.resize(1);Market market;market.inventory.fill(10000);for(int k=0;k<9;k++)market.prices[k]=price(k,10000);std::vector<int8_t>shops;
 auto&t=own.tiles[34];t.kind=TileKind::PLANT;t.crop=Item::STRAWBERRY;t.planted_day=7;t.fertilized_until_day=18;t.consecutive_unwatered=1;
 View v{480+hour,20,hour,own,rival,priv,market,shops};triad::Settings s;s.max_hands=0;s.max_land=4;s.intraday=0;s.a06_r11_recovery=0;s.delay_sale=-1;
 triad::Controller c(s);c.core.day=20;c.core.crop_service_day=20;c.core.target={{34,S}};c.core.crop_birth[34]=7;c.core.crop_kind[34]=S;c.core.crop_water[34]=c.core.crop_fertilize[34]=1;
 c.prepare_with_ongoing_supply(v,v,0);int n=0;for(auto a:c.core.queue)if(a.op==Op::BUY_PRODUCT&&int(a.item)==F)n+=a.quantity;
 std::cout<<"{\"hour\":"<<hour<<",\"buys\":"<<n<<",\"previews\":"<<c.ongoing_supply_previews<<",\"skips\":"<<c.ongoing_supply_skips<<",\"errors\":"<<c.ongoing_supply_preview_errors<<"}\n";
 }
}
