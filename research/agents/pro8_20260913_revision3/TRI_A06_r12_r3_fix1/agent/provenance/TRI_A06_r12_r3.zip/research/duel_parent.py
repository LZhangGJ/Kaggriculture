"""Small official full-game engineering check versus the immutable own parent.
Not any of the twelve central opponents. Not a representative/holdout estimate.
The frozen candidate and fixed two-seed paired schedule are never tuned here.
"""
from pathlib import Path
import sys,copy,json,gzip,time,hashlib,resource,importlib.util
from datetime import datetime,timezone
w=Path(__file__).resolve().parents[1];sys.path.insert(0,str(w/'feedback/referee'))
from cpu_runtime import LocalGame
candidate=w/'candidate' if (w/'candidate/main.py').is_file() else w
FROZEN='7d7fd9540328b4d87df7b9970c03d63837831713efd781b86359a33de76836f5'
seed=int(sys.argv[1]);seat=int(sys.argv[2]);limit=int(sys.argv[3]) if len(sys.argv)>3 else 719
assert seed in (2026091391,2026091392) and seat in (-1,0,1)
assert hashlib.sha256((candidate/'policy/a06.so').read_bytes()).hexdigest()==FROZEN
label=f'{seed}_'+('parent_control' if seat<0 else f'candidate_seat{seat}')+('' if limit==719 else f'_probe{limit}')
d=w/'logs/parent_duels';d.mkdir(parents=True,exist_ok=True);t=time.perf_counter()
roots=[]
for player in (0,1):
 path=candidate/'main.py' if player==seat else w/'parent/main.py'
 spec=importlib.util.spec_from_file_location(f'duel_{label}_{player}',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);roots.append(m)
g=LocalGame(seed);day_start=[g.observation(s)['farms'][s]['money'] for s in (0,1)];ledger=[];calls=[[],[]];action_hash=hashlib.sha256();errors=[]
raw=gzip.open(d/f'{label}.jsonl.gz','wt');raw.write(json.dumps({'type':'identity','seed':seed,'candidate_seat':seat,'limit':limit,'native':FROZEN,'configuration':dict(g.configuration),'scope':'Official closed-loop own-parent duel; each root receives only its own lawful observation. Both policies are this lineage, not the twelve-opponent pool.'})+'\n')
try:
 while not g.done and g.t<limit:
  obs=[g.observation(s) for s in (0,1)];actions=[]
  for s in (0,1):
   begin=time.perf_counter();a=roots[s].agent(copy.deepcopy(obs[s]),copy.deepcopy(g.configuration));calls[s].append(time.perf_counter()-begin)
   assert isinstance(a,dict) and len(a['hands'])==len(obs[s]['farms'][s]['hands']) and len(a['market'])<=10
   actions.append(a)
  action_hash.update(json.dumps(actions,sort_keys=True,separators=(',',':')).encode()+b'\n')
  raw.write(json.dumps({'type':'transition','step':g.t,'own_observations':obs,'actions':actions},separators=(',',':'))+'\n');g.advance(actions)
  for s in (0,1):
   o=g.observation(s);assert o['farms'][s]['money']>=0 and sum(o['private']['shed'].values())<=100
   assert all(n>=0 for n in o['private']['shed'].values())
  if g.t%24==0 or g.done:
   for s in (0,1):
    cash=g.observation(s)['farms'][s]['money'];ledger.append({'day':(g.t-1)//24,'seat':s,'start':day_start[s],'end':cash,'delta':cash-day_start[s],'end_step':g.t});day_start[s]=cash
   (d/f'{label}.checkpoint.json').write_text(json.dumps({'step':g.t,'seconds':time.perf_counter()-t,'day_cash':ledger[-2:]}))
except Exception as e:
 errors.append(repr(e));raise
finally:
 final=[g.observation(s) for s in (0,1)];money=[final[s]['farms'][s]['money'] for s in (0,1)]
 raw.write(json.dumps({'type':'final','steps':g.t,'done':g.done,'observations':final,'errors':errors},separators=(',',':'))+'\n');raw.close()
 debug=[r._seats.get(s).debug() if s in r._seats else None for s,r in enumerate(roots)]
 for r in roots:r.reset()
 result={'seed':seed,'candidate_seat':seat,'scope':'Own-parent engineering mini-panel, not central twelve-opponent acceptance','native':FROZEN,'steps':g.t,'complete':g.done and g.t==719,'money':money,'margin':money[seat]-money[1-seat] if seat>=0 else None,'strict_win':bool(money[seat]>money[1-seat]) if seat>=0 else None,'draw':money[0]==money[1],'errors':errors,'day_cash':ledger,'action_sha256':action_hash.hexdigest(),'seconds':time.perf_counter()-t,'max_call_seconds':[max(c,default=0) for c in calls],'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'debug':debug,'completed_at_utc':datetime.now(timezone.utc).isoformat()}
 (d/f'{label}.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ('debug','day_cash')}),flush=True)
