from pathlib import Path
import sys,json,time,resource
import bounded_execution as b
w=b.w;mode=sys.argv[1];idx=int(sys.argv[2]);results=[];t=time.perf_counter()
cases=json.loads((w/'logs/prefix_summary_v1.json').read_text())
if mode=='extended':
 r=cases[idx];case=r['case'];start=r['first_divergence'];intervention=False;group='bounded_extended';ticks=72;seed=2026091300+idx;scenarios=('observed_market_idle_rival','supply_input_pressure')
elif mode=='day20':
 case='submission_56149565_1827852203_seat0';start=480;intervention=True;group='bounded_day20';ticks=72;seed=2026091320+idx;scenarios=(('observed_market_idle_rival','supply_input_pressure','expensive_fertilizer','no_finance')[idx],)
else:raise ValueError(mode)
for scenario in scenarios:
 for variant in ('parent','candidate'):
  results.append(b.run(case,variant,scenario,start,seed,ticks=ticks,output_group=group,intervention=intervention))
  (w/'logs'/f'{group}_{idx}.json').write_text(json.dumps(results,indent=2))
(w/'logs'/f'{group}_{idx}.resource.json').write_text(json.dumps({'seconds':time.perf_counter()-t,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'completed':len(results),'synthetic_seed':seed},indent=2))
