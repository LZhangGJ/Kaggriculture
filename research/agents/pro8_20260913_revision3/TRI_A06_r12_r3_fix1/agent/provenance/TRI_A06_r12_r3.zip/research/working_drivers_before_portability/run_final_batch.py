"""Small official conditional scenarios; never full matches or acceptance results."""
import sys,json,time,resource,hashlib
import bounded_execution as b
w=b.w;i=int(sys.argv[1]);version=sys.argv[2] if len(sys.argv)>2 else 'v2';t=time.perf_counter();results=[]
cases=['market_smart_v8_568422814_seat0','moon_v215_31485687_seat0','submission_56149565_1827852203_seat0','submission_56149565_805057947_seat0']
if i<4:
 case=cases[i];start=[480,384,480,384][i];ticks=72;seed=2026091340+i;scenarios=('observed_market_idle_rival','supply_input_pressure')
else:
 case=cases[2];start=480;ticks=48;seed=2026091340+i;scenarios=(('no_finance','expensive_fertilizer')[i-4],)
for scenario in scenarios:
 for variant in ('parent','candidate'):
  results.append(b.run(case,variant,scenario,start,seed,ticks=ticks,output_group='bounded_'+version,intervention=False))
  (w/'logs'/f'bounded_{version}_{i}.json').write_text(json.dumps(results,indent=2))
(w/'logs'/f'bounded_{version}_{i}.resource.json').write_text(json.dumps({'seconds':time.perf_counter()-t,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'completed':len(results),'synthetic_seed':seed,'candidate_native_sha256':hashlib.sha256((w/'candidate/policy/a06.so').read_bytes()).hexdigest()},indent=2))
