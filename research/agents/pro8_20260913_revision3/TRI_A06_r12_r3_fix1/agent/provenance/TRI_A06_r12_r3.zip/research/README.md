# Research is never the submission entry

Root `../main.py` uses only root `../policy/`. `v1_candidate/`, `v2_candidate/`,
and `dayfork_agent/` are retained development variants with separate raw results;
they are not deployable aliases of the final build. `r3_final_disabled.so` is
only a compile-time ablation. No external rival source is included or used.

`maintenance_audit.cpp` includes the immutable parent bridge and adds read-only
source diagnostics. Its added export is not loaded by the production entry.
`audit_traces.py` validates all4×719 parent actions while recording selection and
reservation. `check_prefixes.py v3 N` stops the final candidate at first mismatch.
`bounded_execution.py` uses fresh official observations after a conditional fork;
`run_final_batch.py N v3` selects the documented20-run final suite in six batches.
`duel_parent.py` is the fixed own-parent mini-panel, not a recreated central pool.
`audit_new_runs.py` validates existing new-game/bounded recordings and adds no games.

Run research only in a disposable copy: these programs write to `../logs`.
Portable release scripts accept a root production layout as well as the original
`candidate/` working layout. Working driver bytes before packaging are retained under
`working_drivers_before_portability/`; path-only changes do not alter policy or previously recorded
results. The original bounded logger's missing land hook and failed first replay
are preserved as named historical files. Corrected future logging records actual
land fills. Historicalv1/v2 commands and outputs are retained verbatim; their
assumptions must not be silently applied to finalv3 results. Manual dayfork's
inherited receipt is labelled NOT_FOR_DAYFORK; the actual manual compile command
and raw native are retained for that research-only intervention.
