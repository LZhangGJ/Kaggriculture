from pathlib import Path
import json,subprocess,hashlib,time
w=Path(__file__).resolve().parents[1];r=w/'candidate' if (w/'candidate/main.py').is_file() else w;flags=json.loads((r/'COMPILER_FLAGS.json').read_text());out=w/'research/r3_final_disabled.so';cmd=['g++',*flags,'-DTRI_A06_R12_R3_FERT_SUPPLY=0',str(r/'policy/bridge.cpp'),str(r/'policy/executor/vendor/simulator.cpp'),'-o',str(out)]
t=time.perf_counter();x=subprocess.run(cmd,capture_output=True,text=True,timeout=130)
(w/'logs/final_disabled_compile.stdout').write_text(x.stdout);(w/'logs/final_disabled_compile.stderr').write_text(x.stderr)
receipt={'command':cmd,'returncode':x.returncode,'seconds':time.perf_counter()-t,'compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0]}
if x.returncode==0:receipt['sha256']=hashlib.sha256(out.read_bytes()).hexdigest()
(w/'logs/final_disabled_compile.json').write_text(json.dumps(receipt,indent=2));print(receipt)
raise SystemExit(x.returncode)
