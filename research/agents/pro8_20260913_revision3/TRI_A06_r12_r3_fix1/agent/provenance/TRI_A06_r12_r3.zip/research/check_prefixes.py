from pathlib import Path
import importlib.util,json,gzip,copy,time,hashlib,resource,sys
version=sys.argv[1] if len(sys.argv)>1 else "final"
index=int(sys.argv[2]) if len(sys.argv)>2 else None
w=Path(__file__).resolve().parents[1]
def load(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
p=load(w/'parent/main.py','parent_root');c=load((w/'candidate' if (w/'candidate/main.py').is_file() else w)/'main.py','candidate_root');summary=[]
for i,path in enumerate(sorted((w/'feedback/own_traces').glob('*.gz'))):
 if index is not None and i!=index:continue
 tr=json.loads(gzip.decompress(path.read_bytes()));p.reset();c.reset();rows=[];first=None;t=time.perf_counter();pcalls=0
 for step,obs in enumerate(tr['observations'][:719]):
  pa=p.agent(copy.deepcopy(obs),tr['configuration']);pcalls+=1
  assert pa==tr['own_actions'][step],(path.name,step,'parent')
  if first is None:
   ca=c.agent(copy.deepcopy(obs),tr['configuration']);same=ca==pa
   rows.append({'step':step,'same':same,'parent':pa,'candidate':ca})
   if not same:first=step
 p.reset();c.reset();r={'case':tr['game_id'],'first_divergence':first,'matched_candidate_prefix':first if first is not None else 719,'candidate_calls':len(rows),'parent_exact':pcalls,'seconds':time.perf_counter()-t,'new_games':0,'scope':'Root entry saved observations. Candidate stops at FIRST divergence; no historical suffix passed thereafter.'}
 out=w/'logs'/('prefix_'+version+'_'+tr['game_id']+'.json.gz');out.write_bytes(gzip.compress(json.dumps({'summary':r,'rows':rows}).encode()));summary.append(r);print(r,flush=True)
(w/('logs/prefix_summary_'+version+('_'+str(index) if index is not None else '')+'.json')).write_text(json.dumps(summary,indent=2))
