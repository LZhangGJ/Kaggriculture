from pathlib import Path
import sys,importlib.util,ctypes,gzip,json,time,copy,resource,hashlib
w=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('audit_root',w/'parent/main.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
summary=[]
for path in sorted((w/'feedback/own_traces').glob('*.gz')):
 trace=json.loads(gzip.decompress(path.read_bytes()));a=m.create_agent(w/'research/maintenance_audit.so');lib=a.lib
 lib.td_maintenance_audit.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_double),ctypes.c_size_t];lib.td_maintenance_audit.restype=ctypes.c_char_p
 t=time.perf_counter();exact=0;rows=[]
 for step,obs in enumerate(trace['observations'][:719]):
  action=a(copy.deepcopy(obs),trace['configuration'])
  if action!=trace['own_actions'][step]:raise AssertionError((path.name,step,action,trace['own_actions'][step]))
  exact+=1
  if step%24<=2:
   data=m.codec._pack(obs);data=lib.td_maintenance_audit(a.handle,data,len(data)).decode()
   if data.startswith('ERROR'):raise AssertionError(data)
   rows.append(json.loads(data))
 a.close();out=w/'logs'/('audit_'+path.name.replace('.json.gz','.json'))
 out.write_text(json.dumps({'case':trace.get('id',path.name),'scope':'Parent read-only diagnostic, root actions verified exactly. No changed-policy future used.','new_games':0,'exact':exact,'seconds':time.perf_counter()-t,'rows':rows},indent=2))
 summary.append({'case':path.name,'exact':exact,'seconds':time.perf_counter()-t,'out':str(out.relative_to(w))});print(summary[-1],flush=True)
(w/'logs/audit_traces_summary.json').write_text(json.dumps(summary,indent=2))
