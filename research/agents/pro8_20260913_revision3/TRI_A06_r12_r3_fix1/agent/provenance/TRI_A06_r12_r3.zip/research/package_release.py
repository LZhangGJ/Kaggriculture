"""Stage a source-complete frozen delivery; does not build or alter production."""
from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,shutil,difflib,subprocess,os,re
W=Path(__file__).resolve().parents[1]
S=Path('/mnt/data/TRI_A06_r12_r3_release')
NOW=datetime.now(timezone.utc)
NATIVE='7d7fd9540328b4d87df7b9970c03d63837831713efd781b86359a33de76836f5'
PARENT='638626de9398f0aed45e98394742ee22df875dd805f2647dee6d5666eb1c7755'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def js(p):return json.loads(p.read_text())
def put(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
assert sha(W/'candidate/policy/a06.so')==NATIVE
b=js(W/'candidate/policy/a06.BUILD.json')
for p,h in b['all_build_inputs'].items():assert sha(W/'candidate'/p)==h,p
assert not S.exists(), 'Do not silently replace an existing release stage'
S.mkdir()
for p in (W/'candidate').iterdir():
 if p.is_dir():shutil.copytree(p,S/p.name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 else:shutil.copy2(p,S/p.name)
for name in ('parent','feedback','logs','research'):
 shutil.copytree(W/name,S/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
(S/'provenance').mkdir()
for p in (W/'source_inputs').iterdir():
 if p.is_file():shutil.copy2(p,S/'provenance'/p.name)
shutil.copy2(W/'parent_rebuilt_probe.so',S/'provenance/parent_rebuilt_probe.so')
shutil.copy2(W/'parent_rebuilt_probe.BUILD.json',S/'provenance/parent_rebuilt_probe.BUILD.json')
# Preserve executed driver bytes; portable copies change paths/logging only, not
# production source, opponent behavior, seed schedule, or recorded results.
hist=S/'research/executed_drivers';hist.mkdir()
for name in ('bounded_execution.py','run_final_batch.py','check_prefixes.py','compile_disabled_final.py'):
 p=S/'research'/name;shutil.copy2(p,hist/name);s=p.read_text()
 if name=='bounded_execution.py':
  s=s.replace('"""Official 48-transition conditional forks.', '"""Official bounded 48/72-transition conditional forks.')
  s=s.replace("else w/variant/'main.py'", "else ((w/'candidate' if (w/'candidate/main.py').is_file() else w)/'main.py' if variant=='candidate' else w/variant/'main.py')")
 elif name=='run_final_batch.py':
  s=s.replace("else 'v2'", "else 'v3'")
  s=s.replace("(w/'candidate/policy/a06.so')", "((w/'candidate' if (w/'candidate/main.py').is_file() else w)/'policy/a06.so')")
 elif name=='check_prefixes.py':
  s=s.replace("c=load(w/'candidate/main.py','candidate_root')", "c=load((w/'candidate' if (w/'candidate/main.py').is_file() else w)/'main.py','candidate_root')")
 elif name=='compile_disabled_final.py':
  s=s.replace("r=w/'candidate';", "r=w/'candidate' if (w/'candidate/main.py').is_file() else w;")
 p.write_text(s);compile(s,str(p),'exec')
# Historical manual day-fork binary carried an inherited (not matching) build
# receipt. Preserve it clearly under an archive label, never as active metadata.
day=S/'research/dayfork_agent/policy/a06.BUILD.json'
if day.exists():day.rename(day.with_name('inherited_parent_receipt_NOT_FOR_DAYFORK.json'))
inputs={}
for fn in ('TRI_A06_r12_r2_source_inputs.zip','TRI_A06_r12_r2_own_feedback.zip'):
 p=Path('/mnt/data')/fn;inputs[fn]={'sha256':sha(p),'bytes':p.stat().st_size}
identity={'candidate':'TRI_A06_r12_r3','status':'source-complete engineering candidate, central acceptance NOT established','native_sha256':NATIVE,'parent_candidate':'TRI_A06_r12_r2','parent_native_sha256':PARENT,'parent_original_delivery_zip_sha256':'0bffa7ee3bdcf27c8683b4ae528c92adc587109ac2fb34f4e950d110a0ce3d87','excluded_other_r2_native_sha256':'bd0c7dd9170b2f70781a7e2bd211b367fc625aa66154a99f5855641f08aefd62','excluded_other_r2_zip_sha256':'d94d9480465f2aba3c493441a1f3a82c7c916514d20cb457af64c1aae38d0a03','borrowed_from_excluded_other_r2':False,'source_archives':inputs,'config_sha256':sha(S/'policy/config.json'),'compiler_flags_sha256':sha(S/'COMPILER_FLAGS.json'),'fixed_configuration_unchanged':sha(S/'policy/config.json')==sha(S/'parent/policy/config.json'),'parent_files':51,'production_entry':'main.py:agent','runtime_native':'policy/a06.so','original_dispatch_utc':'2026-09-13T19:00:45Z','hard_deadline_utc':'2026-09-13T21:00:45Z','release_staging_started_utc':NOW.isoformat(),'true_duel_schedule_frozen_utc':js(S/'logs/parent_duel_plan.json')['frozen_at_utc'],'production_changes_after_true_duel_results':False}
put(S/'IDENTITY.json',identity)
prod=dict(b['all_build_inputs']);prod['policy/a06.so']=NATIVE
changed=[];diff=[]
for name,h in prod.items():
 q=S/'parent'/name
 if not q.exists() or sha(q)!=h:
  changed.append({'path':name,'parent_sha256':sha(q) if q.exists() else None,'candidate_sha256':h})
  if name.endswith(('.py','.hpp','.inc','.cpp','.json')):
   diff.extend(difflib.unified_diff(q.read_text().splitlines(True) if q.exists() else [],(S/name).read_text().splitlines(True),fromfile='parent/'+name,tofile=name))
(S/'provenance/production_changes.diff').write_text(''.join(diff))
put(S/'SOURCE_FREEZE.json',{'verified_utc':NOW.isoformat(),'scope':'Only root production inputs/native; research versions are not loaded by main.py','all_build_inputs':b['all_build_inputs'],'native_sha256':NATIVE,'changes_relative_to_exact_parent':changed,'source_inputs_match_compilation':True,'independent_rebuild_byte_identical':True})
put(S/'BUILD.json',{'candidate':'TRI_A06_r12_r3','actual_production_build':b,'independent_rebuild_receipt':'logs/independent_rebuild_receipt.json','flags':js(S/'COMPILER_FLAGS.json'),'production_wall_seconds':27.77,'production_peak_rss_kib':609280,'independent_rebuild_wall_seconds':27.51,'independent_rebuild_peak_rss_kib':609224,'native_file':(S/'logs/native_file.txt').read_text(),'linked_requirements':'logs/native_versions.txt','production_input_count':50})
# Extract compact evidence from actual full parent diagnostics, not estimated
# recovery revenue or saved post-divergence candidate observations.
audit=js(S/'logs/audit_submission_56149565_1827852203_seat0.json');row=next(r for r in audit['rows'] if r['step']==480)
put(S/'provenance/maintenance_evidence.json',{'scope':'Read-only exact-parent source instrumentation','case':audit['case'],'original_source':'logs/audit_submission_56149565_1827852203_seat0.json','day20':{k:v for k,v in row.items() if k!='selected'},'public_loss_note':'The 16 strawberry missing bonuses mostly have service_fert=0; this is not a blanket lost-input bug. See full public source diagnostic.'})
# Collect every actual seed appearing in all retained run metadata, raw heads,
# own evidence and scripts. Different scopes are explicitly separated.
seed_refs={}
def walk(o,ref):
 if isinstance(o,dict):
  for k,v in o.items():
   if k in ('seed','synthetic_seed') and isinstance(v,int):seed_refs.setdefault(v,set()).add(ref)
   elif k=='seeds' and isinstance(v,list):
    for q in v:
     if isinstance(q,int):seed_refs.setdefault(q,set()).add(ref)
   else:walk(v,ref)
 elif isinstance(o,list):
  for v in o:walk(v,ref)
for p in sorted((S/'logs').rglob('*.json')):
 if p.name.startswith(('audit_','disabled_final_equivalence')):continue
 walk(js(p),str(p.relative_to(S)))
for p in (S/'feedback/PARTIAL_ROWS.json',S/'feedback/SELECTED_CASES.json'):walk(js(p),str(p.relative_to(S)))
for p in sorted((S/'logs').rglob('*.json.gz')):
 with gzip.open(p,'rt') as f:d=json.load(f)
 if 'result' in d:walk(d['result'],str(p.relative_to(S)))
for p in (S/'feedback/own_traces').glob('*.json.gz'):
 with gzip.open(p,'rt') as f:d=json.load(f)
 for k,v in d.items():
  if k not in ('observations','own_actions'):walk({k:v},str(p.relative_to(S)))
rows=js(S/'feedback/PARTIAL_ROWS.json')
put(S/'DEVELOPMENT_SEEDS.json',{'scope':'All exposed and used seeds are development/engineering inputs, not sealed holdout. Production receives no match seed and has no seed/opponent table. Script constants belong to test schedules only.','parent_partial_rows_retained':len(rows),'parent_partial_unique_seeds':sorted({r['seed'] for r in rows}),'actual_candidate_full_game_seeds':[2026091391,2026091392],'final_bounded_synthetic_seeds':list(range(2026091340,2026091346)),'all_observed_seed_references':[{'seed':k,'sources':sorted(v)} for k,v in sorted(seed_refs.items())],'additional_internal_scenario_constructor_seed':0,'additional_official_schema_initialization_seed':1})
final=[]
for i in range(6):final.extend(js(S/f'logs/bounded_v3_{i}.json'))
paired=[]
for c in sorted({x['case'] for x in final}):
 for sn in sorted({x['scenario'] for x in final if x['case']==c}):
  pp=next(x for x in final if (x['case'],x['scenario'],x['variant'])==(c,sn,'parent'));cc=next(x for x in final if (x['case'],x['scenario'],x['variant'])==(c,sn,'candidate'))
  paired.append({'case':c,'scenario':sn,'transitions_per_variant':cc['steps'],'candidate_own_cash_minus_parent':cc['own_cash_end']-pp['own_cash_end'],'synthetic_rival_cash_difference':cc['rival_cash_end']-pp['rival_cash_end'],'relative_cash_margin_difference':cc['own_cash_end']-pp['own_cash_end']-cc['rival_cash_end']+pp['rival_cash_end'],'parent_endpoint':pp['own_cash_end'],'candidate_endpoint':cc['own_cash_end'],'scope':'Conditional synthetic counterpart, NOT actual opponent/new win/recovered historical cash'})
val={'status':'NOT central acceptance; engineering validation complete','unit_suites':3,'unit_assertions':21478,'unit_failures':0,'parent_exact_history_actions':2876,'feature_disabled_exact_parent_history_actions':2876,'new_complete_candidate_games':4,'new_complete_parent_controls':2,'candidate_full_game_wins':2,'candidate_full_game_losses':2,'candidate_full_game_draws':0,'new_complete_games_total':6,'full_games_each_steps':719,'true_opponent':'immutable exact own parent only, not fixed 12-opponent pool','full_player_days_reconciled':360,'final_bounded_trajectories':20,'final_bounded_transitions':1344,'official_exact_replay_transitions':5658,'official_action_schema_checks':11316,'replays_add_games':False,'central_1536_candidate_games':0,'central_acceptance_proven':False,'parent_snapshot':js(S/'feedback/PROGRESS.json'),'prefixes':[js(S/f'logs/prefix_summary_v3_{i}.json')[0] for i in range(4)],'bounded_cash_diagnostics':paired,'root_entry_test':js(S/'logs/root_entry_prepackage.json'),'source_frozen_before_true_matches':True,'known_negative':'Moon bounded cash -872/-66; one own-parent full-game margin -2 vs control; protection of both historical narrow wins not established','authoritative_cash_breakdown':'logs/reconciled_ledgers; original bounded_v3 flow maps omitted BUY_LAND in four R2-narrow trajectories and are preserved unchanged'}
put(S/'VALIDATION.json',val)
(S/'README.md').write_text('''# TRI_A06_r12_r3 — approved recurring-crop maintenance supply

**Full engineering candidate, not an accepted >85% agent.** This package actually
builds and runs the A06 calendar-r12 lineage. The only parent is the centrally
tested r2 native `638626de9398f0aed45e98394742ee22df875dd805f2647dee6d5666eb1c7755`.
The other same-named r2 (`bd0c7dd…`) in the conversation was neither substituted
nor borrowed. `parent/` is a byte-identical, read-only copy of all 51 supplied
parent files. `IDENTITY.json` binds both original input archives and the parent.

The submission is **root `main.py:agent`**, loading **`policy/a06.so`**. Nothing
under `parent/`, `research/`, `feedback/`, or `logs/` is loaded by production.
The production configuration and compiler flags are unchanged. Rebuild offline
with `python -B build.py`; build and run the three supplied source-test suites
with `python -B build.py --unit`. See `BUILD.md` for actual commands and ABI.

## One structural change

At R2 case `1827852203`, day20/step480, the exact parent selected 22 fertilizer
requirements with only 13 units in the shed. The preparation path's `day < 15`
purchase condition omitted the nine-unit shortfall. `reserve()` then degraded
selected FERTILIZE+WATER jobs, while watering remained. This is **not** a claim
that all fertilizer purchasing after day15 was prohibited: existing recovery
can still purchase and collect inputs. The source instrumentation reproduces all
2,876 supplied parent actions and exposes selection, raw jobs and reservation.
See `provenance/maintenance_evidence.json` and `logs/audit_*.json`.

R3 supplies only an already-selected, due, incumbent strawberry/tomato service
lost to actual fertilizer reservation, on days15–28. It does not turn every
missing bonus into an obligation or force economically rejected maintenance.
Existing service valuation, wages, item-price limits, cash/stock reservation,
capacity, route assignment, public supply assumptions and calendar DP remain.
The earlier end-season wheat/carrot planting fix and r2 survival wage ordering
remain intact and are explicitly tested.

Before keeping additional procurement, the controller compares copied,
current-day execution of parent preparation and supplied preparation. Existing
collection/recovery that already fulfils all selected maintenance suppresses
the extra purchase. Otherwise, supplied preparation must actually achieve at
least one additional selected FERTILIZE+WATER service, without losing any selected
service the parent preparation achieves. Buying fertilizer alone is insufficient:
pickup, travel, valid use and watering must finish in the remaining day. The
comparison is a **conditional feasibility screen**, not income, a perfect
opponent model or actual future state. It uses an idle synthetic counterpart
and no external private inventory or saved future. Exceptions fail closed to
parent preparation. Live investment and recovery remain enabled.

## What the validation shows

* Three C++ suites: **21,478 assertions**, no failure in the final suites; includes
  18,403 inherited survival-wage checks, positive/negative service procurement,
  exact-route/deadline/cash/price tests and retained late-planting boundaries.
* Exact parent history: **2,876/2,876 actions**. A compile-time disabled final
  mechanism also matches **2,876/2,876**, isolating the source change.
* Candidate saved-history probe stops at the first divergence. The public loss
  matches all719 actions; R2 loss first diverges at480, both narrow wins at384.
  **Neither narrow win has been proven preserved.** No old suffix is treated as
  the candidate's real future.
* Twenty official-engine bounded continuations: **1,344 transitions**, not
  matches. Final successive states are generated by the supplied interpreter.
  Cash is calculated from actual filled transactions, not requested orders or
  valuation of unsold stock. Conditions and losses are in `VALIDATION.md`.
* A frozen two-seed, both-seat **real closed-loop mini-panel against the exact
  own parent**: candidate **2 wins, 2 losses**, plus two parent-v-parent controls.
  All six games finish719 steps, with zero errors/draws and360 player-days.
  Three candidate games have exactly the corresponding control's joint actions;
  the fourth has a margin two cash units worse. **Competitive improvement was
  not demonstrated.** These are not the fixed12 external opponents.
* Fresh official replay audits: all **5,658 transitions** exact, with **11,316
  action-schema checks**. Replaying adds zero matches. Independent rebuilding
  reproduces the delivered native byte-for-byte. Root entry, seat isolation,
  reset, explicit error and matching-build checks are included.

The strongest positive conditional R2 case produces six previously missing
bonuses on its first service day and actually sells five additional strawberries
and one additional tomato within72 transitions. Net cash differs by +1,095 with
an idle synthetic counterpart, or +978 under declared input/output pressure
(relative cash margin +981). These are not an actual R2 rematch, a recovered
historical loss, or evidence of the target win rate. The public-loss negative
control is unchanged. The moon narrow-win condition loses872/66 cash in the two
72-step scenarios despite a changed remaining inventory; unsold stock is not
counted as recovered revenue.

## Limitations and acceptance

The central parent progress file contains an **incomplete** snapshot:917 games,
647 wins,270 nonwins; its best possible final count is1266/1536. It is not a
completed parent win rate. No later full-panel supplement was received here.
All917 rows and every exposed/used development seed are retained. Earlier rounds
use different seeds; historical rate differences are not an ablation.

The candidate has **zero completed games against the central fixed12-opponent
panel**. The actual mini-panel did not show improvement. The preparation screen
is deliberately narrow and does not repair rejected service valuations, forecast
market absorption, all portfolio effects or every public loss. The horizon-local
screen can have downstream investment/sales effects, and both narrow wins remain
at risk. Acceptance still requires the central new shared64-seed,12-opponent,
both-seat panel: **at least1,306 strict wins out of1,536**; draws do not count.
This package is delivered for that independent test, not labelled a success.

## Artifact map and auditability

`BUILD.json`, `SOURCE_FREEZE.json`, and `MANIFEST.json` bind actual commands,
inputs, native and every package file. `provenance/production_changes.diff` is
supplementary; full production files are present. `feedback/` preserves supplied
own-only observations, ledgers, official rules/engine and partial results.
`logs/` retains complete new run records and failures; `research/` includes the
read-only parent diagnostic and explicitly non-production development versions.
`DEVELOPMENT_SEEDS.json` records test scopes and seeds, none used as a production
lookup. `FAILURES_AND_LIMITS.md` describes rejected hypotheses and a corrected
cash-logger omission, with original failure and raw logs retained. The external
delivery receipt records final ZIP hash, extraction check and actual finish time.
''')
(S/'VALIDATION.md').write_text('''# Validation report — scopes must not be merged

## Frozen true games, not the central pool

Source/native were frozen before the predeclared two-seed schedule in
`logs/parent_duel_plan.json`. Production was not changed after these results.
Both agents independently run full strategy through lawful current observations
from the supplied official engine; neither policy receives a seed. The opponent
is the exact **own parent**, not an external market_smart/R2 imitation.

| Seed | Candidate seat | Own cash | Parent cash | Margin | Margin delta vs same-seed parent control |
|---|---:|---:|---:|---:|---:|
|2026091391|0|107821|108390|-569|-2|
|2026091391|1|108389|107822|567|0|
|2026091392|0|127600|132020|-4420|0|
|2026091392|1|132020|127600|4420|0|

Candidate2/4 strict wins, no draws. Two additional parent-v-parent controls make
six complete719-step games, zero errors,360 cash player-days. Last three joint
action streams equal the controls exactly. This tiny engineering result does
**not** demonstrate competitive improvement or estimate the12-opponent win rate.
The96-step speed probe is incomplete and counted as zero games.

## Natural-prefix official bounded continuations

Each root is warmed only through an exact historical prefix. At the first
candidate divergence (or the explicit unchanged public control atstep480), the
missing opponent private state is replaced by a declared synthetic condition.
Thereafter every observation is freshly generated by the official interpreter;
no saved suffix is used. These20 trajectories comprise1,344 transitions, **zero
additional complete matches**. First16 are72 steps; the four negative financial
conditions are48 steps. Future shop/weather/random effects are conditional seeds,
not the actual missing opponent or random tape. Parent and candidate share the
same conditional initial state and synthetic seed.

The idle condition has no rival unit work or inventory. The pressure condition
gives the synthetic rival40 strawberries and40 tomatoes, buys20 fertilizer at
offset0 subject to actual public cash/availability, and offers5 of each crop
every fourth transition through offset36. Unit actions remainPASS. This probes
input/output contention, not actual opponent strategy.

| Historical state used | Start | Idle own cash delta | Pressure own cash delta | Pressure relative margin delta |
|---|---:|---:|---:|---:|
|market_smart568422814 loss|480|0|0|0|
|moon31485687 narrow win|384|-872|-66|-66|
|R2 1827852203 loss|480|1095|978|981|
|R2 805057947 narrow win|384|495|1348|1348|

All deltas are candidate minus parent **within a condition**, not final match
margin or recovered historical cash. R2loss first day: successful fertilizer
service16→22, bonus-producing ticks28→34, crop output62→68. Across72 transitions,
actual strawberry sales97→102 and tomato sales35→36. Nine fertilizer units cost
367 (idle) or403 (pressure); other filled spending/sales and wages are included
in net cash. Those first-day six cases are5 strawberries and1 tomato, not nine
extra crops. Original selected22 versus warehouse13 is a reservation gap, not a
claim that all nine initially degraded tasks would otherwise miss production.

In the moon idle condition candidate ends with12 additional unsold melons and2
strawberries. These do not offset the reported872 cash loss. The price/cost floor
and inability to complete service are tested as reasons not to procure. The
expensive-fertilizer condition makes no new purchase and matches the parent.
A zero-cash/zero-eligible-stock shock preserves real budget constraints, but both
policies suffer25 ongoing-crop deaths; this fix is not a universal survival fix.

Full successful/failed FERTILIZE, WATER, pickup, delivery, production and filled
market events are in `logs/bounded_v3/*.json.gz`. Corrected complete transaction
breakdowns are in `logs/reconciled_ledgers/*.json`. Four original R2narrow raw
flow maps omitted a separate BUY_LAND handler (4000 each); the actual endpoints
were already correct. Fresh replay records real land fills and reconciles them.
Original logs and first audit failure are intentionally retained.

## Source and entry checks

Three final C++ suites pass18,403+3,029+46=21,478 assertions. The tests preserve
survival-wage ordering, late planting, economic rejection, actual stock, cash,
identity, date, transport/travel deadlines, actual end-day fertilizer+water use,
fallback recovery, and a fail-closed optional projection. `build/tests/` contains
actual compiler commands, compiler version, binaries and outputs.

Read-only parent instrumentation matches2,876 saved actions exactly. The final
feature-off compile matches2,876/2,876, without adding games. Final candidate
prefix matches: public719, moon384, R2loss480, R2narrow384. The three first
mismatching actions are recorded and no later saved candidate calls are made.
Two narrow wins have changed behavior, so historical wins are **not protected by
identity** and have no new true-opponent terminal proof.

`tests/verify_entry.py` checks the frozen native, all50 build inputs,384 root
calls on four48-step prefixes and synthetic seat relabeling,8 step-zero resets,
and3 explicit negative error cases. No call is counted as a new match.

Fresh official-engine replay of the six new full games plus20 final bounded
trajectories matches all5,658 transitions and11,316 action schemas. Each full
game's60 player-day cash rows sum to its actual terminal cash delta. Replays
add no games. See `logs/new_runs_replay_audit.json`. A new interpreter run from
final ZIP extraction is recorded in the external delivery receipt.
''')
flags=' '.join(js(S/'COMPILER_FLAGS.json'))
(S/'BUILD.md').write_text(f'''# Build and runtime receipt

Final native SHA256: `{NATIVE}`.
Actual compiler: `{b['compiler']}`. Python3.13.5. Linux x86-64, explicit
`-march=x86-64`, not host-native ISA. No pip install or network is needed for
production rebuild, root inference or the C++ unit suites.

Actual final command (original working directory paths are preserved):

```sh
{' '.join(b['command'])}
```

Equivalent offline commands from the extracted delivery root:

```sh
timeout 150s python -B build.py
# Optional new tests exist and may now be requested:
timeout 180s python -B tests/run_units.py
python -B tests/verify_entry.py --out /tmp/a06_r3_entry.json
```

All flags: `{flags}`.
`policy/a06.BUILD.json` is the actual final receipt, including50 input hashes,
compiler, command, native hash and measured build duration. Root `BUILD.json`
references independent build validation rather than guessing source/native
compatibility. The first frozen-parent probe compiled in30.76s, peak607840KiB,
and matched the parent's binary. Final production compile took27.77s wall,
peak609280KiB; independent directory compile27.51s, peak609224KiB, native bytes
identical. All commands were serial with explicit timeouts. Compile stdout and
stderr, including empty successful stderr, are retained as actual logs.

The distributed binary is dynamically linked. Observed required symbols include
GLIBC2.32 and GLIBCXX3.4.31; see exact ELF/version/ldd records in `logs/native_*`.
An older Linux runtime may require the supplied offline rebuild. GCC13.3 rebuilt
the parent centrally; this round used the actual available GCC14.2.0, not a claimed
central-toolchain build. Cross-compiler byte identity is not promised.

For diagnostics only, the supplied Python official engine uses its vendored
source; optional action-schema auditing uses already-installed `jsonschema`
(Draft7). Production has no `jsonschema` dependency. Re-run research in a copy to
avoid overwriting frozen raw logs. Example final bounded batch (four trajectories,
not full matches): `python -B research/run_final_batch.py 2 v3`. The historical
subversions and manual research fork are explicitly not production binaries.
''')
(S/'FAILURES_AND_LIMITS.md').write_text('''# Failures, rejected hypotheses and remaining risks

1. A raw fertilizer gap is not sufficient evidence to buy. Internalv1 admitted
   unnecessary purchases that parent collection/recovery could cover. Internalv2
   added a fallback-current-day screen, but supplied runs could still fail to
   attain extra service when too late. Finalv3 requires a feasible positive
   maintenance-profile superset. All variants, commands and unfavorable cash
   outputs remain under `research/` and `logs/`; none replaces root production.
2. One early research-only day20 activation fork was used to inspect a parent
   state after naturalv1 divergence. It is NOT the final root nor a natural
   candidate prefix; its raw scope labels say so. The manual fork's inherited
   build receipt was stale and is retained only as
   `inherited_parent_receipt_NOT_FOR_DAYFORK.json`. Actual manual compile command
   is `logs/dayfork_compile_command.json`. No result from this fork is presented
   as finalv3 natural behavior or a new match.
3. First official replay audit failed a cash-flow assertion: the bounded logger
   hooked ordinary atomic market trades and HIRE, but not the separate BUY_LAND
   function. Four R2narrow final raw trajectories omitted4000 land spending each.
   Actual engine endpoint cash was correct throughout. The corrected audit
   replays actual filled land purchases with before/after money and land masks;
   it does not insert a guessed residual or count requested orders as fills.
   Original raw files are unchanged. See `new_runs_replay_audit_failed_v1.*`,
   `research/audit_new_runs_failed_v1.py`,
   `research/bounded_execution_unlogged_land.py` and reconciled cash ledgers.
4. Interactive exec allocation was unavailable; the exact tool failure is in
   `logs/tool_failures.txt`. One early long bounded batch's transport call timed
   out, while the subprocess finished its recorded18 trajectories. Its outer
   GNU-time log is empty; no peakRSS is invented for that missing receipt.
   Later batches are explicitly split and independently timed. Small exploratory
   output queries also encountered KeyError/TypeError on incorrectly assumed
   diagnostic shapes; these were analysis-query errors, not agent runtime wins,
   tests or valid results. No corresponding phantom test pass is claimed.
5. Two true-game seeds, both seats, produced2wins/2losses against the exact parent;
   one margin worsened by2, three were unchanged. The package therefore does NOT
   claim measured competitive improvement. The two historical narrow wins have
   changed prefixes and lack true-counterpart terminal validation. The moon
   conditional cash losses remain negative; remaining stock is not revenue.
6. Copied current-day admission uses a declared idle counterpart. It cannot
   predict an actual opponent's private resources, new decisions, contested
   purchases or random future. It is an execution guard, not an oracle. Economic
   selection is inherited and may itself be wrong; rejected service and all
   public losses are not solved. Future portfolio opportunity cost and sales
   interaction remain risks. Configuration/cash constraints and investment
   capability are preserved, not proof of correct global valuation.
7. No final central parent1536 report arrived in this turn;917-row progress is
   partial, not a final win rate. The candidate has not run the central12-opponent
   acceptance panel. Required≥1306/1536 strictwins remains unmet/unverified.
''')
(S/'research/README.md').write_text('''# Research is never the submission entry

Root `../main.py` uses only root `../policy/`. `v1_candidate/`, `v2_candidate/`,
and `dayfork_agent/` are retained development variants with separate raw results;
they are not deployable aliases of the final build. `r3_final_disabled.so` is
only a compile-time ablation. No external rival source is included or used.

`maintenance_audit.cpp` includes the immutable parent bridge and adds read-only
source diagnostics. Its added export is not loaded by the production entry.
`audit_traces.py` validates all4×719 parent actions while recording selection and
reservation. `check_prefixes.py v3 N` stops the final candidate at first mismatch.
`bounded_execution.py` uses fresh official observations after a conditional fork;
`run_final_batch.py N v3` selects the documented20-run final suite in six batches.
`duel_parent.py` is the fixed own-parent mini-panel, not a recreated central pool.
`audit_new_runs.py` validates existing new-game/bounded recordings and adds no games.

Run research only in a disposable copy: these programs write to `../logs`.
Portable release scripts accept a root production layout as well as the original
`candidate/` working layout. Original driver bytes are retained under
`executed_drivers/`; path-only changes do not alter policy or previously recorded
results. The original bounded logger's missing land hook and failed first replay
are preserved as named historical files. Corrected future logging records actual
land fills. Historicalv1/v2 commands and outputs are retained verbatim; their
assumptions must not be silently applied to finalv3 results. Manual dayfork's
inherited receipt is labelled NOT_FOR_DAYFORK; the actual manual compile command
and raw native are retained for that research-only intervention.
''')
# Snapshot quota and timing after staging, never host-size inference.
resource=subprocess.run(['bash','-lc',"date -u +'%Y-%m-%dT%H:%M:%SZ'; cat /proc/self/status | grep Cpus_allowed_list; cat /sys/fs/cgroup/cpu.max; cat /sys/fs/cgroup/memory.max /sys/fs/cgroup/memory.current; grep MemAvailable /proc/meminfo; df -h /mnt/data; python --version; g++ --version | head -1"],capture_output=True,text=True)
(S/'logs/environment_packaging.txt').write_text(resource.stdout+resource.stderr)
put(S/'RESOURCE_AND_TIME.json',{'dispatch_utc':'2026-09-13T19:00:45Z','deadline_utc':'2026-09-13T21:00:45Z','first_resource_probe_utc':'2026-09-13T19:04:46Z','first_probe_within_five_minutes':True,'cpu_affinity':[0,1,2,3,4],'cgroup_cpu_max':'400000 100000','effective_cpus':4,'memory_limit_bytes':4294967296,'memory_working_ceiling_bytes':3006477107,'initial_memory_current_bytes':313925632,'host_memavailable_not_treated_as_quota':True,'concurrency':'one compiler or memory-heavy experiment at a time','source_final_build_at_utc':b['built_at_utc'],'packaging_started_utc':NOW.isoformat(),'minutes_since_dispatch_at_packaging':(NOW-datetime(2026,9,13,19,0,45,tzinfo=timezone.utc)).total_seconds()/60,'budget_reset':False,'production_compile_wall_seconds':27.77,'production_compile_rss_kib':609280,'independent_rebuild_wall_seconds':27.51,'independent_rebuild_rss_kib':609224,'completion_record':'external delivery receipt after ZIP extraction verification','commands_and_peak_rss_logs':'logs/*.time and *.resource.json'})
# Hash check original inputs despite release folder remapping.
parent_manifest=js(S/'provenance/MANIFEST.json');checked=0
for name,entry in parent_manifest.items():
 p=(S/'parent'/name.removeprefix('agent/')) if name.startswith('agent/') else S/'provenance'/name
 assert sha(p)==entry['sha256'],name;checked+=1
for name,entry in js(S/'feedback/MANIFEST.json').items():assert sha(S/'feedback'/name)==entry['sha256'],name
for name,h in prod.items():assert sha(S/name)==h,name
put(S/'logs/staging_identity.json',{'source_manifest_checks':checked,'feedback_manifest_checks':len(js(S/'feedback/MANIFEST.json')),'parent_files':51,'production_build_inputs':50,'native_sha256':NATIVE,'all_passed':True,'staged_at_utc':datetime.now(timezone.utc).isoformat()})
print(json.dumps({'stage':str(S),'files':sum(p.is_file() for p in S.rglob('*')),'native':NATIVE,'source_changes':changed,'seed_count':len(seed_refs),'parent_source_manifest':checked,'paired_diagnostics':paired},indent=2))
