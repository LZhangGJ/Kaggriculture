from pathlib import Path
import importlib.util,json,gzip,copy,time,hashlib,resource
w=Path(__file__).resolve().parents[1];r=w/'candidate' if (w/'candidate/main.py').is_file() else w
sp=importlib.util.spec_from_file_location('r3_main_check',r/'main.py');mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
summary=[];lib=w/'research/r3_final_disabled.so'
for path in sorted((w/'feedback/own_traces').glob('*.gz')):
 data=json.loads(gzip.decompress(path.read_bytes()));a=mod.create_agent(lib);t=time.perf_counter();maxcall=0
 for k,o in enumerate(data['observations'][:719]):
  start=time.perf_counter();out=a(copy.deepcopy(o),data['configuration']);maxcall=max(maxcall,time.perf_counter()-start)
  assert out==data['own_actions'][k],(path.name,k)
 summary.append({'case':data['game_id'],'exact':719,'seconds':time.perf_counter()-t,'max_call_seconds':maxcall,'debug':a.debug()});a.close();print(data['game_id'],719,flush=True)
(w/'logs/disabled_final_equivalence.json').write_text(json.dumps({'scope':'Compile-time disabled R3 mechanism. Full parent-history equivalence, not new games.','native_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'exact_total':sum(x['exact'] for x in summary),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'results':summary},indent=2))
