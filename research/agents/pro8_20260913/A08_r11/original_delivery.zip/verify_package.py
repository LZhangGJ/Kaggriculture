#!/usr/bin/env python3
"""Verify a frozen source-only release; optional bounded saved-observation smoke.
No full match, seed draw or PASS evaluation is started.
"""
from pathlib import Path
import argparse,gzip,hashlib,importlib.util,json,time
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify(smoke=False):
 manifest=json.loads((ROOT/'FILES_SHA256.json').read_text());checked=0
 for rel,entry in manifest.items():
  p=ROOT/rel;assert p.is_file(),rel;assert sha(p)==entry['sha256'],rel;assert p.stat().st_size==entry['bytes'],rel;checked+=1
 build=json.loads((ROOT/'BUILD.json').read_text())
 for rel,h in build['sources'].items():assert sha(ROOT/rel)==h,rel
 assert sha(ROOT/'policy/a08_r11.so')==build['binary_sha256']
 assert (ROOT/'BUILD.json').read_bytes()==(ROOT/'policy/a08_r11.BUILD.json').read_bytes()
 result={'files_verified':checked,'BUILD_sources_verified':len(build['sources']),'binary_sha256':build['binary_sha256'],'formal_games':0,'smoke':[]}
 if smoke:
  sp=importlib.util.spec_from_file_location('default_release',ROOT/'main.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
  try:
   for name in ['author_A06_r6_3592792484_seat0','author_A02_r1_3592792492_seat1']:
    case=json.loads((ROOT/'validation/cases'/f'{name}.json').read_text());d=json.loads(gzip.decompress((ROOT/'validation/fixtures'/f'{name}.json.gz').read_bytes()));seat=d['result']['seat'];start=time.perf_counter();hashes=[]
    for step in range(case['step']+1):
     action=m.agent(d['steps'][step][seat]['observation'])
     expect=d['actions'][step][seat] if step<case['step'] else case['r11_action']
     assert action==expect,(name,step,'default entry action mismatch')
     hashes.append(hashlib.sha256(json.dumps(action,sort_keys=True,separators=(',',':')).encode()).hexdigest())
    result['smoke'].append({'case':name,'seat':seat,'calls':case['step']+1,'original_prefix_identical_calls':case['step'],'first_sale_action_matches':True,'seconds':time.perf_counter()-start,'action_sha256_by_step':hashes})
  finally:m.reset()
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--smoke',action='store_true');p.add_argument('--out',type=Path);a=p.parse_args();r=verify(a.smoke)
 if a.out:
  assert not a.out.resolve().is_relative_to(ROOT),'Write validation output outside frozen release';assert not a.out.exists();a.out.write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({**r,'smoke':[{k:v for k,v in x.items() if k!='action_sha256_by_step'} for x in r['smoke']]},indent=2))
