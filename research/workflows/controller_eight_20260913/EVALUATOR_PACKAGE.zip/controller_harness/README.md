# CPU strategy evaluation harness

`controller.py` runs the frozen official interpreter from `../author_input_smoke/referee`. Each strategy gets a fresh spawned process for every game. Only its own observation and a configuration with seed cleared cross its pipe. Module state, native contexts and imports cannot carry across games. Games run in separate process groups; the game watchdog kills the group on Linux/WSL. Per-action watchdogs report seat and step. This is process isolation, not a hostile-code filesystem or network sandbox.

Each valid result must finish exactly 719 transitions, put both players in DONE status, and have finite rewards equal to terminal farm money. The official action JSON schema accepts objects; the harness also requires JSON serialization without NaN. The official interpreter handles illegal unit commands as silent no-ops. This harness preserves that rule and does not label every ineffective action illegal. Its configurable local timeout is not certification of Kaggle's timeout accounting.

## Run

Use Python 3.10 or newer on Linux/WSL. The tests and smoke here used direct `wsl -d Ubuntu-22.04 -- python3`, which resolves Python 3.10.12. A login shell differs: `wsl -d Ubuntu-22.04 -- bash -lc 'command -v python3; python3 --version'` resolves `/home/ktyser/.local/bin/python3`, Python 3.12.13. Record the exact invocation for each run. Native packages may need a build before freezing. Never rebuild the pinned original R2 just to change its identity.

1. Prepare a roster JSON with `candidates` and `opponents` lists. Each item has `id`, absolute `root`, and relative `entry` (usually `main.py`). Keep runtime/source roots separate from result directories. Candidate IDs must be distinct from opponent IDs. Use all eight candidates for qualification and round robin; use the selected two for the competitive freeze. Source changes require a new freeze.
2. Freeze before drawing seeds: `python3 controller.py freeze --roster roster.json --referee ../author_input_smoke/referee --output freeze.json`.
3. Supply a seed JSON with `created_unix` later than the freeze and a `seeds` list. No seed generator is included. Import all historical and author-development seeds into the shared ledger before the first run: each JSONL line has a `seeds` list. `outputs/SEED_HISTORY.json`, maintained by the central controller, contains known historical exclusions. Use the same ledger path for every revision and phase.
4. Run: `python3 controller.py run --freeze freeze.json --seeds fresh_seeds.json --seed-ledger campaign_seed_claims.jsonl --mode competitive --workers 2 --game-seconds 120 --action-seconds 5 --round-seconds 7200 --replays --output new_round`.

Modes: qualification requires at least two distinct seeds and plays both seats against PASS; its complete average terminal cash must reach 200,000. Round robin requires eight candidates, schedules each unordered pair on both seats for every shared seed, and reports ranking eligibility only. Competitive requires exactly 64 distinct seeds and the exact public11 plus original R2 IDs in `POOL_SOURCE_INVENTORY.json`, for 1,536 games per candidate. Only a complete, unchanged-source competitive run above 85% strict wins passes. Ties, failures and missing games never count as wins; all planned games remain in the denominator. There is no competitive cash gate.

The manifest freezes settings, cells, referee and full source-tree hashes. `rows.jsonl` appends one record per planned cell and includes every action duration. Each optional gzip replay contains initial state and every action and resulting state; its hash appears in the result. `SUMMARY.json` contains aggregate, opponent and seat counts/rates. `POST_RUN_INTEGRITY.json` must be valid for promotion. A run never resumes or silently retries failures. The shared seed ledger claims seeds before execution and rejects reuse. An exhausted two-hour budget records all remaining cells as errors.

One or two workers need no extra receipt. More workers, up to 32, require an explicit `--resource-preflight receipt.json` with `approved_workers` and positive `measured_seconds_per_game`. The controller must measure and approve that concurrency; the receipt alone is not a benchmark.

## Verification and timing

Run `python3 -m unittest -v test_controller`. Tests cover panel counts, denominator failures, round-robin seat inversion, two complete fresh-process games, hidden seed checks, action timing coverage, and actor/game watchdog errors. The test PASS fixture is not a strategy candidate.

`native_smoke.py` ran the existing parent versus the exact original R2 in both seats on already-used seed 291307001. Both games completed 719 transitions in 5.315 and 5.186 seconds. Both actors returned 719 timed actions in each game; the maximum action time was 0.200 seconds. Referee peak RSS was about 22 MiB; the largest reported child peak was about 38 MiB. Child peak RSS is not total simultaneous memory use.

At the measured mean of 5.25 seconds, 1,536 games cost about 2.24 hours serial or 1.12 hours at ideal two-worker scaling. Two candidates cost about 2.24 hours at two workers, exceeding the two-hour round cap. Four workers would project 1.12 hours for both candidates, but must be benchmarked first. These are estimates from one seed and two native policies; slow Python opponents or revised authors can change the cost. Allow time for compilation, qualification, matches, analysis and scheduling within each author round. `NATIVE_SMOKE.json` preserves raw timings and results; this smoke is not fresh qualification or competitive evidence.

## Opponent availability

All 12 required entrypoints exist under the read-only portable repository at `C:/Users/Owner/Documents/Codex/2026-09-11/please-go-onto-my-discord-i/work/portable-repo/evaluation/opponents`. `POOL_SOURCE_INVENTORY.json` lists 46 files and their SHA256 values across the designated directories. Paths in this inventory are Windows paths; convert to `/mnt/c/...` when preparing a WSL roster.

The original `submission_56149565/afs_runtime/agent.so` hash is `1ead09a9bd48b20b512fb8fe57bbbbd87c86bb12fc9b1b42553e5c5b5bec121c`, exactly the required original R2. Its runtime works unchanged in the native smoke. The directory includes entrypoint, runtime policy, config and binary, but no C++ source; do not claim complete R2 build-source availability.

## Four-worker public12 runtime preflight

The authorized follow-up ran the rebuilt parent against all exact 12 opponents in both seats on already-used seed 291307001. Before starting, WSL reported 32 logical CPUs, 7,936 MiB total memory and 7,292 MiB available memory. Direct `/usr/bin/python3` was 3.10.12. Four concurrent CPU game workers completed all 24 games without errors in 24.733 seconds. All games reached 719 transitions, and source hashes matched before and after.

Observed throughput was 0.9704 games/second; the 3,072-game projection is 3,166 seconds, or 52.8 minutes. Maximum action time was 0.216 seconds. Individual game-process peak RSS was 23,804 KiB; the largest actor peak was 70,140 KiB. These peaks do not measure simultaneous aggregate memory. This one-seed estimate leaves about 67 minutes in a two-hour budget, but revised authors, other seeds, qualification and analysis can consume that margin.

`pool_preflight_results/rows.jsonl` contains all 24 full timing records. `SOURCE_BEFORE.json` and `SOURCE_AFTER.json` preserve source-tree hashes. `RESOURCE_PREFLIGHT.json` authorizes four workers for this measured runtime and can serve as the CLI resource receipt. This is runtime evidence only; it is neither qualification nor competitive acceptance. No strategy or original R2 source changed.
