"""CPU evaluation controller. Python 3.10+, Linux/WSL recommended."""
import argparse, concurrent.futures, copy, gzip, hashlib, importlib.util, inspect
import json, math, multiprocessing as mp, os, pathlib, signal, subprocess, sys, time, traceback
P = pathlib.Path
HERE = P(__file__).resolve().parent
POOL_IDS=set('soil_v219g moon_v215 flexon_v5 market_smart_v8 nagatakengo_v70 aurax_reactive_v1 thomas_955_v2 shop0909 aurax_shop_v2 seven_turn ahmed_v27 submission_56149565'.split())
os.environ.update(CUDA_VISIBLE_DEVICES='', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
sys.dont_write_bytecode = True

def sha(p): return hashlib.sha256(P(p).read_bytes()).hexdigest()
def read(p): return json.loads(P(p).read_text())
def write(p, value): P(p).write_text(json.dumps(value, sort_keys=True, indent=2)+'\n')
def require(ok, text):
    if not ok: raise ValueError(text)
def tree(root):
    return {str(p.relative_to(root)): sha(p) for p in sorted(P(root).rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}

def cells(mode, candidates, opponents, seeds):
    require(len(seeds)==len(set(seeds)) and all(type(s) is int for s in seeds), 'Unique integer seeds required')
    ids=[x['id'] for x in candidates]; rivals=[x['id'] for x in opponents]
    require(len(ids)==len(set(ids)) and len(rivals)==len(set(rivals)), 'Duplicate identities')
    if mode=='qualification':
        require(len(seeds)>=2, 'Qualification requires multiple seeds')
        pairs=[(a,'PASS') for a in ids]
    elif mode=='roundrobin':
        require(len(ids)==8, 'Eight candidates required')
        pairs=[(a,b) for i,a in enumerate(ids) for b in ids[i+1:]]
    else:
        require(len(seeds)==64 and len(rivals)==12, 'Competitive panel needs 64 seeds and 12 opponents')
        require(set(rivals)==POOL_IDS,'Competitive pool must match the designated public11 plus original R2')
        require(not set(ids)&set(rivals), 'Candidate/opponent identity collision')
        pairs=[(a,b) for a in ids for b in rivals]
    return [dict(candidate=a,opponent=b,seed=s,seat=seat) for a,b in pairs for s in seeds for seat in (0,1)]

def load(path):
    path=P(path).resolve(); sys.path.insert(0,str(path.parent)); os.chdir(path.parent)
    spec=importlib.util.spec_from_file_location('isolated_strategy',path)
    mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
    return mod.create_agent() if hasattr(mod,'create_agent') else mod.agent

def actor(pipe, entry):
    # Spawn receives only its own entrypoint. Environment seed and referee never enter this process.
    try:
        fn=load(entry); two=True
        try: inspect.signature(fn).bind({}, {})
        except TypeError: two=False
        pipe.send({'ready':True})
        while True:
            message=pipe.recv()
            if message is None: break
            obs,cfg=message
            assert 'seed' not in obs and cfg.get('seed') is None
            start=time.perf_counter(); action=fn(obs,cfg) if two else fn(obs)
            # JSON roundtrip rejects non-serializable actions and NaN.
            action=json.loads(json.dumps(action,allow_nan=False))
            pipe.send({'action':action,'seconds':time.perf_counter()-start})
        if hasattr(fn,'close'): fn.close()
    except BaseException:
        try: pipe.send({'error':traceback.format_exc()})
        except Exception: pass
    finally: pipe.close()

def receive(pipe, timeout, seat, step):
    if not pipe.poll(timeout): raise TimeoutError(f'actor watchdog seat={seat} step={step} limit={timeout}s')
    try: result=pipe.recv()
    except EOFError: raise RuntimeError(f'actor exited seat={seat} step={step}')
    if 'error' in result: raise RuntimeError(f'actor failure seat={seat} step={step}: '+result['error'])
    return result

def validate(action):
    # The official action JSON schema requires only an object. Semantic illegal
    # commands are official silent no-ops, not disqualifications.
    require(isinstance(action,dict),'Official action schema requires object')
    json.dumps(action,allow_nan=False)

def game(payload):
    start=time.monotonic(); row=dict(payload['cell'],valid=False,steps=0)
    procs=[]; pipes=[]; timings=[[],[]]; replay=None
    try:
        sys.path.insert(0,payload['referee'])
        from cpu_runtime import LocalGame, load_engine, pass_agent
        env=LocalGame(row['seed'],load_engine()); ctx=mp.get_context('spawn')
        entries=[payload['entries'][row['candidate']],payload['entries'].get(row['opponent'])]
        if row['seat']==1: entries.reverse()
        for seat,entry in enumerate(entries):
            if entry is None: pipes.append(None);continue
            parent,child=ctx.Pipe();proc=ctx.Process(target=actor,args=(child,entry));proc.start();child.close()
            procs.append(proc);pipes.append(parent)
            receive(parent,payload['startup_seconds'],seat,-1)
        if payload.get('replay'):
            replay=gzip.open(payload['replay'],'wt'); replay.write(json.dumps({'initial':env.snapshot()})+'\n')
        while not env.done:
            actions=[]
            for seat,pipe in enumerate(pipes):
                obs=env.observation(seat)
                if pipe is None: actions.append(pass_agent(obs));continue
                pipe.send((obs,copy.deepcopy(env.configuration)))
                r=receive(pipe,payload['action_seconds'],seat,env.t)
                validate(r['action']);actions.append(r['action']);timings[seat].append(r['seconds'])
            env.advance(actions);row['steps']=env.t
            if replay: replay.write(json.dumps({'actions':actions,'state':env.snapshot()})+'\n')
            require(env.t<=719,'Episode exceeded 719 transitions')
        require(env.t==719 and all(s.status=='DONE' for s in env.state),'Incomplete terminal coverage')
        cash=[float(s.reward) for s in env.state]
        require(all(math.isfinite(x) for x in cash),'Nonfinite terminal reward')
        require(all(cash[i]==float(env.state[i].observation.farms[i]['money']) for i in (0,1)), 'Terminal cash/reward mismatch')
        own=cash[row['seat']];other=cash[1-row['seat']]
        row.update(valid=True,cash=cash,own_cash=own,opponent_cash=other,win=own>other,tie=own==other,margin=own-other)
    except BaseException: row['error']=traceback.format_exc()
    finally:
        for pipe in pipes:
            if pipe:
                try: pipe.send(None);pipe.close()
                except Exception: pass
        for proc in procs:
            proc.join(.1)
            if proc.is_alive(): proc.terminate();proc.join(1)
        if replay:
            replay.close();row['replay_sha256']=sha(payload['replay'])
        row.update(seconds=time.monotonic()-start,action_seconds=timings)
        try:
            import resource
            row['max_rss_kib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            row['child_max_rss_kib']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
        except ImportError: pass
    return row

def bounded(payload, directory, index):
    inp=directory/f'game_{index:06d}.json'; out=directory/f'game_{index:06d}.result.json'
    write(inp,payload);start=time.monotonic()
    proc=subprocess.Popen([sys.executable,str(HERE/'controller.py'),'_game',str(inp),str(out)],
                          start_new_session=os.name=='posix',stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        proc.wait(timeout=payload['game_seconds'])
        if out.exists(): return read(out)
        return dict(payload['cell'],valid=False,error=f'game process exited {proc.returncode} without result',seconds=time.monotonic()-start)
    except subprocess.TimeoutExpired:
        if os.name=='posix': os.killpg(proc.pid,signal.SIGKILL)
        else: subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True)
        proc.wait()
        return dict(payload['cell'],valid=False,error='game watchdog expired',seconds=time.monotonic()-start)

def summary(manifest, rows):
    result={}
    for c in manifest['candidates']:
        ident=c['id']; mode=manifest['mode']
        planned=sum(x['candidate']==ident or (mode=='roundrobin' and x['opponent']==ident) for x in manifest['cells'])
        selected=[r for r in rows if r['candidate']==ident or (mode=='roundrobin' and r['opponent']==ident)]
        good=[r for r in selected if r['valid']]
        wins=sum((r['win'] if r['candidate']==ident else r['margin']<0) for r in good)
        cash=[r['own_cash'] if r['candidate']==ident else r['opponent_cash'] for r in good]
        complete=len(good)==planned
        mean=sum(cash)/len(cash) if cash else None
        def stats(items):
            return dict(recorded=len(items),errors=sum(not r['valid'] for r in items),ties=sum(r.get('tie',False) for r in items),wins=sum(r['valid'] and (r['win'] if r['candidate']==ident else r['margin']<0) for r in items))
        by_opponent={}
        by_seat={}
        for planned_row in manifest['cells']:
            if planned_row['candidate']!=ident and not (mode=='roundrobin' and planned_row.get('opponent')==ident): continue
            own=planned_row['candidate']==ident
            opp=planned_row.get('opponent','unknown') if own else planned_row['candidate']
            seat=planned_row.get('seat',0) if own else 1-planned_row['seat']
            for table,key,match in [(by_opponent,opp,lambda r:(r.get('opponent') if r['candidate']==ident else r['candidate'])==opp),(by_seat,str(seat),lambda r:(r.get('seat',0) if r['candidate']==ident else 1-r['seat'])==seat)]:
                if key not in table: table[key]=dict(stats([r for r in selected if match(r)]),planned=0)
                table[key]['planned']+=1
        for table in (by_opponent,by_seat):
            for value in table.values(): value['strict_win_rate']=value['wins']/value['planned']
        result[ident]=dict(planned=planned,recorded=len(selected),valid=len(good),wins=wins,
            strict_win_rate=wins/planned,mean_terminal_cash=mean,complete=complete,
            errors=sum(not r['valid'] for r in selected),ties=sum(r.get('tie',False) for r in good),by_opponent=by_opponent,by_seat=by_seat,
            ranking_eligible=complete and manifest.get('integrity_valid',True),accepted=None if mode=='roundrobin' else complete and manifest.get('integrity_valid',True) and (mean>=200000 if mode=='qualification' else wins/planned>.85))
    return result

def main():
    if len(sys.argv)>1 and sys.argv[1]=='_game':
        write(sys.argv[3],game(read(sys.argv[2])));return
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='command',required=True)
    f=sub.add_parser('freeze');f.add_argument('--roster',required=True);f.add_argument('--referee',required=True);f.add_argument('--output',required=True)
    r=sub.add_parser('run');r.add_argument('--freeze',required=True);r.add_argument('--seeds',required=True);r.add_argument('--output',required=True)
    r.add_argument('--seed-ledger',required=True,help='Shared campaign append-only seed-claim journal')
    r.add_argument('--mode',choices=['qualification','roundrobin','competitive'],required=True)
    r.add_argument('--workers',type=int,default=1);r.add_argument('--resource-preflight',help='Required JSON receipt for workers above two: approved_workers and measured_seconds_per_game')
    r.add_argument('--game-seconds',type=float,default=120)
    r.add_argument('--action-seconds',type=float,default=5);r.add_argument('--startup-seconds',type=float,default=30)
    r.add_argument('--round-seconds',type=float,default=7200);r.add_argument('--replays',action='store_true')
    args=ap.parse_args()
    if args.command=='freeze':
        require(not P(args.output).exists(),'Freeze already exists')
        roster=read(args.roster)
        for entry in roster['candidates']+roster.get('opponents',[]):
            entry['root']=str(P(entry['root']).resolve());entry['entry']=str((P(entry['root'])/entry.get('entry','main.py')).resolve())
            require(P(entry['entry']).is_relative_to(P(entry['root'])),'Entry outside root')
            require(P(entry['entry']).is_file(),'Missing entry')
            entry['files']=tree(entry['root'])
            if entry['id']=='submission_56149565':
                require(entry['files'].get('afs_runtime/agent.so')=='1ead09a9bd48b20b512fb8fe57bbbbd87c86bb12fc9b1b42553e5c5b5bec121c','Original R2 native hash mismatch')
        roster.update(referee=str(P(args.referee).resolve()),referee_files=tree(P(args.referee).resolve()),frozen_unix=time.time(),harness_sha256=sha(__file__))
        write(args.output,roster);return
    require(0<args.round_seconds<=7200 and args.game_seconds>0 and args.action_seconds>0,'Invalid time budget')
    require(1<=args.workers<=32,'Workers must be between 1 and 32')
    if args.workers>2:
        receipt=read(args.resource_preflight) if args.resource_preflight else {}
        require(receipt.get('approved_workers',0)>=args.workers and receipt.get('measured_seconds_per_game',0)>0,'Measured resource preflight required above two workers')
    freeze=read(args.freeze);require(sha(__file__)==freeze['harness_sha256'],'Harness changed since freeze')
    require(tree(freeze['referee'])==freeze['referee_files'],'Referee changed')
    for e in freeze['candidates']+freeze.get('opponents',[]): require(tree(e['root'])==e['files'],'Source changed: '+e['id'])
    seed_input=read(args.seeds)
    require(seed_input['created_unix']>freeze['frozen_unix'],'Seed panel must be created after source freeze')
    planned=cells(args.mode,freeze['candidates'],freeze.get('opponents',[]),seed_input['seeds'])
    ledger=P(args.seed_ledger).resolve();ledger.parent.mkdir(parents=True,exist_ok=True)
    lock=ledger.with_suffix(ledger.suffix+'.lock')
    guard=lock.open('x')
    try:
            old=[json.loads(line) for line in ledger.read_text().splitlines()] if ledger.exists() else []
            used={s for claim in old for s in claim['seeds']}
            require(not used.intersection(seed_input['seeds']),'Seed panel overlaps an earlier claimed panel')
            with ledger.open('a') as journal:
                journal.write(json.dumps(dict(seeds=seed_input['seeds'],freeze_sha256=sha(args.freeze),output=str(P(args.output).resolve()),claimed_unix=time.time()))+'\n')
                journal.flush();os.fsync(journal.fileno())
    finally:
        guard.close();lock.unlink()
    directory=P(args.output).resolve();directory.mkdir(parents=True,exist_ok=False)
    manifest=dict(freeze,mode=args.mode,cells=planned,settings=vars(args),seed_panel_sha256=sha(args.seeds),freeze_sha256=sha(args.freeze))
    write(directory/'MANIFEST.json',manifest)
    entries={e['id']:e['entry'] for e in freeze['candidates']+freeze.get('opponents',[])}
    jobs=directory/'games';jobs.mkdir();rows=[];start=time.monotonic()
    def task(i):
        remaining=args.round_seconds-(time.monotonic()-start)
        if remaining<=0: return dict(planned[i],valid=False,error='round time budget exhausted')
        payload=dict(cell=planned[i],referee=freeze['referee'],entries=entries,game_seconds=min(args.game_seconds,remaining),action_seconds=args.action_seconds,startup_seconds=args.startup_seconds)
        if args.replays: payload['replay']=str(jobs/f'game_{i:06d}.replay.jsonl.gz')
        return bounded(payload,jobs,i)
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor, (directory/'rows.jsonl').open('x') as journal:
        for row in executor.map(task,range(len(planned))):
            rows.append(row);journal.write(json.dumps(row,allow_nan=False)+'\n');journal.flush();os.fsync(journal.fileno())
    manifest['integrity_valid']=(sha(__file__)==freeze['harness_sha256'] and tree(freeze['referee'])==freeze['referee_files'] and all(tree(e['root'])==e['files'] for e in freeze['candidates']+freeze.get('opponents',[])))
    write(directory/'POST_RUN_INTEGRITY.json',dict(valid=manifest['integrity_valid']))
    write(directory/'SUMMARY.json',summary(manifest,rows))
    print(json.dumps(summary(manifest,rows),indent=2))

if __name__=='__main__': main()
