"""Two-seat infrastructure timing on the already-used smoke seed only."""
import controller as c

if __name__=='__main__':
    root=c.HERE.parent
    directory=c.HERE/'native_smoke_results';directory.mkdir(exist_ok=True)
    pool=c.read(c.HERE/'POOL_SOURCE_INVENTORY.json')['opponents']
    r2=next(e for e in pool if e['id']=='submission_56149565')
    # Convert the read-only inventory's Windows path for WSL.
    r2path='/mnt/c/'+r2['root'][3:].replace('\\','/')+'/main.py'
    rows=[]
    for seat in (0,1):
        p=dict(cell=dict(candidate='parent',opponent='submission_56149565',seed=291307001,seat=seat),
          entries={'parent':str(root/'author_input_smoke/parent/main.py'),'submission_56149565':r2path},
          referee=str(root/'author_input_smoke/referee'),game_seconds=60,action_seconds=5,startup_seconds=15)
        rows.append(c.bounded(p,directory,seat))
    c.write(c.HERE/'NATIVE_SMOKE.json',rows)
    for r in rows: print({k:v for k,v in r.items() if k!='action_seconds'})
