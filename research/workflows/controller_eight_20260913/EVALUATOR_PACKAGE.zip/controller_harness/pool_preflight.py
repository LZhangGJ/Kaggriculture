"""Authorized 24-game runtime preflight, reused smoke seed, four CPU workers."""
import concurrent.futures, os, platform, shutil, time
import controller as c

def linux_path(value): return '/mnt/c/'+value[3:].replace('\\','/')

if __name__=='__main__':
    directory=c.HERE/'pool_preflight_results';directory.mkdir(exist_ok=False)
    inventory=c.read(c.HERE/'POOL_SOURCE_INVENTORY.json')['opponents']
    roots={e['id']:c.P(linux_path(e['root'])) for e in inventory}
    roots['parent']=c.HERE.parent/'author_input_smoke/parent'
    roots['referee']=c.HERE.parent/'author_input_smoke/referee'
    snapshots={key:c.tree(path) for key,path in roots.items()}
    for entry in inventory:
        c.require(snapshots[entry['id']]==entry['files'],'Pool differs from source inventory: '+entry['id'])
    c.write(directory/'SOURCE_BEFORE.json',snapshots)
    entries={key:str(path/'main.py') for key,path in roots.items() if key!='referee'}
    tasks=[dict(candidate='parent',opponent=e['id'],seed=291307001,seat=seat) for e in inventory for seat in (0,1)]
    start=time.monotonic()
    def run(index):
        remaining=300-(time.monotonic()-start)
        if remaining<=0:return dict(tasks[index],valid=False,error='preflight five-minute budget exhausted')
        payload=dict(cell=tasks[index],entries=entries,referee=str(roots['referee']),
            game_seconds=min(60,remaining),action_seconds=5,startup_seconds=15)
        return c.bounded(payload,directory,index)
    rows=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor, (directory/'rows.jsonl').open('x') as journal:
        futures={executor.submit(run,i):i for i in range(24)}
        for future in concurrent.futures.as_completed(futures):
            row=future.result();rows.append(row);journal.write(c.json.dumps(row)+'\n');journal.flush()
    elapsed=time.monotonic()-start
    after={key:c.tree(path) for key,path in roots.items()}
    c.write(directory/'SOURCE_AFTER.json',after)
    valid=[r for r in rows if r['valid']]
    report=dict(scope='Runtime and concurrency preflight only; reused seed 291307001. Not qualification or competitive evidence.',
        python=platform.python_version(),python_executable=c.sys.executable,invocation='wsl -d Ubuntu-22.04 --cd <harness> -- python3 pool_preflight.py',
        logical_cpus=os.cpu_count(),workers=4,planned=24,valid=len(valid),errors=[{k:v for k,v in r.items() if k!='action_seconds'} for r in rows if not r['valid']],
        seconds=elapsed,source_integrity_valid=snapshots==after,
        mean_game_seconds=sum(r['seconds'] for r in valid)/len(valid) if valid else None,
        max_action_seconds=max((x for r in rows for seat in r.get('action_seconds',[]) for x in seat),default=None),
        observed_games_per_second=24/elapsed,projected_3072_games_seconds=elapsed*128,
        max_game_process_rss_kib=max((r.get('max_rss_kib',0) for r in rows),default=0),
        max_actor_process_rss_kib=max((r.get('child_max_rss_kib',0) for r in rows),default=0),
        memory_note='RSS values are individual process peaks, not simultaneous aggregate memory.',
        approved_workers=4 if len(valid)==24 and snapshots==after else 0,
        measured_seconds_per_game=elapsed/24,
        estimate_limit='One already-used seed; revised candidates and other seeds can be slower. Allow author and analysis time within the round.')
    c.write(directory/'RESOURCE_PREFLIGHT.json',report);print(c.json.dumps(report,indent=2))
