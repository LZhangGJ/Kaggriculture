import tempfile, time, unittest
from pathlib import Path
import controller as c

class Contracts(unittest.TestCase):
    def test_coverage(self):
        authors=[{'id':str(i)} for i in range(8)]
        pool=[{'id':i} for i in sorted(c.POOL_IDS)]
        self.assertEqual(len(c.cells('competitive',authors[:2],pool,list(range(64)))),3072)
        self.assertEqual(len(c.cells('roundrobin',authors,[],[1,2])),112)
        with self.assertRaises(ValueError): c.cells('qualification',authors,[],[1,1])

    def test_failure_denominator(self):
        manifest={'mode':'competitive','candidates':[{'id':'a'}],'cells':[{'candidate':'a'}]*10}
        good=dict(candidate='a',valid=True,win=True,own_cash=1)
        report=c.summary(manifest,[good]*8)['a']
        self.assertEqual(report['strict_win_rate'],.8)
        self.assertFalse(report['accepted'])

    def test_roundrobin_inversion(self):
        cell=dict(candidate='a',opponent='b',seat=0,seed=1)
        row=dict(cell,valid=True,win=True,tie=False,margin=5,own_cash=10,opponent_cash=5)
        report=c.summary(dict(mode='roundrobin',candidates=[{'id':'a'},{'id':'b'}],cells=[cell]),[row])
        self.assertIsNone(report['b']['accepted'])
        self.assertEqual(report['b']['by_seat']['1']['wins'],0)
        self.assertEqual(report['b']['by_opponent']['a']['strict_win_rate'],0)

    def test_full_game_reset_and_privacy(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            # Test fixture only: records expected step and checks hidden seed.
            agent=root/'fixture.py'
            agent.write_text('n=0\ndef agent(obs,cfg):\n global n\n assert obs["step"]==n\n assert "seed" not in obs and cfg["seed"] is None\n n+=1\n return {"farmer":["PASS"],"hands":[],"market":[]}\n')
            payload=dict(cell=dict(candidate='a',opponent='PASS',seat=0,seed=7),
                entries={'a':str(agent)},referee=str(c.HERE.parent/'author_input_smoke/referee'),
                game_seconds=30,action_seconds=2,startup_seconds=5)
            rows=[c.bounded(payload,root,i) for i in range(2)]
            for row in rows:
                self.assertTrue(row['valid'],row.get('error'))
                self.assertEqual(row['steps'],719)
                self.assertEqual(len(row['action_seconds'][0]),719)
            c.write(c.HERE/'TEST_SMOKE.json',rows)
            agent.write_text('import time\ndef agent(obs,cfg):\n time.sleep(30)\n return {}\n')
            payload['action_seconds']=.1
            row=c.bounded(payload,root,2)
            self.assertFalse(row['valid']);self.assertIn('actor watchdog seat=0 step=0',row['error'])
            payload['game_seconds']=.01
            row=c.bounded(payload,root,3)
            self.assertEqual(row['error'],'game watchdog expired')

if __name__=='__main__': unittest.main()
