# Independent search and PPO pilot

Completed 640 test games on 8 fresh worlds; zero failed games.

| Family | Games | Wins | Draws | Win rate | Match score | Mean cash | Win-rate change vs control (95% CI) |
|---|---:|---:|---:|---:|---:|---:|---|
| control | 64 | 0 | 0 | 0.00% | 0.000 | 9324.2 | +0.00 pp [+0.00, +0.00] |
| untrained | 192 | 0 | 0 | 0.00% | 0.000 | 0.6 | +0.00 pp [+0.00, +0.00] |
| search | 192 | 0 | 0 | 0.00% | 0.000 | 41626.4 | +0.00 pp [+0.00, +0.00] |
| ppo | 192 | 0 | 0 | 0.00% | 0.000 | 0.0 | +0.00 pp [+0.00, +0.00] |

No champion promotion or submission. These are local pilot results.

- Eight test worlds and four benchmark opponents give limited coverage and power.
- Intervals are conditional on three trained seeds; individual seed results are also shown.
- E1 uses a finite five-stage target grammar with a feedback executor; CP-SAT repairs allocations, not full worker schedules.
- PPO and search have different learning mixtures: PPO adds current self-play.
- CPU pilot budgets do not establish GPU learning efficiency or hosted execution compliance.
- JAX backend has been audited from source, not benchmarked on this host.
