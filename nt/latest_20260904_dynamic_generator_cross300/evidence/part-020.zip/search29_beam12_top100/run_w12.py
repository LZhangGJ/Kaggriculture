"""Widen only the frozen daily common-plan search, then test 100 diverse winners."""
from pathlib import Path
import argparse,gzip,json,sys,time
HERE=Path(__file__).resolve().parent
EXP=HERE.parent
OLD=EXP/'search8_multiseed'
W4=EXP/'search29_multiseed'
W4POOL=EXP/'search29_top20_multiseed'
sys.path.insert(0,str(OLD));import run as old
sys.path.insert(0,str(W4POOL));import run_daily20 as helper
read,write,sha,zipped=old.read,old.write,old.sha,old.zipped
DAYS=list(range(29));WIDTH=12;COUNT=100;VALID=list(range(20264501,20264517))

def context(out,create=False):
    f,n,pool=old.runtime(OLD/'receipts_v1')
    assert read(W4POOL/'receipts_v1/acceptance.json')['status']=='COMPLETE_DAILY29_DIVERSE20_PAIRED_NEW_SEEDS_NOT_PROMOTION'
    refs=read(W4POOL/'receipts_v1/selection_frozen.json')
    for ref in refs['routes']:assert sha(W4POOL/'receipts_v1'/ref['route']/'selected20.json')==ref['sha256']
    frozen=dict(schema='daily29-beam12-diverse100-v1',days=DAYS,width=WIDTH,count=COUNT,train=old.TRAIN,validation=VALID,seats=[0,1],
        selected=f['selected'],route_ids=f['route_ids'],config=f['config'],script_sha256=sha(__file__),helper_sha256=sha(W4POOL/'run_daily20.py'),
        plan_sha256=sha(HERE/'PLAN_ZH.md'),source_inputs_sha256=sha(OLD/'receipts_v1/inputs.json'),
        binary_sha256=read(OLD/'receipts_v1/build.json')['binary_sha256'],width4_frozen=refs,
        width4_stage0_hashes={c['route_id']:sha(W4/'receipts_v1'/c['route_id']/'stage00.json.gz') for c in f['selected']},
        candidate_limit=None,threads=16)
    used=old.TRAIN+old.VALID+list(range(20264201,20264217))+list(range(20264301,20264317))+list(range(20264401,20264417))
    assert not set(VALID)&set(used)
    if create:out.mkdir(exist_ok=False);write(out/'inputs.json',frozen)
    else:assert read(out/'inputs.json')==frozen,'Frozen experiment inputs changed'
    return frozen,n,pool

def check(out):
    f,n,pool=context(out,True);checks=[]
    seeds=[s for s in old.TRAIN for _ in (0,1)];seats=[p for _ in old.TRAIN for p in (0,1)]
    for case in f['selected']:
        route=f['route_ids'].index(case['route_id']);engine=n.Search8(pool,route,f['config'],seeds,seats,DAYS,WIDTH,16);stage=engine.expand()
        with gzip.open(W4/'receipts_v1'/case['route_id']/'stage00.json.gz','rt') as file:prior=json.load(file)
        assert stage['frontier']==prior['frontier'] and stage['beam'][:4]==prior['beam']
        assert len(stage['beam'])==WIDTH
        checks.append(dict(route=case['route_id'],day0_candidates=stage['proposals'],same_frontier=True,top4_equal=True,beam_count=len(stage['beam'])))
    write(out/'mechanism.json',dict(status='PASS_SAME_DAY0_FRONTIER_ONLY_WIDTH_CHANGED',checks=checks))
    print(json.dumps(dict(check='PASS',checks=checks)),flush=True)

def search(out):
    f,n,pool=context(out);assert read(out/'mechanism.json')['status']=='PASS_SAME_DAY0_FRONTIER_ONLY_WIDTH_CHANGED'
    seeds=[s for s in old.TRAIN for _ in (0,1)];seats=[p for _ in old.TRAIN for p in (0,1)];start=time.perf_counter();refs=[]
    for case in f['selected']:
        target=out/case['route_id'];target.mkdir(exist_ok=True)
        if not (target/'selected.json').exists():
            if any(target.glob('stage*.json.gz')):raise RuntimeError('Partial frontier exists: preserve and use new version, never overwrite')
            tic=time.perf_counter();engine=n.Search8(pool,f['route_ids'].index(case['route_id']),f['config'],seeds,seats,DAYS,WIDTH,16)
            for depth in range(len(DAYS)):
                s=engine.expand();zipped(target/f'stage{depth:02d}.json.gz',s);best=s['beam'][0]['outcomes']
                p=dict(route=case['route_id'],day=s['day'],nodes=depth+1,total_nodes=29,beam=len(s['beam']),proposals=s['proposals'],suffixes=s['suffixes'],
                    seconds=s['seconds'],wins=sum(r['win'] for r in best),mean_margin=sum(r['margin'] for r in best)/len(best),total_suffixes=s['total_suffixes'])
                write(out/'progress.json',p);print(json.dumps(p),flush=True)
            selected=engine.state();selected['case']=case;selected['seconds']=time.perf_counter()-tic;write(target/'selected.json',selected)
            write(target/'policy.json',dict(days=DAYS,plan=selected['beam'][0]['plan'],base_config=f['config'],missing_recipe='KEEP_WITH_EXPLICIT_REASON'))
        refs.append(dict(route=case['route_id'],files={p.name:sha(p) for p in sorted(target.glob('stage*.json.gz'))},selected_sha256=sha(target/'selected.json'),policy_sha256=sha(target/'policy.json')))
    write(out/'search_done.json',dict(status='ALL_SEARCH_COMPLETE_BEFORE_HOLDOUT',seconds=time.perf_counter()-start,routes=refs))

def select(out):
    f,n,pool=context(out);search=read(out/'search_done.json');all_selected=[];start=time.perf_counter()
    for ref in search['routes']:
        target=out/ref['route']
        for name,h in ref['files'].items():assert sha(target/name)==h
        assert sha(target/'selected.json')==ref['selected_sha256'] and sha(target/'policy.json')==ref['policy_sha256']
    for case in f['selected']:
        target=out/case['route_id'];dest=target/'selected100.json'
        if dest.exists():all_selected.append(dict(route=case['route_id'],sha256=sha(dest)));continue
        catalog={};evaluated=0
        for path in sorted(target.glob('stage*.json.gz')):
            with gzip.open(path,'rt') as file:s=json.load(file)
            for row in s['frontier']:
                evaluated+=1
                if row['wins']!=8:continue
                k=helper.key(row['plan']);item=dict(row,plan=helper.canonical(row['plan']),origin=path.name,depth=len(row['plan']),plan_id=helper.plan_id(row['plan']))
                if k in catalog:
                    for name in ('wins','mean_margin','mean_cash'):assert catalog[k][name]==item[name]
                else:catalog[k]=item
        zipped(target/'winning_frontier_catalog.json.gz',list(catalog.values()));assert len(catalog)>=COUNT,'Insufficient training winners'
        first=helper.key(read(target/'policy.json')['plan']);assert first in catalog
        remaining=dict(catalog);min_dist={k:float('inf') for k in remaining};chosen=[];seen=set();attempts=[];route=f['route_ids'].index(case['route_id'])
        while len(chosen)<COUNT and remaining:
            k=first if not chosen else max(remaining,key=lambda x:(min_dist[x],remaining[x]['mean_margin'],remaining[x]['mean_cash'],x))
            item=remaining.pop(k);min_dist.pop(k)
            rows=helper.evaluate(n,pool,f,route,item['plan'],DAYS,old.TRAIN);stats=old.stats(rows)
            assert stats['wins']==8
            for name in ('mean_cash','mean_margin'):assert stats[name]==item[name],('Full replay mismatch',name)
            signature=tuple(r['state_action_hash'] for r in rows);duplicate=signature in seen
            record=dict(item,training=stats,training_rows=rows,behavior_signature=list(signature),duplicate_behavior=duplicate);attempts.append(record)
            if duplicate:continue
            seen.add(signature);record['selection_index']=len(chosen)+1;chosen.append(record)
            for other in remaining:min_dist[other]=min(min_dist[other],helper.distance(other,k))
            write(target/'selection_progress.json',dict(accepted=len(chosen),attempted=len(attempts)))
            if len(chosen)%5==0 or len(chosen)==1:print(json.dumps(dict(select=case['route_id'],accepted=len(chosen),attempted=len(attempts))),flush=True)
        zipped(target/'selection_attempts.json.gz',attempts);assert len(chosen)==COUNT,'Insufficient distinct actual behaviors'
        write(dest,dict(status='FROZEN_BEFORE_NEW_SEEDS',case=case,frontier_evaluations=evaluated,semantic_win8_count=len(catalog),
            attempted=len(attempts),behavior_duplicate_count=len(attempts)-len(chosen),candidates=chosen))
        all_selected.append(dict(route=case['route_id'],sha256=sha(dest)))
    write(out/'selection_frozen.json',dict(status='ALL_300_FROZEN',routes=all_selected,seconds=time.perf_counter()-start))

def validate(out):
    f,n,pool=context(out);frozen=read(out/'selection_frozen.json');assert frozen['status']=='ALL_300_FROZEN'
    for ref in frozen['routes']:assert sha(out/ref['route']/'selected100.json')==ref['sha256']
    summaries=[];start=time.perf_counter()
    for case in f['selected']:
        target=out/case['route_id'];route=f['route_ids'].index(case['route_id']);sel=read(target/'selected100.json')
        basefile=target/'keep_validation.json'
        if basefile.exists():base=read(basefile)
        else:
            rows=helper.evaluate(n,pool,f,route,[old.KEEP]*29,DAYS,VALID);base=dict(summary=old.stats(rows),rows=rows);write(basefile,base)
        w4=read(W4POOL/'receipts_v1'/case['route_id']/'selected20.json');results={}
        for arm,chosen in [('W12',sel['candidates']),('W4',w4['candidates'])]:
            plans=[]
            for item in chosen:
                dest=target/f"{arm.lower()}_{item['selection_index']:03d}_validation.json"
                if dest.exists():result=read(dest)
                else:
                    rows=helper.evaluate(n,pool,f,route,item['plan'],DAYS,VALID)
                    result=dict(arm=arm,days=DAYS,plan_id=item['plan_id'],selection_index=item['selection_index'],plan=item['plan'],summary=old.stats(rows),rows=rows);write(dest,result)
                assert result['plan_id']==item['plan_id'];plans.append(result)
                if item['selection_index']%5==0 or item['selection_index']==1:
                    print(json.dumps(dict(validation=case['team_name'],arm=arm,candidate=item['selection_index'],wins=result['summary']['wins'],games=32,mean_margin=result['summary']['mean_margin'])),flush=True)
            results[arm]=plans
        summary=dict(route=case['route_id'],team=case['team_name'],keep=base['summary'],arms={
            'W4_20':helper.arm_summary(results['W4']), 'W12_20':helper.arm_summary(results['W12'][:20]), 'W12_100':helper.arm_summary(results['W12'])})
        write(target/'summary.json',summary);summaries.append(summary)
        item=sel['candidates'][-1]
        for seat in (0,1):
            fixture=n.replay8(pool,route,f['config'],VALID[0],seat,DAYS,item['plan'],True)
            assert fixture['state_action_hash']==results['W12'][-1]['rows'][seat]['state_action_hash']
            zipped(target/f'official_fixture_seat{seat}.json.gz',fixture)
    write(out/'validation_done.json',dict(status='ALL_11616_NEW_SEED_GAMES_COMPLETE',summary=summaries,seconds=time.perf_counter()-start))

def official(out):
    context(out);import audit
    audit.runtime=lambda ignored:context(out)
    audit.official(out)

def close(out):
    f,n,pool=context(out);v=read(out/'validation_done.json');o=read(out/'official.json')
    assert o['status']=='PASS_COMPLETE_STATE_AND_PYTHON_OPPONENT' and len(o['rows'])==6
    for ref in read(out/'selection_frozen.json')['routes']:
        assert sha(out/ref['route']/'selected100.json')==ref['sha256']
        s=read(out/ref['route']/'selected100.json');assert len(s['candidates'])==COUNT
        assert len({tuple(c['behavior_signature']) for c in s['candidates']})==COUNT
    write(out/'acceptance.json',dict(status='COMPLETE_BEAM12_DAILY29_100_ROUTES_PER_TARGET_NOT_PROMOTION',summary=v['summary'],
        width=WIDTH,days=DAYS,training_independent_seeds=4,validation_independent_seeds=16,w12_candidates=300,w4_candidates=60,
        w12_games=9600,w4_games=1920,keep_games=96,official_games=6,production_unchanged=True,old_goal_still_paused=True,
        online_router=False,candidate_limit=None,search_seconds=read(out/'search_done.json')['seconds'],
        files={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file() and p.name!='acceptance.json'}))
    print(json.dumps(dict(acceptance='PASS',summary=v['summary'])),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['check','search','select','validate','official','close']);p.add_argument('--version',default='v1');a=p.parse_args();out=HERE/('receipts_'+a.version)
    try:globals()[a.mode](out)
    except Exception as exc:
        if out.exists():write(out/f'failure_{a.mode}_{time.time_ns()}.json',dict(status='FAIL_PRESERVED',error=repr(exc)))
        raise
