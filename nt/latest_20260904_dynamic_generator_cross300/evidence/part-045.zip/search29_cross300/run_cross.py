"""Evaluate all frozen plans against all targets, without re-search or tuning."""
from pathlib import Path
import argparse, csv, gzip, json, sys, time

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'search29_beam12_top100'
SRC=SOURCE/'receipts_v1'
sys.path.insert(0,str(SOURCE))
import run_w12 as w
old,helper=w.old,w.helper
read,write,sha,zipped=w.read,w.write,w.sha,w.zipped
DAYS=w.DAYS;SEEDS=w.VALID
EXPECTED=[(s,p) for s in SEEDS for p in (0,1)]

def check_rows(rows):
    assert len(rows)==32 and [(r['seed'],r['seat']) for r in rows]==EXPECTED
    for r in rows:
        assert r['steps']==719 and r['margin']==r['cash']-r['opponent_cash']
        assert bool(r['win'])==(r['cash']>r['opponent_cash'])

def source_context():
    f,n,pool=w.context(SRC)
    acceptance=read(SRC/'acceptance.json')
    assert acceptance['status']=='COMPLETE_BEAM12_DAILY29_100_ROUTES_PER_TARGET_NOT_PROMOTION'
    refs=read(SRC/'selection_frozen.json');assert refs['status']=='ALL_300_FROZEN'
    candidates={};hashes={};diagonal={}
    for ref in refs['routes']:
        rid=ref['route'];path=SRC/rid/'selected100.json'
        assert sha(path)==ref['sha256']==acceptance['files'][str(path.relative_to(SRC))]
        candidates[rid]=read(path)['candidates'];assert len(candidates[rid])==100
        assert [c['selection_index'] for c in candidates[rid]]==list(range(1,101))
        hashes[str(path.relative_to(SRC))]=sha(path)
        for c in candidates[rid]:
            assert len(c['plan'])==29 and helper.plan_id(c['plan'])==c['plan_id']
            p=SRC/rid/f"w12_{c['selection_index']:03d}_validation.json"
            h=sha(p);assert h==acceptance['files'][str(p.relative_to(SRC))]
            r=read(p);assert r['plan']==c['plan'] and r['plan_id']==c['plan_id'] and r['days']==DAYS
            assert r['selection_index']==c['selection_index']
            check_rows(r['rows']);assert old.stats(r['rows'])==r['summary']
            hashes[str(p.relative_to(SRC))]=h;diagonal[(rid,c['selection_index'])]=r
    return f,n,pool,candidates,hashes,diagonal

def context(out,create=False):
    f,n,pool,candidates,hashes,diagonal=source_context()
    manifest=dict(schema='daily29-cross300-v1',days=DAYS,seeds=SEEDS,seats=[0,1],threads=16,
        config=f['config'],opponents=[dict(route_id=c['route_id'],team_name=c['team_name']) for c in f['selected']],
        source_acceptance_sha256=sha(SRC/'acceptance.json'),source_inputs_sha256=sha(SRC/'inputs.json'),
        source_files=hashes,script_sha256=sha(__file__),plan_sha256=sha(HERE/'PLAN_ZH.md'),
        binary_sha256=f['binary_sha256'],games=28800,reused_games=9600,new_games=19200,
        ranking='minimum_opponent_wins_then_total_wins_then_mean_margin')
    if create:
        out.mkdir(exist_ok=False);write(out/'inputs.json',manifest)
    else:assert read(out/'inputs.json')==manifest,'Frozen crossplay inputs changed'
    return f,n,pool,candidates,diagonal

def freeze(out):
    f,n,pool,candidates,diagonal=context(out,True);checks=[]
    for case in f['selected']:
        rid=case['route_id'];item=candidates[rid][0]
        for seat in (0,1):
            r=n.replay8(pool,f['route_ids'].index(rid),f['config'],SEEDS[0],seat,DAYS,item['plan'],False)
            ref=diagonal[(rid,1)]['rows'][seat]
            for k in ('state_action_hash','cash','opponent_cash','missing_recipe','steps'):assert r[k]==ref[k],k
            checks.append(dict(source=rid,seed=SEEDS[0],seat=seat,state_action_hash=r['state_action_hash']))
    write(out/'mechanism.json',dict(status='PASS_ORIGINAL_RESULTS_REPRODUCED',checks=checks))
    print(json.dumps(dict(freeze='PASS',plans=300,mechanism_games=6)),flush=True)

def destination(out,source,index,target):return out/'games'/source/f'{index:03d}'/(target+'.json')

def run(out):
    f,n,pool,candidates,diagonal=context(out)
    assert read(out/'mechanism.json')['status']=='PASS_ORIGINAL_RESULTS_REPRODUCED'
    tic=time.perf_counter();completed=calculated=0;files={};fixtures=[]
    for src in f['selected']:
        srid=src['route_id']
        for target in f['selected']:
            trid=target['route_id'];route=f['route_ids'].index(trid)
            for item in candidates[srid]:
                idx=item['selection_index'];path=destination(out,srid,idx,trid)
                metadata=dict(source_route=srid,opponent_route=trid,selection_index=idx,plan_id=item['plan_id'],days=DAYS,plan=item['plan'])
                if path.exists():result=read(path)
                else:
                    reused=srid==trid
                    rows=diagonal[(srid,idx)]['rows'] if reused else helper.evaluate(n,pool,f,route,item['plan'],DAYS,SEEDS)
                    check_rows(rows)
                    result=dict(**metadata,reused=reused,summary=old.stats(rows),rows=rows)
                    if reused:
                        p=SRC/srid/f'w12_{idx:03d}_validation.json'
                        result['reuse_source']=str(p);result['reuse_sha256']=sha(p)
                    else:calculated+=32
                    write(path,result)
                for k,v in metadata.items():assert result[k]==v,(path,k)
                check_rows(result['rows']);assert old.stats(result['rows'])==result['summary']
                assert result['reused']==(srid==trid)
                if srid==trid:assert result['rows']==diagonal[(srid,idx)]['rows']
                files[str(path.relative_to(out))]=sha(path);completed+=1
                if idx%10==0:
                    progress=dict(source=src['team_name'],opponent=target['team_name'],candidate=idx,wins=result['summary']['wins'],
                        combinations=completed,total_combinations=900,new_games_this_run=calculated,seconds=time.perf_counter()-tic)
                    write(out/'progress.json',progress);print(json.dumps(progress),flush=True)
            if srid!=trid:
                item=candidates[srid][-1];r=read(destination(out,srid,100,trid))
                for seat in (0,1):
                    trace=n.replay8(pool,route,f['config'],SEEDS[0],seat,DAYS,item['plan'],True)
                    assert trace['state_action_hash']==r['rows'][seat]['state_action_hash']
                    p=out/'official_by_source'/srid/trid/f'official_fixture_seat{seat}.json.gz'
                    p.parent.mkdir(parents=True,exist_ok=True);zipped(p,trace)
                    fixtures.append(dict(path=str(p.relative_to(out)),sha256=sha(p),source=srid,opponent=trid,seat=seat))
    assert completed==900 and len(fixtures)==12
    write(out/'run_done.json',dict(status='COMPLETE_28800_GAMES',files=files,fixtures=fixtures,seconds=time.perf_counter()-tic,
        games=28800,new_games=19200,reused_games=9600,new_games_this_run=calculated))

def official(out):
    f,n,pool,_,_=context(out);done=read(out/'run_done.json');assert done['status']=='COMPLETE_28800_GAMES'
    for r in done['fixtures']:assert sha(out/r['path'])==r['sha256']
    import audit
    combined=[];tic=time.perf_counter()
    for src in f['selected']:
        subset=dict(f,selected=[c for c in f['selected'] if c['route_id']!=src['route_id']])
        audit.runtime=lambda ignored:(subset,n,pool)
        p=out/'official_by_source'/src['route_id'];audit.official(p)
        report=read(p/'official.json');assert report['status']=='PASS_COMPLETE_STATE_AND_PYTHON_OPPONENT'
        combined.extend(dict(source=src['route_id'],**r) for r in report['rows'])
    assert len(combined)==12
    write(out/'official.json',dict(status='PASS_12_CROSS_GAMES',rows=combined,seconds=time.perf_counter()-tic))

def close(out):
    f,n,pool,candidates,_=context(out);done=read(out/'run_done.json');ref=read(out/'official.json')
    assert done['status']=='COMPLETE_28800_GAMES' and ref['status']=='PASS_12_CROSS_GAMES'
    for rel,h in done['files'].items():assert sha(out/rel)==h
    cases=f['selected'];rids=[c['route_id'] for c in cases];labels={c['route_id']:c['team_name'] for c in cases}
    plans=[];matrix=[];signatures=set();semantic=set();coverage={r:[False]*32 for r in rids}
    for src in cases:
        srid=src['route_id'];source_plans=[]
        for c in candidates[srid]:
            idx=c['selection_index'];results={r:read(destination(out,srid,idx,r)) for r in rids}
            scores={r:results[r]['summary'] for r in rids}
            allhash=tuple(v['state_action_hash'] for r in rids for v in results[r]['rows']);signatures.add(allhash)
            semantic.add(helper.key(c['plan']))
            for r in rids:
                for i,v in enumerate(results[r]['rows']):coverage[r][i]|=bool(v['win'])
            record=dict(uid=f'{srid}:{idx:03d}',source=srid,source_team=labels[srid],index=idx,plan_id=c['plan_id'],plan=c['plan'],opponents=scores,
                min_wins=min(x['wins'] for x in scores.values()),total_wins=sum(x['wins'] for x in scores.values()),
                mean_margin=sum(x['mean_margin'] for x in scores.values())/3,
                mean_cash=sum(x['mean_cash'] for x in scores.values())/3,
                missing_recipe=sum(x['missing_recipe'] for x in scores.values()))
            plans.append(record);source_plans.append(record)
        for r in rids:
            vals=[p['opponents'][r] for p in source_plans]
            matrix.append(dict(source=srid,opponent=r,mean_winrate=sum(v['wins'] for v in vals)/3200,max_wins=max(v['wins'] for v in vals),
                min_wins=min(v['wins'] for v in vals),plans_ge90=sum(v['wins']>=29 for v in vals),plans_all_wins=sum(v['wins']==32 for v in vals)))
    ranked=sorted(plans,key=lambda p:(p['min_wins'],p['total_wins'],p['mean_margin']),reverse=True)
    average=sorted(plans,key=lambda p:(p['total_wins'],p['min_wins'],p['mean_margin']),reverse=True)
    by_opponent={r:max(plans,key=lambda p:(p['opponents'][r]['wins'],p['opponents'][r]['mean_margin']))['uid'] for r in rids}
    summary=dict(status='COMPLETE_CROSS300_NOT_PROMOTION',plan_entries=300,semantic_unique=len(semantic),behavior_unique_96_worlds=len(signatures),
        games=28800,new_games=19200,reused_games=9600,official_games=12,matrix=matrix,
        best_balanced=ranked[0],best_overall=average[0],best_per_opponent=by_opponent,
        all_three_ge90=sum(p['min_wins']>=29 for p in plans),all_three_perfect=sum(p['min_wins']==32 for p in plans),
        retrospective_coverage={r:sum(v) for r,v in coverage.items()},test_seed_count=16,
        production_unchanged=True,online_router=False,old_goal_still_paused=True,seconds=done['seconds'])
    write(out/'summary.json',summary);write(out/'ranked300.json',ranked)
    with (HERE/'CROSS300.csv').open('w',newline='',encoding='utf-8-sig') as file:
        fields=['rank','uid','source_team','index','plan_id',*[labels[r]+'_wins32' for r in rids],
            *[labels[r]+'_mean_margin' for r in rids],'min_wins','total_wins','mean_margin','mean_cash','missing_recipe']
        writer=csv.DictWriter(file,fieldnames=fields);writer.writeheader()
        for rank,p in enumerate(ranked,1):
            row={k:p[k] for k in ('uid','source_team','index','plan_id','min_wins','total_wins','mean_margin','mean_cash','missing_recipe')}
            row['rank']=rank
            for r in rids:row[labels[r]+'_wins32']=p['opponents'][r]['wins'];row[labels[r]+'_mean_margin']=p['opponents'][r]['mean_margin']
            writer.writerow(row)
    lines=['# 300条冻结路线 × 三个对手交叉测试','',
        '2026-09-04。不重新搜索、不改路线、配置或控制器。Day0–28，每条路线对每个对手16个种子双座位32局。',
        '种子20264501–20264516沿用上一轮，未参加原4seed搜索；但本批用于筛选后不能再宣称是新一次独立认证。','',
        f"共28,800局，复用9,600，新增19,200；本轮计算及结果写入{done['seconds']:.1f}秒。12场跨来源官方逐步复核通过（不是28,800场官方复核）。",'',
        f"三者均≥90%（至少各29/32）：{summary['all_three_ge90']}/300；三者全胜：{summary['all_three_perfect']}/300。",'',
        '## 来源池的平均胜率','',
        '| 路线来源（各100条） | OceanMix | Driz Lo | QQ Farming |','| --- | ---: | ---: | ---: |']
    for src in cases:
        vals=[next(x for x in matrix if x['source']==src['route_id'] and x['opponent']==r) for r in rids]
        lines.append('| '+src['team_name']+' | '+' | '.join(f"{x['mean_winrate']:.2%}" for x in vals)+' |')
    lines+=['','这是100条路线的平均，不代表存在一条路线达到三个格子的平均。','',
        '## 单路线均衡排名前20','',
        '按最弱对手胜场、总胜场、平均分差排序；最高值为在本批选择的结果。','',
        '| 排名 | 来源/编号 | OceanMix | Driz Lo | QQ Farming | 总胜场/96 | 平均分差 |',
        '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
    for i,p in enumerate(ranked[:20],1):
        lines.append(f"| {i} | {p['source_team']} #{p['index']:03d} | "+' | '.join(f"{p['opponents'][r]['wins']}/32" for r in rids)+f" | {p['total_wins']}/96 | {p['mean_margin']:+,.0f} |")
    lines+=['','## 每个对手各自最佳（不是同一条通用路线）','',
        '| 对手 | 来源/编号 | 胜场 | 我方平均现金 | 对手平均现金 | 分差 |','| --- | --- | ---: | ---: | ---: | ---: |']
    for r in rids:
        p=next(x for x in plans if x['uid']==by_opponent[r]);s=p['opponents'][r]
        lines.append(f"| {labels[r]} | {p['source_team']} #{p['index']:03d} | {s['wins']}/32 | {s['mean_cash']:,.0f} | {s['mean_opponent_cash']:,.0f} | {s['mean_margin']:+,.0f} |")
    lines+=['','## 可信边界与结果入口','',
        f"300条来源条目中，规范参数计划{len(semantic)}种，96个世界上的完整状态/动作哈希签名{len(signatures)}种；不等同于独立经营家族。",'',
        '逐局事后任选一条赢家的覆盖：'+', '.join(f"{labels[r]} {summary['retrospective_coverage'][r]}/32" for r in rids)+'。这不是在线路由胜率。','',
        '对手为本地冻结的历史路线和已有修复，不代表作者最新完整Agent。每个对手只有16个独立随机seed，两座位配对。','',
        'missing_recipe是计划在真实状态下找不到可行候选而明确回退KEEP的节点数，不是偷偷换参数；完整记录在CSV和每局JSON中。','',
        '结果不晋级生产，不恢复旧Goal，没有训练或导出在线路由器。','',
        '- [全部300条对照CSV](CROSS300.csv)','- [排序与完整计划JSON](receipts_v1/ranked300.json)',
        '- [统计汇总](receipts_v1/summary.json)','- [输入与复用哈希](receipts_v1/inputs.json)','- [官方复核](receipts_v1/official.json)']
    (HERE/'RESULT_ZH.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
    write(out/'acceptance.json',dict(status=summary['status'],summary_sha256=sha(out/'summary.json'),ranked_sha256=sha(out/'ranked300.json'),
        report_sha256=sha(HERE/'RESULT_ZH.md'),csv_sha256=sha(HERE/'CROSS300.csv'),run_done_sha256=sha(out/'run_done.json'),
        official_sha256=sha(out/'official.json'),input_sha256=sha(out/'inputs.json')))
    print(json.dumps(dict(acceptance='PASS',best_balanced=summary['best_balanced']['uid'],
        wins=[summary['best_balanced']['opponents'][r]['wins'] for r in rids],all_three_ge90=summary['all_three_ge90'],
        new_games=19200,total_games=28800)),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['freeze','run','official','close']);parser.add_argument('--version',default='v1')
    args=parser.parse_args();out=HERE/('receipts_'+args.version)
    try:globals()[args.mode](out)
    except Exception as exc:
        if out.exists():write(out/f'failure_{args.mode}_{time.time_ns()}.json',dict(status='FAIL_PRESERVED',error=repr(exc)))
        raise
