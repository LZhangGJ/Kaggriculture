"""Render the completed frozen receipt, without changing policies or evaluation."""
from pathlib import Path
import gzip,json
HERE=Path(__file__).resolve().parent
OUT=HERE/'receipts_v1'
read=lambda p:json.loads(p.read_text())
a=read(OUT/'acceptance.json')
assert a['status']=='COMPLETE_DAILY29_DIVERSE20_PAIRED_NEW_SEEDS_NOT_PROMOTION'
v=read(OUT/'validation_done.json');selection=read(OUT/'selection_frozen.json')
rows=v['summary']
lines=['# Day0＋Day1–28每对手20条：与旧8节点的同种子复验','',
'日期：2026-09-04。仅使用已有获胜前沿，不重新搜索、不更改生产策略。每个原对手各20条新29节点路线，加上上一轮冻结的20条旧8节点路线，使用同一新种子库比较。','',
'## 1. 最重要的结果','',
'每条16个新seed×双座位，共32局。下面的最高是从这批新结果中筛选的最高，并非再经另一独立库验证的真实胜率。','',
'| 对手 | 8节点20条中最高 | 29节点20条中最高 | 8节点达到90%数量 | 29节点达到90%数量 | 29节点全胜数量 |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:
    e,d=r['arms']['EIGHT'],r['arms']['DAILY']
    lines.append(f"| {r['team']} | {e['max_wins']}/32 | {d['max_wins']}/32 | {e['plans_wins_ge_29']}/20 | {d['plans_wins_ge_29']}/20 | {d['plans_wins_eq_32']}/20 |")
lines+=['','本批结果：逐日路线池对Driz Lo有改善，QQ保留更多全胜路线；OceanMix仍未突破五成。不是所有对手的最高成绩都上升，也没有达成普遍90%。','',
'这是20264401–20264416全新库。不要直接把本表与上一报告20264301–20264316的结果相减；本轮已经将旧20条也在同一新库重跑，才是公平比较。','',
'## 2. 整个候选池与原冠军','',
'| 对手 | 来源 | 原冠军胜场 | 20条胜场范围 | 全池平均胜率 | 胜率高于原冠军的条数 | 新库不同实际轨迹签名 |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:
    for name in ('EIGHT','DAILY'):
        p=r['arms'][name]
        lines.append(f"| {r['team']} | {name} | {p['original_champion']['wins']}/32 | {p['min_wins']}–{p['max_wins']}/32 | {p['mean_winrate']:.2%} | {p['plans_better_than_original']}/20 | {p['new_set_distinct_behaviors']}/20 |")
lines+=['','同一seed下不同方案的结果、同一seed两个座位都相关，不能将候选×座位的全部局数当作同等数量的独立样本。','',
'## 3. 本批池内最优的资金','',
'同胜场时按平均分差取优。候选序号是冻结的选择顺序，不是路线排名。','',
'| 对手 | 来源 | 序号 | 胜场 | 平均我方现金 | 平均对手现金 | 平均分差 |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:
    for name in ('EIGHT','DAILY'):
        p=r['arms'][name]['best_on_this_new_set']
        lines.append(f"| {r['team']} | {name} | {p['index']:02d} | {p['wins']}/32 | {p['mean_cash']:,.0f} | {p['mean_opponent_cash']:,.0f} | {p['mean_margin']:+,.0f} |")
lines+=['','## 4. 20条完整胜场明细','',
'每格分母32；01为对应搜索的原冠军，其余不是按本轮结果排序。','',
'| 序号 | Ocean 8 | Ocean 29 | Driz 8 | Driz 29 | QQ 8 | QQ 29 |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for i in range(1,21):
    numbers=[]
    for r in rows:
        for arm in ('eight','daily'):
            numbers.append(str(read(OUT/r['route']/f'{arm}_{i:02d}_validation.json')['summary']['wins']))
    lines.append(f"| {i:02d} | "+' | '.join(numbers)+' |')
lines+=['','## 5. 这20条的多样性是否真实','',
'先限定原4训练seed×双座位8/8，再把前缀补KEEP并按语义去重。每组第1条保留原冠军，其余按日期、操作、产业和数量的最远优先抽取；只使用原训练分差打破距离并列。训练从头重放核对前沿结果，以8世界完整状态/动作hash去掉无效参数造成的重复。','',
'全部60条在读取新种子前冻结，不按新结果更换。旧8节点20条保持上一轮原名单，不按上一轮新库再挑选。','',
'| 对手 | 29节点源全胜参数方案 | 本次选定 | 训练行为去重 | 源前两天开局组合 | 选中前两天开局组合 |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
def opening(plan):return tuple((r['family'],r['kind'],r['amount']) for r in plan[:2])
for r in rows:
    s=read(OUT/r['route']/'selected20.json')
    with gzip.open(OUT/r['route']/'winning_frontier_catalog.json.gz','rt') as f:cat=json.load(f)
    lines.append(f"| {r['team']} | {s['semantic_win8_count']} | {len(s['candidates'])} | {len({tuple(c['behavior_signature']) for c in s['candidates']})}/20 | {len({opening(c['plan']) for c in cat})} | {len({opening(c['plan']) for c in s['candidates']})} |")
lines+=['','参数路线不同，不代表互不相关的策略家族。若某些方案在新库收敛为相同实际行为，已在第2节显示，未看到结果后换方案凑数。','',
'29节点仍是Beam4的已有前沿，未枚举全部组合。更大的时间空间不保证有限Beam选出的候选一定更好；也不能把本次20条的失败推广成全体可行路线都失败。','',
'## 6. 离线覆盖，不是在线胜率','',
'| 对手 | 8节点每局任选赢家 | 29节点每局任选赢家 | KEEP实际胜场 |',
'| --- | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['team']} | {r['arms']['EIGHT']['retrospective_any_winner_coverage']}/32 | {r['arms']['DAILY']['retrospective_any_winner_coverage']}/32 | {r['keep']['wins']}/32 |")
lines+=['','这里的任选赢家需要事后知道结果，仅用于描述本批候选池覆盖。没有实现一个能在真实对战正确选到赢家的路由器。','',
'## 7. 完成量、耗时和可信边界','',
f"- 60条29节点路线选择及原训练重放：{selection['seconds']:.1f}秒。每组20个训练行为签名不同，均8/8。",
f"- 新29路线1920局＋旧8路线1920局＋KEEP96局：共3936局；包含保存夹具约{v['seconds']:.1f}秒。",
'- C++、最多16线程，复用原冻结二进制，无新编译。上述是本次验证面板，不是搜索所有路线的时间。',
'- 预先指定每组29节点第20条、首个新seed双座位，共6完整局719步，官方1.32.7完整状态及Python对手动作核验全部通过。并非3936局都在官方Python里跑。',
'- 输入、生产源码、旧方案及注册表未改，原八对手Goal仍暂停，不推广或提交任何线上Agent。',
'- 对手只是原3条历史代表路线及本地既有修复执行，不是已覆盖全部153条或原作者全部动态策略。',
'', '## 8. 文件与复现','',
'入口`run_daily20.py`；依次`select → validate → official → close`，参数`--version v1`。本轮已完成，不需要重跑。',
'',
'- `receipts_v1/selection_frozen.json`：60条冻结名单哈希。',
'- 各对手目录`selected20.json`：新29节点完整计划、来源和训练重放。',
'- 各目录`daily_01_validation.json`至`daily_20_validation.json`：新29路线新种子逐局结果。',
'- 各目录`eight_01_validation.json`至`eight_20_validation.json`：旧8路线同一新库逐局结果。',
'- `receipts_v1/validation_done.json`、`official.json`、`acceptance.json`：汇总和验收。',
'',
'所有最佳和失败方案都保留。若下一轮根据本库挑选、改参数或改候选生成，本库即成为开发/选型证据，需要另一未用种子库做最终复验。','']
(HERE/'RESULT_ZH.md').write_text('\n'.join(lines),encoding='utf8')
print('REPORT WRITTEN',HERE/'RESULT_ZH.md')
