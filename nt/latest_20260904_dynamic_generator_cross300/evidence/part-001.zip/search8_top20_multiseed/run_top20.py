"""Frozen 8-node frontier diversity sampling and fresh-seed evaluation. No search."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse, gzip, hashlib, json, sys, time

HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'search8_multiseed'
sys.path.insert(0,str(OLD))
import run as old
read,write,sha,zipped=old.read,old.write,old.sha,old.zipped
DAYS=old.DAYS
VALID=list(range(20264301,20264317))
COUNT=20

def canonical(plan):
    return list(plan)+[dict(old.KEEP) for _ in range(len(DAYS)-len(plan))]

def key(plan):return tuple((r['family'],r['kind'],r['amount']) for r in canonical(plan))

def plan_id(plan):return hashlib.sha256(json.dumps(key(plan),separators=(',',':')).encode()).hexdigest()[:16]

def distance(a,b):
    # Fixed diversity heuristic, never a utility or validation score.
    return sum(2*(x[0]!=y[0])+(x[1]!=y[1])+0.5*abs(x[2]-y[2])/max(1,abs(x[2]),abs(y[2])) for x,y in zip(a,b))

def context(out,create=False):
    f,n,pool=old.runtime(OLD/'receipts_v1')
    assert read(OLD/'receipts_v1/acceptance.json')['status']=='COMPLETE_8_NODE_MULTISEED_PILOT_NOT_PROMOTION'
    files=[p for case in f['selected'] for p in (OLD/'receipts_v1'/case['route_id']).glob('stage*.json.gz')]
    files += [OLD/'receipts_v1'/case['route_id']/'policy.json' for case in f['selected']]
    frozen=dict(schema='search8-diverse20-v1',days=DAYS,count=COUNT,train=old.TRAIN,validation=VALID,seats=[0,1],
        config=f['config'],selected=f['selected'],route_ids=f['route_ids'],source_script_sha256=sha(__file__),plan_document_sha256=sha(HERE/'PLAN_ZH.md'),
        source_inputs_sha256=sha(OLD/'receipts_v1/inputs.json'),binary_sha256=read(OLD/'receipts_v1/build.json')['binary_sha256'],
        frontiers={str(p.relative_to(OLD)):sha(p) for p in files})
    assert not set(VALID)&set(old.TRAIN+old.VALID+list(range(20264201,20264217)))
    if create:out.mkdir(exist_ok=False);write(out/'inputs.json',frozen)
    else:assert read(out/'inputs.json')==frozen,'Frozen inputs changed'
    return frozen,n,pool

def evaluate(n,pool,f,route,plan,seeds):
    jobs=[(s,p) for s in seeds for p in (0,1)]
    def one(job):
        r=n.replay8(pool,route,f['config'],job[0],job[1],DAYS,plan,False)
        assert r['steps']==719
        return r
    with ThreadPoolExecutor(max_workers=16) as workers:return list(workers.map(one,jobs))

def select(out):
    f,n,pool=context(out,not out.exists());all_selected=[];start=time.perf_counter()
    for case in f['selected']:
        target=out/case['route_id'];dest=target/'selected20.json'
        if dest.exists():all_selected.append(dict(route=case['route_id'],sha256=sha(dest)));continue
        target.mkdir(exist_ok=True);catalog={};evaluated=0
        for path in sorted((OLD/'receipts_v1'/case['route_id']).glob('stage*.json.gz')):
            with gzip.open(path,'rt') as file:stage=json.load(file)
            for row in stage['frontier']:
                evaluated+=1
                if row['wins']!=8:continue
                k=key(row['plan']);item=dict(row,plan=canonical(row['plan']),origin=path.name,depth=len(row['plan']),plan_id=plan_id(row['plan']))
                if k in catalog:
                    for name in ('wins','mean_margin','mean_cash'):assert catalog[k][name]==item[name],('Duplicate KEEP suffix differs',name)
                else:catalog[k]=item
        assert len(catalog)>=COUNT,'Insufficient distinct semantic winners'
        zipped(target/'winning_frontier_catalog.json.gz',list(catalog.values()))
        prior=read(OLD/'receipts_v1'/case['route_id']/'policy.json')['plan'];first=key(prior)
        assert first in catalog
        chosen=[];seen=set();rejected=[];attempts=[];route=f['route_ids'].index(case['route_id']);remaining=dict(catalog)
        while len(chosen)<COUNT and remaining:
            if not chosen:k=first
            else:k=max(remaining,key=lambda x:(min(distance(x,key(c['plan'])) for c in chosen),remaining[x]['mean_margin'],remaining[x]['mean_cash'],x))
            item=remaining.pop(k);rows=evaluate(n,pool,f,route,item['plan'],old.TRAIN);stats=old.stats(rows)
            assert stats['wins']==8
            for name in ('mean_margin','mean_cash'):assert stats[name]==item[name],('Full replay mismatch',name,stats,item)
            signature=tuple(r['state_action_hash'] for r in rows)
            duplicate=signature in seen
            record=dict(item,training=stats,training_rows=rows,behavior_signature=list(signature),duplicate_behavior=duplicate)
            attempts.append(record)
            if duplicate:rejected.append(item['plan_id']);continue
            seen.add(signature);record['selection_index']=len(chosen)+1;chosen.append(record)
            write(target/'selection_progress.json',dict(accepted=len(chosen),attempted=len(attempts),behavior_duplicates=len(rejected)))
            print(json.dumps(dict(select=case['route_id'],accepted=len(chosen),attempted=len(attempts),train_wins=8)),flush=True)
        zipped(target/'selection_attempts.json.gz',attempts)
        assert len(chosen)==COUNT,'Insufficient distinct actual behavior; preserve failure'
        selected=dict(status='FROZEN_BEFORE_NEW_SEEDS',case=case,frontier_evaluations=evaluated,semantic_win8_count=len(catalog),
            attempted=len(attempts),behavior_duplicate_count=len(rejected),candidates=chosen)
        write(dest,selected);all_selected.append(dict(route=case['route_id'],sha256=sha(dest)))
    write(out/'selection_frozen.json',dict(status='ALL_60_FROZEN',routes=all_selected,seconds=time.perf_counter()-start))

def validate(out):
    f,n,pool=context(out);frozen=read(out/'selection_frozen.json');assert frozen['status']=='ALL_60_FROZEN'
    for ref in frozen['routes']:assert sha(out/ref['route']/'selected20.json')==ref['sha256']
    summaries=[];start=time.perf_counter()
    for case in f['selected']:
        target=out/case['route_id'];sel=read(target/'selected20.json');route=f['route_ids'].index(case['route_id'])
        basefile=target/'keep_validation.json'
        if basefile.exists():base=read(basefile)
        else:
            rows=evaluate(n,pool,f,route,[old.KEEP]*8,VALID);base=dict(summary=old.stats(rows),rows=rows);write(basefile,base)
        plans=[]
        for item in sel['candidates']:
            dest=target/f"candidate_{item['selection_index']:02d}_validation.json"
            if dest.exists():result=read(dest)
            else:
                rows=evaluate(n,pool,f,route,item['plan'],VALID)
                result=dict(plan_id=item['plan_id'],selection_index=item['selection_index'],plan=item['plan'],summary=old.stats(rows),rows=rows)
                write(dest,result)
            assert result['plan_id']==item['plan_id']
            plans.append(result)
            print(json.dumps(dict(validation=case['team_name'],candidate=item['selection_index'],wins=result['summary']['wins'],games=32,mean_margin=result['summary']['mean_margin'])),flush=True)
        best=max(plans,key=lambda r:(r['summary']['wins'],r['summary']['mean_margin']))
        oldchamp=plans[0]
        union=sum(any(p['rows'][i]['win'] for p in plans) for i in range(32))
        summary=dict(route=case['route_id'],team=case['team_name'],candidates=COUNT,keep=base['summary'],
            original_champion=oldchamp['summary'],best_on_this_new_set=dict(index=best['selection_index'],**best['summary']),
            min_wins=min(p['summary']['wins'] for p in plans),max_wins=max(p['summary']['wins'] for p in plans),
            mean_winrate=sum(p['summary']['wins'] for p in plans)/(32*COUNT),
            plans_wins_ge_16=sum(p['summary']['wins']>=16 for p in plans),plans_wins_ge_24=sum(p['summary']['wins']>=24 for p in plans),
            plans_wins_ge_29=sum(p['summary']['wins']>=29 for p in plans),plans_wins_eq_32=sum(p['summary']['wins']==32 for p in plans),
            plans_better_than_original=sum(p['summary']['wins']>oldchamp['summary']['wins'] for p in plans),
            retrospective_any_winner_coverage=union,coverage_games=32)
        write(target/'summary.json',summary);summaries.append(summary)
        # Predeclared candidate 20, not validation champion.
        item=sel['candidates'][-1]
        for seat in (0,1):
            fixture=n.replay8(pool,route,f['config'],VALID[0],seat,DAYS,item['plan'],True)
            ref=plans[-1]['rows'][seat];assert fixture['state_action_hash']==ref['state_action_hash']
            zipped(target/f'official_fixture_seat{seat}.json.gz',fixture)
    write(out/'validation_done.json',dict(status='ALL_2016_NEW_SEED_GAMES_COMPLETE',summary=summaries,seconds=time.perf_counter()-start))

def official(out):
    context(out)
    import audit
    audit.runtime=lambda ignored:context(out)
    audit.official(out)

def close(out):
    f,n,pool=context(out);v=read(out/'validation_done.json');o=read(out/'official.json')
    assert o['status']=='PASS_COMPLETE_STATE_AND_PYTHON_OPPONENT' and len(o['rows'])==6
    for case in f['selected']:
        s=read(out/case['route_id']/'selected20.json');assert len(s['candidates'])==COUNT
        assert len({tuple(c['behavior_signature']) for c in s['candidates']})==COUNT
    write(out/'acceptance.json',dict(status='COMPLETE_60_FROZEN_CANDIDATES_NEW_SEEDS_NOT_PROMOTION',summary=v['summary'],
        candidates=60,independent_new_seeds=16,seats=[0,1],candidate_games=1920,keep_games=96,official_games=6,
        production_unchanged=True,old_goal_still_paused=True,online_router=False,
        caveat='20 training-distinct parameter trajectories per target, not 20 unrelated strategy families; new-set ranking is selection, not further independent certification.',
        files={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file() and p.name!='acceptance.json'}))
    print(json.dumps(dict(acceptance='PASS',summary=v['summary'])),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['select','validate','official','close']);p.add_argument('--version',default='v1');a=p.parse_args();out=HERE/('receipts_'+a.version)
    try:globals()[a.mode](out)
    except Exception as exc:
        if out.exists():write(out/f'failure_{a.mode}_{time.time_ns()}.json',dict(status='FAIL_PRESERVED',error=repr(exc)))
        raise
