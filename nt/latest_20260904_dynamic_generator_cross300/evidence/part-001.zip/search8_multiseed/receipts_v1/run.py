"""Bounded, isolated common-plan beam search. Run using the existing WSL venv."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse, gzip, hashlib, json, os, shutil, subprocess, sys, sysconfig, time, zlib

HERE=Path(__file__).resolve().parent
EXP=HERE.parent
ROOT=EXP.parents[1]
DATA=Path('/mnt/d/kaggriculture_replay/top60_daily_20260901/candidate8_winning_path_v1')
TEAM=ROOT/'research/team_mate/Kaggriculture_main_512631c/agents/route_clustering_switch_agent'
DAYS=[0,1,3,6,9,12,18,24]
KEEP=dict(family='KEEP',kind=-1,amount=0)
TRAIN=list(range(20264001,20264005))
VALID=list(range(20264101,20264117))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,d):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(d,ensure_ascii=False,indent=2));os.replace(temp,p)
def zipped(p,d):
    with gzip.open(p,'wt',encoding='utf8',compresslevel=1) as f:json.dump(d,f,separators=(',',':'))
def inputs(out):
    build=read(EXP/'native/build/build_receipt.json')
    for rel,h in build['source_hashes'].items():assert sha(EXP/rel)==h,(rel,'production hash')
    actions_path=DATA/'top60_nondynamic_family_actions.json.zlib'
    meta_path=DATA/'top60_nondynamic_route_library.json'
    cases_path=DATA/'top60_nondynamic_candidate8_cases.json'
    meta=read(meta_path);cases=read(cases_path)['cases']
    assert len(cases)==153 and sha(actions_path)==meta['actions_sha256'].lower()
    selected=[next(c for c in cases if c['rank']==r) for r in (2,3,5)]
    source=TEAM/'runtime/teammate_base.py'
    sys.path.insert(0,str(TEAM/'src'))
    from meta_agent.src.teammate_expanded_routes import TeammateExpandedRouteAgent
    actions=json.loads(zlib.decompress(actions_path.read_bytes()))
    probe=TeammateExpandedRouteAgent(source.read_text(),actions,'search8_asset_unpack_only')
    k320=probe.namespace['_BASE'].__dict__['_K320'].__dict__
    moon=probe.namespace['_MOON'].__dict__
    labels=['10C4S_3Q','8C6S_3Q','6C8S_3Q','6C12S_4Q_FIRST_YARN','6C12S_4Q_SECOND_YARN']
    market=lambda xs:[dict(farmer=['PASS'],hands=[],market=list(v or [])) for v in xs]
    route_ids=[e['route_id'] for e in meta['opponent_routes']]
    payload=dict(opening=0,nodes=[],routes=[actions[k] for k in route_ids],raw_passthrough=meta.get('raw_passthrough',False),
        r5=market(k320['_V17_R5_MARKETS']),md=market(k320['_V17_MD_MARKETS']),
        moon={i:moon['_ACTIONS_'+v] for i,v in enumerate(labels)},moon_legacy={i:moon['_LEGACY_ACTIONS_'+v] for i,v in enumerate(labels)})
    config=read(EXP/'profiles/s5d_bounded_v2/configs.json')['all_intraday_insert']
    frozen=dict(production=build,config=config,days=DAYS,width=4,train_seeds=TRAIN,validation_seeds=VALID,seats=[0,1],selected=selected,
        pool_count=153,competitive_count=152,raw_passthrough=payload['raw_passthrough'],route_ids=route_ids,
        inputs={str(p):sha(p) for p in (source,actions_path,meta_path,cases_path,EXP/'profiles/s5d_bounded_v2/configs.json')},
        search_source=sha(HERE/'search.cpp'),runner_source=sha(__file__))
    fp=out/'inputs.json'
    if fp.exists():assert read(fp)==frozen,'frozen experiment inputs changed; use a new version'
    else:write(fp,frozen)
    return frozen,payload
def build(out):
    out.mkdir(exist_ok=False)
    frozen,_=inputs(out)
    for p in (HERE/'search.cpp',HERE/'run.py',HERE/'PLAN_ZH.md'):shutil.copy2(p,out/p.name)
    native=EXP/'native/build'
    # Freeze exact production source and linked object provenance; no mutation.
    for rel in frozen['production']['source_hashes']:
        dest=out/'source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(EXP/rel,dest)
    objects=sorted(p for p in native.glob('*.o') if p.name!='module.o')
    import pybind11
    binary=out/('_dp7_search8'+sysconfig.get_config_var('EXT_SUFFIX'))
    cmd=['g++','-std=c++20','-O3','-DNDEBUG','-march=native','-fopenmp','-fPIC','-shared',
         '-I'+pybind11.get_include(),'-I'+sysconfig.get_paths()['include'],'-I'+str(EXP/'native'),
         str(HERE/'search.cpp'),*[str(p) for p in objects],'-o',str(binary)]
    tic=time.perf_counter();p=subprocess.run(cmd,capture_output=True,text=True)
    (out/'compile.log').write_text(p.stdout+p.stderr)
    write(out/'build.json',dict(status='PASS' if p.returncode==0 else 'FAIL_PRESERVED',returncode=p.returncode,seconds=time.perf_counter()-tic,
        command=cmd,objects={str(p):sha(p) for p in objects},binary_sha256=sha(binary) if binary.exists() else None))
    if p.returncode:raise RuntimeError(p.stderr[-8000:])
    print(json.dumps(dict(build='PASS',seconds=time.perf_counter()-tic)),flush=True)
def runtime(out):
    frozen,payload=inputs(out);receipt=read(out/'build.json');assert receipt['status']=='PASS'
    binaries=list(out.glob('_dp7_search8*.so'));assert len(binaries)==1 and sha(binaries[0])==receipt['binary_sha256']
    sys.path.insert(0,str(out));import _dp7_search8 as n
    return frozen,n,n.RoutePool(payload)
def compact(row):return {k:v for k,v in row.items() if k not in ('trace','cash_by_step','node_effects')}
def mechanism(out):
    f,n,pool=runtime(out);checks=[]
    for case in f['selected']:
        route=f['route_ids'].index(case['route_id'])
        for seed in TRAIN[:2]:
            for seat in (0,1):
                a=n.replay8(pool,route,f['config'],seed,seat,[],[],False)
                b=n.replay8(pool,route,f['config'],seed,seat,DAYS,[KEEP]*8,False)
                assert a['state_action_hash']==b['state_action_hash'],(case['route_id'],seed,seat,'KEEP differs')
                assert a['steps']==b['steps']==719
                checks.append(dict(route=case['route_id'],seed=seed,seat=seat,hash=a['state_action_hash'],cash=a['cash'],opponent_cash=a['opponent_cash']))
    # Small real two-world branch search and exact common-plan replay.
    route=f['route_ids'].index(f['selected'][0]['route_id'])
    engine=n.Search8(pool,route,f['config'],[TRAIN[0]]*2,[0,1],DAYS,2,16)
    stats=engine.expand();plan=stats['beam'][0]['plan'];replays=[]
    for seat in (0,1):
        result=n.replay8(pool,route,f['config'],TRAIN[0],seat,DAYS[:1],plan,False)
        expected=stats['beam'][0]['outcomes'][seat]
        for key in ('cash','opponent_cash','missing_recipe','changed_nodes'):assert result[key]==expected[key],(key,result,expected)
        replays.append(compact(result))
    write(out/'mechanism.json',dict(status='PASS_KEEP_AND_COMMON_PLAN_REPLAY',checks=checks,branch=stats,replays=replays))
    print(json.dumps(dict(mechanism='PASS',keep_games=len(checks),day0_candidates=stats['proposals'],seconds=stats['seconds'])),flush=True)
def search(out):
    f,n,pool=runtime(out);assert read(out/'mechanism.json')['status']=='PASS_KEEP_AND_COMMON_PLAN_REPLAY'
    seeds=[s for s in TRAIN for _ in (0,1)];seats=[p for _ in TRAIN for p in (0,1)]
    started=time.perf_counter()
    for case in f['selected']:
        target=out/case['route_id'];target.mkdir(exist_ok=True)
        if (target/'selected.json').exists():continue
        if any(target.glob('stage*.json.gz')):raise RuntimeError('partial stage evidence exists; preserve and use a new version')
        route=f['route_ids'].index(case['route_id']);tic=time.perf_counter()
        engine=n.Search8(pool,route,f['config'],seeds,seats,DAYS,4,16)
        for depth in range(8):
            stats=engine.expand();zipped(target/f'stage{depth}.json.gz',stats)
            best=stats['beam'][0]['outcomes']
            progress=dict(route=case['route_id'],depth=depth+1,day=stats['day'],proposals=stats['proposals'],suffixes=stats['suffixes'],seconds=stats['seconds'],
                wins=sum(r['win'] for r in best),mean_margin=sum(r['margin'] for r in best)/len(best),total_suffixes=stats['total_suffixes'])
            write(out/'progress.json',progress);print(json.dumps(progress),flush=True)
        selected=engine.state();selected['case']=case;selected['seconds']=time.perf_counter()-tic;write(target/'selected.json',selected)
        # Selection is closed before accessing any validation seed.
        policy=dict(schema='search8-common-semantic-plan-v1',base_config=f['config'],days=DAYS,plan=selected['beam'][0]['plan'],
                    missing_candidate='KEEP_WITH_EXPLICIT_REASON',scope='current_day_new_projects_with_stateful_continuation')
        write(target/'policy.json',policy)
    write(out/'search_done.json',dict(status='SEARCH_COMPLETE_NOT_VALIDATION',seconds=time.perf_counter()-started,routes=len(f['selected'])))
def stats(rows):
    return dict(games=len(rows),wins=sum(r['win'] for r in rows),ties=sum(r['cash']==r['opponent_cash'] for r in rows),
                mean_cash=sum(r['cash'] for r in rows)/len(rows),mean_opponent_cash=sum(r['opponent_cash'] for r in rows)/len(rows),
                mean_margin=sum(r['margin'] for r in rows)/len(rows),missing_recipe=sum(r['missing_recipe'] for r in rows))
def validate(out):
    f,n,pool=runtime(out);assert (out/'search_done.json').exists();started=time.perf_counter();summaries=[]
    # Preserve all finalists. Only the preselected top1 is the target's reported winner.
    for case in f['selected']:
        target=out/case['route_id'];dest=target/'validation.json'
        if dest.exists():summaries.append(read(dest)['summary']);continue
        selected=read(target/'selected.json');plan=read(target/'policy.json')['plan'];route=f['route_ids'].index(case['route_id'])
        train=[]
        for ref in selected['beam'][0]['outcomes']:
            row=n.replay8(pool,route,f['config'],ref['seed'],ref['seat'],DAYS,plan,False)
            for key in ('cash','opponent_cash','missing_recipe','changed_nodes'):assert row[key]==ref[key],('full reexecution differs',key,row,ref)
            train.append(row)
        jobs=[(s,p,arm) for s in VALID for p in (0,1) for arm in ('KEEP','SELECTED')]
        def run(job):
            seed,seat,arm=job;r=n.replay8(pool,route,f['config'],seed,seat,DAYS,plan if arm=='SELECTED' else [KEEP]*8,False)
            assert r['steps']==719;r['arm']=arm;return r
        tic=time.perf_counter()
        with ThreadPoolExecutor(max_workers=16) as workers:rows=list(workers.map(run,jobs))
        base=[r for r in rows if r['arm']=='KEEP'];chosen=[r for r in rows if r['arm']=='SELECTED']
        summary=dict(route=case['route_id'],team=case['team_name'],train_keep=stats(selected['baseline']),train_selected=stats(train),
                     validation_keep=stats(base),validation_selected=stats(chosen),seconds=time.perf_counter()-tic)
        write(dest,dict(status='COMPLETE_FROZEN_POLICY_HOLDOUT',policy_sha256=sha(target/'policy.json'),summary=summary,train_replays=train,rows=rows))
        # First holdout seed and both seats are predetermined official fixtures.
        for seat in (0,1):
            trace=n.replay8(pool,route,f['config'],VALID[0],seat,DAYS,plan,True)
            zipped(target/f'official_fixture_seat{seat}.json.gz',trace)
        summaries.append(summary);print(json.dumps(summary),flush=True)
    # Crossplay of frozen choices, no validation-based re-selection.
    cross=[]
    for source in f['selected']:
        plan=read(out/source['route_id']/'policy.json')['plan']
        for case in f['selected']:
            if case['route_id']==source['route_id']:continue
            route=f['route_ids'].index(case['route_id']);jobs=[(s,p) for s in VALID for p in (0,1)]
            def run(job):return n.replay8(pool,route,f['config'],job[0],job[1],DAYS,plan,False)
            with ThreadPoolExecutor(max_workers=16) as workers:rows=list(workers.map(run,jobs))
            cross.append(dict(source=source['route_id'],opponent=case['route_id'],summary=stats(rows),rows=rows))
    write(out/'validation_done.json',dict(status='COMPLETE_PILOT_NOT_153_COVERAGE',summary=summaries,cross=cross,seconds=time.perf_counter()-started))
def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['build','mechanism','search','validate']);p.add_argument('--version',default='v1');a=p.parse_args()
    out=HERE/('receipts_'+a.version)
    try:globals()[a.mode](out)
    except Exception as exc:
        if out.exists():write(out/f'failure_{a.mode}_{time.time_ns()}.json',dict(status='FAIL_PRESERVED',error=repr(exc)))
        raise
if __name__=='__main__':main()
