"""Close only the bounded trial, never promote or complete the paused goal."""
import argparse, gzip, json
from run import HERE, EXP, DAYS, TRAIN, VALID, read, write, sha

p=argparse.ArgumentParser();p.add_argument('--version',default='v1');a=p.parse_args()
out=HERE/('receipts_'+a.version)
f=read(out/'inputs.json');done=read(out/'validation_done.json');official=read(out/'official.json')
assert not set(TRAIN)&set(VALID)
assert len(f['selected'])==3 and read(out/'isolation.json')['status']=='PASS'
assert official['status']=='PASS_COMPLETE_STATE_AND_PYTHON_OPPONENT' and len(official['rows'])==6
current=read(EXP/'native/build/build_receipt.json');assert current==f['production']
for rel,h in current['source_hashes'].items():assert sha(EXP/rel)==h
total_suffixes=total_steps=0;qualified=[];files={};missing=[]
for case in f['selected']:
    target=out/case['route_id'];selected=read(target/'selected.json');policy=read(target/'policy.json');validation=read(target/'validation.json')
    assert selected['depth']==8 and policy['days']==DAYS and len(policy['plan'])==8
    assert sha(target/'policy.json')==validation['policy_sha256']
    assert all(set(move)=={'family','kind','amount'} for move in policy['plan'])
    assert len(validation['rows'])==64
    total_suffixes+=selected['total_suffixes'];total_steps+=selected['total_transitions']
    summary=validation['summary'];metric=summary['validation_selected']
    if metric['wins']==metric['games']:qualified.append(case['route_id'])
    chosen=[r for r in validation['rows'] if r['arm']=='SELECTED']
    missing.append(dict(route=case['route_id'],by_day={str(d):sum(entry[1] for r in chosen for entry in r['node_effects'] if entry[0]==d) for d in DAYS}))
    for path in target.iterdir():
        if path.is_file():files[str(path.relative_to(out))]=sha(path)
    for depth in range(8):
        with gzip.open(target/f'stage{depth}.json.gz','rt') as file:stage=json.load(file)
        assert stage['depth']==depth+1 and stage['day']==DAYS[depth]
for path in (out/'inputs.json',out/'build.json',out/'mechanism.json',out/'isolation.json',out/'official.json',out/'validation_done.json',HERE/'audit.py',HERE/'close.py'):
    files[str(path)]=sha(path)
receipt=dict(status='COMPLETE_8_NODE_MULTISEED_PILOT_NOT_PROMOTION',selected_opponents=3,pool_size=153,competitive_pool_size=152,
    days=DAYS,beam_width=4,train_independent_seeds=4,validation_independent_seeds=16,paired_seats=True,
    search_seconds=read(out/'search_done.json')['seconds'],total_suffixes=total_suffixes,total_environment_transitions=total_steps,
    holdout_target_games=96,holdout_keep_games=96,holdout_cross_games=192,official_games=6,
    all_win_holdout_specialists=qualified,summary=done['summary'],missing=missing,
    production_unchanged=True,old_goal_still_paused=True,goal_complete=False,online_router=False,
    files=files,caveats=['Multi-seed common-plan selection is not an all-seed proof.',
       'Two selected plans regress out of sample; do not promote their training victories.',
       'One specialist passes 32/32 on 16 paired seed clusters; not a validated 90% population guarantee.',
       'Missing semantic moves use explicit KEEP; their relation to losses is diagnostic, not causally isolated.',
       'Pool is fixed routes with historical overlays, not original authors complete dynamic agents.',
       'Search handles only existing new-project candidate grammar; not full old Candidate8 action space.'])
write(out/'acceptance.json',receipt)
print(json.dumps({k:v for k,v in receipt.items() if k not in ('files','summary','missing','caveats')},ensure_ascii=False,indent=2))
