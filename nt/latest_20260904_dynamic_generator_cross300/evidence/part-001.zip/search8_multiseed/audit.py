"""Extra isolation checks and official referee for frozen search8 outputs."""
import argparse, copy, gzip, json, sys, time, zlib
from run import HERE, EXP, ROOT, TEAM, DATA, DAYS, KEEP, TRAIN, runtime, read, write, sha

def normalize(a):
    def atom(x):
        if x[0] in ('PICKUP','PLACE'):return x[:2]+[x[2] if len(x)>2 else 1]
        if x[0] in ('BUY_PRODUCT','BUY_ANIMAL','BUY_SEED','SELL'):return x[:3]
        if x[0]=='PLANT':return x[:2]
        return x[:1]
    return dict(farmer=atom(a.get('farmer',['PASS'])),hands=[atom(x) for x in a.get('hands',[])],market=[atom(x) for x in a.get('market',[])])
def canon(a):return json.loads(json.dumps(a))
def isolation(out):
    f,n,pool=runtime(out);route=f['route_ids'].index(f['selected'][0]['route_id'])
    args=([TRAIN[0],TRAIN[1],TRAIN[0],TRAIN[1]],[0,0,1,1])
    a=n.Search8(pool,route,f['config'],*args,DAYS,2,1).expand()
    b=n.Search8(pool,route,f['config'],args[0][::-1],args[1][::-1],DAYS,2,16).expand()
    assert [(r['plan'],r['wins'],r['mean_margin'],r['mean_cash']) for r in a['frontier']]==[(r['plan'],r['wins'],r['mean_margin'],r['mean_cash']) for r in b['frontier']]
    assert a['beam'][0]['outcomes']==b['beam'][0]['outcomes'][::-1]
    # Current production receipt compared against the isolated reused bridge.
    panel=read(EXP/'receipts/s5d_twelveway_N10_v1/results.json')
    payload=json.loads(zlib.decompress((EXP/'native/g001_frozen.json.zlib').read_bytes()))
    g=n.G001(payload);actual=n.batch([20262701,20262701],[0,1],f['config'],g,2)
    refs=[r for r in panel['rows'] if r['variant']=='all_intraday_insert' and r['opponent']=='g001' and r['seed']==20262701]
    for r in actual:
        ref=next(x for x in refs if x['seat']==r['seat'])
        for key in ('cash','opponent_cash'):assert r[key]==ref[key],(key,r,ref)
    write(out/'isolation.json',dict(status='PASS',reverse_world_order=True,serial_parallel_same_frontier=True,production_reference_games=len(actual),candidates=a['proposals']))
def official(out):
    f,n,pool=runtime(out)
    sys.path.insert(0,str(ROOT/'gpt_review/codex/G001_CPU_FOR_GPT_20260903'))
    from cpu_runtime import LocalGame
    from meta_agent.src.teammate_expanded_routes import TeammateExpandedRouteAgent
    source=(TEAM/'runtime/teammate_base.py').read_text()
    actions=json.loads(zlib.decompress((DATA/'top60_nondynamic_family_actions.json.zlib').read_bytes()))
    started=time.perf_counter();rows=[]
    for case in f['selected']:
        target=out/case['route_id']
        for seat in (0,1):
            path=target/f'official_fixture_seat{seat}.json.gz'
            with gzip.open(path,'rt') as file:fixture=json.load(file)
            env=n.Env(fixture['seed']);official=LocalGame(fixture['seed'])
            rival=TeammateExpandedRouteAgent(source,actions,'s8_official_'+str(time.time_ns()));rival.select(case['route_id'])
            try:
                for step,pair in enumerate(fixture['trace']):
                    expected=rival(official.observation(1-seat),copy.deepcopy(official.configuration))
                    assert normalize(expected)==normalize(pair[1-seat]),('opponent_action',step,expected,pair[1-seat])
                    env.step(pair);official.advance(pair)
                    for player in (0,1):
                        actual=canon(env.observation(player));ref=canon(official.observation(player))
                        for key in ('farms','private','market','town'):
                            assert actual[key]==ref[key],('official_state',step,player,key)
                    assert [x['money'] for x in actual['farms']]==fixture['cash_by_step'][step]
                assert env.done and official.done and env.step_count==719
            except Exception as exc:
                write(out/'official_failure.json',dict(route=case['route_id'],seed=fixture['seed'],seat=seat,step=step,error=repr(exc)))
                raise
            rows.append(dict(route=case['route_id'],seed=fixture['seed'],seat=seat,steps=719,fixture_sha256=sha(path)))
            print(json.dumps(dict(official='PASS',**rows[-1])),flush=True)
    write(out/'official.json',dict(status='PASS_COMPLETE_STATE_AND_PYTHON_OPPONENT',rows=rows,seconds=time.perf_counter()-started,
          engine_sha256=sha(ROOT/'gpt_review/codex/G001_CPU_FOR_GPT_20260903/official/kaggriculture.py'),
          caveat='Frozen official interpreter referee, not Kaggle schema/time sandbox acceptance. Candidate Python export not implemented.'))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['isolation','official']);p.add_argument('--version',default='v1');a=p.parse_args()
    globals()[a.mode](HERE/('receipts_'+a.version))
