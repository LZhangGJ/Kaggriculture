"""Day0+1..28 common-plan beam; reuse the frozen 8-node binary unchanged."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse,copy,gzip,json,sys,time,zlib
HERE=Path(__file__).resolve().parent
EXP=HERE.parent
OLD=EXP/'search8_multiseed'
sys.path.insert(0,str(OLD))
import run as old
DAYS=list(range(29))
VALID=list(range(20264201,20264217))
KEEP=old.KEEP
read,write,sha,zipped=old.read,old.write,old.sha,old.zipped

def context(out,create=False):
    f,n,pool=old.runtime(OLD/'receipts_v1')
    assert read(OLD/'receipts_v1/acceptance.json')['status']=='COMPLETE_8_NODE_MULTISEED_PILOT_NOT_PROMOTION'
    frozen=dict(schema='daily29-common-plan-pilot-v1',days=DAYS,width=4,train_seeds=old.TRAIN,validation_seeds=VALID,seats=[0,1],
        source_inputs_sha256=sha(OLD/'receipts_v1/inputs.json'),binary_sha256=read(OLD/'receipts_v1/build.json')['binary_sha256'],
        config=f['config'],selected=f['selected'],route_ids=f['route_ids'],source_script_sha256=sha(__file__),
        old_policy_hashes={c['route_id']:sha(OLD/'receipts_v1'/c['route_id']/'policy.json') for c in f['selected']})
    if create:out.mkdir(exist_ok=False);write(out/'inputs.json',frozen)
    else:assert read(out/'inputs.json')==frozen,'immutable inputs changed'
    return frozen,n,pool
def old_policy(route):return read(OLD/'receipts_v1'/route/'policy.json')
def check(out):
    f,n,pool=context(out,True);rows=[]
    for case in f['selected']:
        route=f['route_ids'].index(case['route_id']);p=old_policy(case['route_id']);moves=dict(zip(p['days'],p['plan']))
        padded=[moves.get(d,KEEP) for d in DAYS]
        for seed in old.TRAIN[:2]:
            for seat in (0,1):
                bare=n.replay8(pool,route,f['config'],seed,seat,[],[],False)
                keep=n.replay8(pool,route,f['config'],seed,seat,DAYS,[KEEP]*29,False)
                a=n.replay8(pool,route,f['config'],seed,seat,p['days'],p['plan'],False)
                b=n.replay8(pool,route,f['config'],seed,seat,DAYS,padded,False)
                assert bare['state_action_hash']==keep['state_action_hash']
                assert a['state_action_hash']==b['state_action_hash']
                rows.append(dict(route=case['route_id'],seed=seed,seat=seat,keep_hash=keep['state_action_hash'],old_plan_hash=b['state_action_hash']))
    write(out/'mechanism.json',dict(status='PASS_29_KEEP_AND_8_PLAN_EMBEDDING',rows=rows))
    print(json.dumps(dict(check='PASS',worlds=len(rows),days=len(DAYS))),flush=True)
def search(out):
    f,n,pool=context(out);assert read(out/'mechanism.json')['status']=='PASS_29_KEEP_AND_8_PLAN_EMBEDDING'
    seeds=[s for s in old.TRAIN for _ in (0,1)];seats=[p for _ in old.TRAIN for p in (0,1)]
    started=time.perf_counter()
    for case in f['selected']:
        target=out/case['route_id'];target.mkdir(exist_ok=True)
        if (target/'selected.json').exists():continue
        if any(target.glob('stage*.json.gz')):raise RuntimeError('partial run exists: preserve, do not overwrite')
        tic=time.perf_counter();route=f['route_ids'].index(case['route_id'])
        engine=n.Search8(pool,route,f['config'],seeds,seats,DAYS,4,16)
        for depth in range(len(DAYS)):
            stage=engine.expand();zipped(target/f'stage{depth:02d}.json.gz',stage)
            best=stage['beam'][0]['outcomes'];progress=dict(route=case['route_id'],day=stage['day'],nodes=depth+1,total_nodes=29,
                proposals=stage['proposals'],suffixes=stage['suffixes'],seconds=stage['seconds'],wins=sum(r['win'] for r in best),
                mean_margin=sum(r['margin'] for r in best)/len(best),total_suffixes=stage['total_suffixes'])
            write(out/'progress.json',progress);print(json.dumps(progress),flush=True)
        selected=engine.state();selected['case']=case;selected['seconds']=time.perf_counter()-tic;write(target/'selected.json',selected)
        write(target/'policy.json',dict(schema='daily29-common-semantic-plan-v1',base_config=f['config'],days=DAYS,
            plan=selected['beam'][0]['plan'],missing_candidate='KEEP_WITH_EXPLICIT_REASON',scope='current_day_new_projects_with_stateful_continuation'))
    write(out/'search_done.json',dict(status='COMPLETE_SEARCH_NOT_HOLDOUT',seconds=time.perf_counter()-started,routes=len(f['selected'])))
def validate(out):
    f,n,pool=context(out);assert (out/'search_done.json').exists();summaries=[];tic=time.perf_counter()
    for case in f['selected']:
        target=out/case['route_id'];dest=target/'validation.json'
        if dest.exists():summaries.append(read(dest)['summary']);continue
        route=f['route_ids'].index(case['route_id']);p=read(target/'policy.json');prior=old_policy(case['route_id'])
        selected=read(target/'selected.json');train=[]
        for ref in selected['beam'][0]['outcomes']:
            r=n.replay8(pool,route,f['config'],ref['seed'],ref['seat'],p['days'],p['plan'],False)
            for key in ('cash','opponent_cash','missing_recipe','changed_nodes'):assert r[key]==ref[key],(key,r,ref)
            train.append(r)
        plans={'KEEP':dict(days=DAYS,plan=[KEEP]*29),'EIGHT':prior,'DAILY':p}
        jobs=[(s,p,arm) for s in VALID for p in (0,1) for arm in plans]
        def run(job):
            seed,seat,arm=job;pp=plans[arm];r=n.replay8(pool,route,f['config'],seed,seat,pp['days'],pp['plan'],False)
            assert r['steps']==719;r['arm']=arm;return r
        with ThreadPoolExecutor(max_workers=16) as workers:rows=list(workers.map(run,jobs))
        metrics={arm:old.stats([r for r in rows if r['arm']==arm]) for arm in plans}
        previous=read(OLD/'receipts_v1'/case['route_id']/'selected.json')
        summary=dict(route=case['route_id'],team=case['team_name'],train_daily=old.stats(train),train_eight=old.stats(previous['beam'][0]['outcomes']),holdout=metrics,
            daily_seconds=selected['seconds'],eight_seconds=previous['seconds'],daily_suffixes=selected['total_suffixes'],eight_suffixes=previous['total_suffixes'])
        write(dest,dict(status='COMPLETE_FROZEN_COMPARISON',policy_sha256=sha(target/'policy.json'),summary=summary,train_replays=train,rows=rows))
        for seat in (0,1):zipped(target/f'official_fixture_seat{seat}.json.gz',n.replay8(pool,route,f['config'],VALID[0],seat,p['days'],p['plan'],True))
        summaries.append(summary);print(json.dumps(summary),flush=True)
    cross=[]
    for source in f['selected']:
        p=read(out/source['route_id']/'policy.json')
        for case in f['selected']:
            if case['route_id']==source['route_id']:continue
            route=f['route_ids'].index(case['route_id']);jobs=[(s,seat) for s in VALID for seat in (0,1)]
            def run(job):return n.replay8(pool,route,f['config'],job[0],job[1],p['days'],p['plan'],False)
            with ThreadPoolExecutor(max_workers=16) as workers:rows=list(workers.map(run,jobs))
            cross.append(dict(source=source['route_id'],opponent=case['route_id'],summary=old.stats(rows),rows=rows))
    write(out/'validation_done.json',dict(status='COMPLETE_DAILY29_PILOT',summary=summaries,cross=cross,seconds=time.perf_counter()-tic))
def official(out):
    # Existing referee requires only selected cases, source config and frozen traces.
    import audit
    audit.runtime=lambda ignored:context(out)
    audit.official(out)
def close(out):
    f,n,pool=context(out);results=read(out/'validation_done.json');official=read(out/'official.json')
    assert official['status']=='PASS_COMPLETE_STATE_AND_PYTHON_OPPONENT' and len(official['rows'])==6
    assert not set(VALID)&set(old.TRAIN) and not set(VALID)&set(old.VALID)
    current=read(EXP/'native/build/build_receipt.json');assert current==read(OLD/'receipts_v1/inputs.json')['production']
    for rel,h in current['source_hashes'].items():assert sha(EXP/rel)==h
    files={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file() and p.name!='acceptance.json'}
    write(out/'acceptance.json',dict(status='COMPLETE_DAILY29_COMPARISON_NOT_PROMOTION',days=DAYS,beam_width=4,
        train_independent_seeds=4,holdout_independent_seeds=16,target_games_per_arm=96,cross_games=192,official_games=6,
        summary=results['summary'],files=files,production_unchanged=True,old_goal_still_paused=True,online_router=False,
        search_seconds=read(out/'search_done.json')['seconds'],binary_reused_no_recompile=True,
        caveat='Same feasible candidate grammar and width; more time nodes, not an exhaustive optimum or all-seed win guarantee.'))
    print('ACCEPTANCE COMPLETE',flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['check','search','validate','official','close']);p.add_argument('--version',default='v1');a=p.parse_args()
    out=HERE/('receipts_'+a.version)
    try:globals()[a.mode](out)
    except Exception as exc:
        if out.exists():write(out/f'failure_{a.mode}_{time.time_ns()}.json',dict(status='FAIL_PRESERVED',error=repr(exc)))
        raise
