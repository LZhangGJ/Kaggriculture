"""Report completed experiment; no re-selection or policy changes."""
from pathlib import Path
import gzip,json,collections
HERE=Path(__file__).resolve().parent
OUT=HERE/'receipts_v1'
read=lambda p:json.loads(p.read_text())
a=read(OUT/'acceptance.json');assert a['status']=='COMPLETE_BEAM12_DAILY29_100_ROUTES_PER_TARGET_NOT_PROMOTION'
v=read(OUT/'validation_done.json');rows=v['summary'];selection=read(OUT/'selection_frozen.json')
lines=['# Day0–28 × Beam12 × 每对手100条获胜路线','',
'2026-09-04。保持候选语法、原动态规划底座、原4训练seed双座位不变，只把搜索Beam由4加到12；每个原对手抽取100条训练全胜且训练行为不同的计划，再换新seed。','',
'## 1. 同新种子直接比较','',
'每条在20264501–20264516共16个全新seed、双座位32局。最高成绩是在本库中筛选的最高，不是又一次独立认证后的真实胜率。','',
'| 对手 | Beam4原20条最高 | Beam12前20条最高 | Beam12全部100条最高 | Beam12百条中≥90% | Beam12百条中全胜 |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:
    x,y,z=(r['arms'][k] for k in ('W4_20','W12_20','W12_100'))
    lines.append(f"| {r['team']} | {x['max_wins']}/32 | {y['max_wins']}/32 | {z['max_wins']}/32 | {z['plans_wins_ge_29']}/100 | {z['plans_wins_eq_32']}/100 |")
lines+=['','前20条是冻结的多样化选择顺序，不是验证后取表现最好20条。两组各20条用于比较Beam变化；同一Beam12的20与100用于观察多取候选的影响。不能把多取80条带来的最高值提升全部归功于Beam12。','',
'## 2. 原冠军与全池分布','',
'| 对手 | 池 | 原冠军 | 胜场范围 | 池平均胜率 | 新库不同行为签名 |',
'| --- | --- | ---: | ---: | ---: | ---: |']
for r in rows:
    for arm in ('W4_20','W12_20','W12_100'):
        p=r['arms'][arm]
        lines.append(f"| {r['team']} | {arm} | {p['original_champion']['wins']}/32 | {p['min_wins']}–{p['max_wins']}/32 | {p['mean_winrate']:.2%} | {p['new_set_distinct_behaviors']}/{p['candidates']} |")
lines+=['','## 3. 各池本批最优现金','',
'以胜场优先、平均分差其次取最优。','',
'| 对手 | 池 | 选择序号 | 胜场 | 我方平均现金 | 对手平均现金 | 平均分差 |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:
    for arm in ('W4_20','W12_20','W12_100'):
        p=r['arms'][arm]['best_on_this_new_set']
        lines.append(f"| {r['team']} | {arm} | {p['index']:03d} | {p['wins']}/32 | {p['mean_cash']:,.0f} | {p['mean_opponent_cash']:,.0f} | {p['mean_margin']:+,.0f} |")
lines+=['','## 4. 实际搜索量与候选数','',
'321是旧Beam4的一层峰值，不是固定上限。本次保留完整候选语法，每前缀合并8训练世界的可行参数候选，整层是12个前缀的候选合计。每个提议在8个训练世界分别续跑，不是把8局当8条路线。','',
'| 对手 | 搜索秒数 | 续跑次数 | 环境转移数 | 单层候选峰值 | 单前缀合并候选峰值 | 去重训练全胜参数计划 | 选定训练不同行为 | 源开局组合/选中开局组合 |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
total_suffixes=total_transitions=0
def opening(plan):return tuple((p['family'],p['kind'],p['amount']) for p in plan[:2])
for r in rows:
    target=OUT/r['route'];s=read(target/'selected.json');selected=read(target/'selected100.json');layermax=parentmax=0
    for p in target.glob('stage*.json.gz'):
        with gzip.open(p,'rt') as f:stage=json.load(f)
        layermax=max(layermax,stage['proposals']);groups=collections.Counter()
        for item in stage['frontier']:
            groups[tuple((x['family'],x['kind'],x['amount']) for x in item['plan'][:-1])]+=1
        parentmax=max(parentmax,max(groups.values()))
    with gzip.open(target/'winning_frontier_catalog.json.gz','rt') as f:catalog=json.load(f)
    source_openings=len({opening(c['plan']) for c in catalog});picked_openings=len({opening(c['plan']) for c in selected['candidates']})
    total_suffixes+=s['total_suffixes'];total_transitions+=s['total_transitions']
    lines.append(f"| {r['team']} | {s['seconds']:.1f} | {s['total_suffixes']:,} | {s['total_transitions']:,} | {layermax} | {parentmax} | {selected['semantic_win8_count']:,} | 100 | {source_openings}/{picked_openings} |")
seconds=read(OUT/'search_done.json')['seconds']
lines+=['',f"搜索总耗时{seconds:.1f}秒（{seconds/60:.1f}分钟），{total_suffixes:,}次后缀续跑，{total_transitions:,}次环境转移。续跑吞吐约{total_suffixes/seconds:.1f}/秒，不是等量完整开局对战。",'',
'首日三组均68候选，与原Beam4全部前沿、前4结果完全一致，只保留前缀数变成12。代码和二进制未改动；有限Beam并不保证找到全局最优，也不保证宽度变大后每个对手都更好。','',
'## 5. 百条路线逐项结果','',
'序号按冻结选择顺序；每格分母32，第001条是本次Beam12训练冠军。','',
'| 序号 | OceanMix | Driz Lo | QQ Farming |','| --- | ---: | ---: | ---: |']
for i in range(1,101):
    vals=[str(read(OUT/r['route']/f'w12_{i:03d}_validation.json')['summary']['wins']) for r in rows]
    lines.append(f"| {i:03d} | "+' | '.join(vals)+' |')
lines+=['','## 6. 覆盖与可信边界','',
'以下需要在每局结束后任选一个赢家，只是候选池覆盖，不是已实现线上策略的胜率。','',
'| 对手 | Beam4的20条事后覆盖 | Beam12前20条事后覆盖 | Beam12百条事后覆盖 | KEEP实际胜场 |',
'| --- | ---: | ---: | ---: | ---: |']
for r in rows:
    vals=[str(r['arms'][k]['retrospective_any_winner_coverage'])+'/32' for k in ('W4_20','W12_20','W12_100')]
    lines.append(f"| {r['team']} | "+' | '.join(vals)+f" | {r['keep']['wins']}/32 |")
lines+=['','- 300条在读取新种子前冻结，只用原训练8局全胜和语义距离选取；每条从头核对训练现金与分差，按完整训练状态/动作签名去重。','- 参数轨迹不同不等于100个独立产业家族。某些方案可能在新种子上收敛到同一行为，表2已记录；没有根据新库结果换方案凑数。','- 每条只有16个独立seed，座位及不同方案共享seed而相关；不能把9600局当作9600个独立随机环境。','- 本轮若按新库挑选最佳，这些种子以后应作为开发数据，需再用未见种子确认。','- 只覆盖原3条历史对手代表，未覆盖153条或全部动态高手。没有实现线上选拳器。','',
'## 7. 交付与验收','',
f"- 300条选择及原训练重放耗时{selection['seconds']:.1f}秒。",
f"- 新库9600局Beam12＋1920局Beam4＋96局KEEP=11616局，含夹具保存约{v['seconds']:.1f}秒。",
'- 每组第100条、首个新seed双座位，共6完整局719步，官方1.32.7完整状态与Python对手动作一致。并非全部11616局官方Python运行。',
'- 原生产、二进制、候选语法、旧最优配置未修改。最多16线程，不恢复暂停Goal，不Git/Kaggle提交。',
'- `receipts_v1/selected100.json`实际位于三个对手子目录内：含全部参数、来源和训练结果；同目录`w12_001_validation.json`至`w12_100_validation.json`含完整新种子记录。',
'- `selection_frozen.json`、`search_done.json`、`validation_done.json`、`official.json`、`acceptance.json`位于`receipts_v1`根目录。原始stage前沿、失效回退、最优及失败路线全部保存。',
'- 入口`run_w12.py`依次`check → search → select → validate → official → close --version v1`；本轮完成后不需要重跑。','']
(HERE/'RESULT_ZH.md').write_text('\n'.join(lines),encoding='utf8')
print('REPORT WRITTEN',HERE/'RESULT_ZH.md')
