# Kaggriculture bilingual lightweight reading pack

Extract the ZIP, open **START_HERE.html**, and choose Chinese or English. Reading does not require Python, Node, a translation model, or a server.

## Find an individual Notebook review

Open **Full index → search by author or Notebook title → Full review and local source references**. Mechanisms, evidence, limitations, transfer ideas, and historical followups are embedded in the HTML. The complete research directory is not required for these reviews.

## Included

- Full Chinese and English reports, plus their Markdown companions.
- 516 cumulative candidates: 514 reviewed Notebooks (508 individual reviews and six exact-duplicate inheritances), plus two availability exceptions.
- 27 selected sources, 16 proposed experiment cards, and 405 historical evidence-followup dispositions.
- Code-bound analysis of Scheme A (route clustering/switching) and Scheme B (three-layer economic/execution planning).
- Original edition validation records, a per-file SHA256 manifest, and an offline verification script.

This is a saved research snapshot, not a live census. The 37 early supplements and 119 targeted historical originals are separate counts, not additional independent Agents.

## Attachment and translation limits

This is a reading/discussion pack, not a reproduction environment. Raw Notebooks, extracted source files, linked repositories, binaries, replays, translation models, and the older detailed archive HTML are excluded.

Original source / Readable code / Prose and other local evidence links still point to the original research workspace. Those attachments will not open from this pack alone. The Chinese report's link to the earlier detailed archive is also excluded; the 514 individual reviews are still embedded in the current reports. Public Kaggle/GitHub URLs remain available and require internet access and the appropriate permissions.

The core English synthesis, protocol, 16 cards, 27 source titles/transfer summaries, and two priority source reviews were translated and checked by the assistant. Other archival reviews use local neural machine translation and may contain imperfect technical wording; consult the original evidence for precise claims.

All suggestions remain PROPOSED_NOT_RUN. The original reports passed static and pure JavaScript logic checks. Browser interaction and visual layout were not verified because of the existing URL policy restriction. Packaging does not change that limitation or establish new experimental gains.

## Working together

Discuss experiment IDs first. For implementation, share a separate scoped bundle containing the pinned Agent, configuration, required dependencies, and relevant evidence. There is no need to transfer the 8 GB research archive just to read the findings.

Keep A, R1, and R2 as separate baselines. Start with T04/O01 for A and T01/T02 for B, then use logs to prioritize E01/E02/E03/E04.

## Optional verification

With Python installed, run `python verify_package.py`. It verifies the ZIP if present alongside the script, otherwise the extracted payload. It checks SHA256/ZIP integrity without executing Agents or a browser.

The original edition acceptance records reference additional research files outside this pack. They are not the package contents list; use PACKAGE_MANIFEST.json.
