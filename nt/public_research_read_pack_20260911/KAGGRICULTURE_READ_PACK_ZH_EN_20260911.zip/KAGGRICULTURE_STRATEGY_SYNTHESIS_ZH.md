# 先修验证对象与现金链，再扩大模型

公开资料中最可迁移的东西，是**生产骨架、市场交易、可执行工作链和真实评估的分离方法**。重复发布和高赞并不等于独立策略；很大的离线胜率也常常只针对同源动作带。这里把已审来源保留下来，再把结论落到你指定的两套代码。

| 优先事项 | 方案A：路线聚类与切换 | 方案B：三层规划 |
|---|---|---|
| 最强的代码证据 | 最终成品为三个浅树、最多一次切换；有效信号只有5类市场/商店量，输出4个族 | 项目DP＋贪心组合＋有限条件预演；默认轮作/重复开关关闭，不是全农场穷举 |
| 优先验证的解释 | 新互动对手使旧市场阈值失效；接续状态未进入最终树；切换后缺恢复选路 | 首日镜像供给先验；共同评分重对手收益；现金到账、雇工和项目启动窗口失配 |
| 先做什么 | T04实态接续门、O01时间与同源留出，再做O02载体筛选 | T01先验开关、T02开局竞争权重，再看E02预览剔除后补选 |
| 经济路线方向 | 用短段目标与边界可行性替代增加大量同源全季带 | E01比较12瓜候选/前缀接管，E03短周期回款桥，E04真实边际劳动 |
| 暂不下的结论 | 用户报告两天失效属实观察，但当前没有上线时序证明唯一原因 | 没有前12天逐局账来确认哪项是主因；执行修复减少漏项没有提高现有总胜场 |

**不要把“十二甜瓜”当成完整对手策略。** 它只描述开局的一部分；后续牲畜、雇工、回款与抢售机制可能不同。12株的种子投入按已读冻结常量为960，理想水分条件下单株年龄10可到6单位，但这既不是第10天必然成交，也没有扣人工、运输及共享市场冲击。对手开局与我方12瓜后接管必须分开实验。[作物与劳动分析](https://www.kaggle.com/code/georgymamarin/kaggriculture-visualized-what-every-crop-pays)、[12瓜开局失败复盘](https://www.kaggle.com/code/moushunchen/twelve-seeds-three-melons)

全部16项均为**待验证建议**，不是已经测得收益的补丁。本轮没有改你们Agent，也没有训练或新跑比赛。试验卡中的工作量只是准备复杂度估计；实际耗时取决于你们评估基础设施。

## 公开方案按哪些机制归纳

| 研究方向 | 代表来源 | 对两套方案最有价值的部分 | 不能继承的说法 |
|---|---|---|---|
| 生产骨架与分段路由 | Thomas、Ahmed、Shop Router、Six-Day、Fieldbook | 共同前缀、特定边界接续、生产族差异 | 多条名字不等于多种生产；作者胜率不等于实盘 |
| 固定生产上的市场变化 | Kaito条件记忆、Boatlee抢售、Mohui | 保留订单槽位、实际成交、精确触发后持续校验 | 30记忆并非30种农场；精确签名不证明泛化 |
| 活动执行器与物流 | Reactive、Mohui、资金失败审计 | 原子播种、真实工人数、按演员预约、承诺完成 | 删掉无效动作不能补回损失；DONE不是经济健康 |
| 生产与市场共同反作用 | Soil V34、Moon V39 | 新增产出、己方现金、对手现金、最终胜负逐层拆分 | 生产增加不等于赚钱；同源池翻胜可能不迁移 |
| 独立经济与搜索 | Island GA、可读动态任务实现、用户B | 独立季节意图、有限候选、现实可执行性 | 私有最终执行器缺失；算法名字不能当运行证据 |
| 学习小决策 | Bruce局部bandit和终局搜索 | KEEP对照、真实转移、有限干预、失败状态 | 微型演示收益不是全季RL或金牌证明 |
| 评估与群体变化 | 18,144局分析、固定seed不固定town、行为X-ray | 时间留出、同源去重、真实成交标签、世界差异 | 统计汇总、模拟例子和排行榜分数不可混用 |

## 近期优先与旧资料的处理

纯提交方案按真实运行/版本时间、明确对应当前版的分数和可读实现优先；例如Ahmed近期生产组合、Soil/Moon最新已知版本，以及近期路由和市场控制层。旧版即使曾有高分，也只在解释关键机制或失败时回看。分析文章不按年龄淘汰：订单→实际成交、资金保护48局全败、同种子世界分叉、局部bandit反例，都比很多新包装更有迁移价值。

“最近运行”可能只是旧源码重新打包。目录内的标题分数、历史Best、当前版Public、真实线上Agent表现分别保存；本页排序只用于查资料，不是当前强度排行榜。

## 建议验证顺序

1. 先完成O01评估分组和现金/成交日志，保留R1、R2、实际A三个基线。
2. 并列准备T01/T02/T04；每项单独改变，先小筛选，只有表现明确的冻结候选进新seed确认。
3. 根据日志判断E02补选、E01开局候选、E03现金桥与E04劳动标定哪个先做。没有出现对应症状的方案降级。
4. A的真实未来窗口仍掉队，再考虑O02/O03；已有稳定增益后才考虑O04混合架构。不要一轮堆完全部改动。


# 两套指定方案：来源绑定与针对性结论

本轮由用户明确恢复并开启新 Goal。2026-09-11；研究为静态代码阅读、字面载荷解码与已有数据复算，没有执行 Agent、训练或对局，也没有新增 Kaggle 请求。已被更新版本替代的早期可提交 Agent 不再默认逐版深挖；有独立机制、实验和失败教训的文章保留。

## 来源及阅读范围

方案 A 使用用户指定的 `main/agents/route_clustering_switch_agent`，固定 commit `eec409775bc538cf65b3676172ee3ce741ca2469`。74 文件从已有本地 Git 对象读取并核验 Git blob；不是本地另一个 710 路线实验。完整阅读 README、SOURCE_PROVENANCE、宏观路线方法文档、运行入口、三个路由/特征/载体适配模块和鲁棒树训练脚本。最终单文件仅做 AST 与 base85/zlib 字面解码；17 个函数/类 AST 与运行时模块完全相同，载体源码及动作带字节一致，策略及元数据 JSON 相同。未执行打包文件中的 exec，也未把全部 74 文件宣称为逐行阅读。底层 547,143 字节执行载体在本轮只做身份绑定，不能将尚未审计的执行分支当作已确认缺陷。

方案 B 使用用户指定 AFS workflow repair 路径，固定 commit `4ef9875968f7104f26fc3140bd28b988101579f8`。远程清单 130/130 文件均已绑定 SHA256，包括两份实际 agent.so；多数与现有实验逐字节相同，少数从 GitHub 连接器读取。130 是清单绑定数量，不是本轮逐行精读文件数量。完整阅读 R1 triad.hpp、planner.hpp、search.hpp、proposals.hpp、joint_candidates.hpp、startup_supply.hpp、public_flow_scenario.hpp、local_sale_timing.hpp、配置、父报告与验收报告；阅读 R1→R2 上述经济路径全部差异及相关投影开关差异。工作流修复与 120KB 执行器的外围实现不作为本轮全文审阅声明。`saved_result_audit178.json` 逐行校验 3,300 条已保存结果及两版 R2 的配对差；这是结果文件复算，不是新实验。

## A：模型已有稳健训练，但部署支持面非常窄

用户称其为 Top40 聚类加 LGBM。指定成品实际用 `DecisionTreeClassifier` 导出三个浅树，固定 G001 开局，只在 144/168/216 检查，最多一次切换。候选库 175 条、训练候选 11 条，与在线有效选择数是不同数量。

真实树中的索引映射已从特征定义核查。结构出现 7 个特征，但羊毛库存与羊毛价格的分裂两侧最终动作相同，对该导出分类无影响。去掉这些冗余分裂后，有效信号仅为 yarn 商店、奶价、番茄/草莓/牛奶库存，输出仅 G001/G006/G036/G169。所有 147 维中的己方现金、对手资产、历史损失和路线未来资金需求都没有影响最终叶子的选择。216 节点实际上只是“出现 yarn→G036，否则保持 G001”；还要服从此前未切换的条件。

训练代码确实有 seed 分组和对手族分组交叉验证、阈值扰动与 bootstrap；不能泛称没有防过拟合。作者报告的 256 新种子留出仍针对同一 175 个回放代表，未验证后续出现的闭环对手生态。+8.44pp 是作者保存的方法结论，不是本轮独立重跑或在线增益。用户“三次进金牌、约两天失效”保留为用户观察，尚无对应时间序列做因果证明。

最需要验证的假设：新对手改变供给与抢售时序后，旧绝对库存阈值不再对应相同未来；载体后缀缺少实态兼容门；一次切换后没有再选择恢复路线。不是断言这三点已解释全部衰减。

## B：不是穷举全农场所有经济路线

三层结构成立，但实际是项目生命周期 DP、按地块依次加入的边际组合规划、有限参数候选加条件滚动预演。当前配置 rotation=0、repeat=0，不能把存在的轮作 DP 接口当作默认已经规划了全季所有轮作。`portfolio_passes=6` 加 `candidate_extra=1` 先生成 9 组设置，再按实际目标与队列去重，并非 9 条始终不同的经济路线。

默认 scenario=1：普通候选只在条件场景中推进一天，之后接剩余资产估值；联合“少买牲畜→小麦→后继作物”候选另有事件驱动的更长预演。候选本身已包括折现提高、偏作物、偏动物、竞争权重折半/1.5倍，以及更高储备和短期融资配置。建议不能重复声称这些从未存在。

重要观察：

- 第一步对手先验是“用我方同套规划器在对手可见空农场做镜像计划”。当前启动供给开关为 2，即完整先验；day>0 清除。面对不同开局时可能误导初始组合，尚需开关消融。
- 现金预算计现钱、85% 棚中商品报价、reserve 和一波饲料；收益模型还有逐日负现金惩罚（risk=1），不是完全没有流动性约束。但资产产出先按日入收益流，不等于已走完采收、运输、入棚和成交链。执行预演能纠正部分问题，长尾估值仍近似。
- 地块贪心选入项目后，最多三次预览剔除未获准启动的未付款项目；该循环重新估值和准备订单，却不在同一循环重新枚举便宜替代项目。后续日内 admission 可以再启动，故应检查“当时是否错过启动窗口”，不能断言整天永久闲置。
- 默认劳动估值同时含根据 labor_hours=10 换算的非线性雇工成本与 work_price=4 的行动影子成本。后者可作为机会成本，不能未经标定称为错误双计；但两者和实际多工人运输成本失配是可测方向。
- 当前竞争权重 2；可能为了减少对手收益接受己方回款较慢的项目。候选已试过 1 和 3，但评分仍以共同 base competition=2 裁决，改变候选与改变最终目标不是同一个消融。
- PublicFlowScenario 只投影公开供给流，默认两个到货窗口 1/17，不执行真实对手策略；关闭新杂草生成并用未知商店的期望需求。这是条件预测模型，不能把其评分当必然真实未来。
- local sale timing 当前模式 1 不使用 rival quantity；尽管交易账本有采集，不能把“有账本”解读为所有决策已利用对手出售时钟。

## 已有评估的含义

同一个 50 种子×11 对手名×两席面板：R1 on 856胜/4平/240负；R2 on 824胜/4平/272负。R2 audit 与 on 仅两席同种子发生动作 hash 改变，各自现金 +658，对手 −815，分差 +1473，仍由 −2360 变 −887，没有翻胜；未解决工作流事件从 40 降为 0。这证明局部执行修复，不证明整体经济更强。R1/R2同时存在经济候选和工作流差异，不能把32个胜场差全归因于一个开关。

`aurax_reactive_v1` 与 `moon_v215` 的摘要完全相同；`flexon_v5` 与 `seven_turn` 也相同。它们至少呈现高度重复的结果，不可把 11 个名字直接当 11 个独立策略族；尚未据此证明代码相同。`nagatakengo_v70` 两版都 100/100，且平均分差远大于其余对手，会显著抬高总平均现金差。

父报告中默认与 m12 接管的 264 局只有三个种子，而且 m12 指我方外置 24 步开局。它没有回答用户说的“对手采用十二甜瓜”。新验证须把对手按实际前24/48步播种、后续牲畜及市场策略分层，而不是仅看名称或标题。

## 新范围下的完成口径

主目录累计 514 份已审阅（508 单独、6 精确继承），早期补充 37、已验收指定历史原件 119。它们不是 670 个独立 Agent。旧待办是证据追踪记录，保留缺失原始比赛、未公开私有组件和旧版本身份问题，但不自动将每个问题变成新的必读方案。Jocelyn 尚有 210 个非空外围模块未精读：保留该事实；其活动入口与两套依赖链已揭示位置/种子/记忆不贯通，当前没有证据要求为目标策略继续穷读所有未接入组件。无关跨赛分析、旧可提交版本与无法绑定的纯成绩声明均单列，不能写成已全文阅读。


# 共同实验协议

## S

方向筛选：8个预先冻结的开发seed × K个经来源/行为去重的对手组 × 双席，每个候选16K局；计划K=6时96局。K不足须报实数，不用同源fork凑数。S不宣称统计确认。

## H

冻结一个晋级候选后，至少32个未用于训练/调参/筛选的新seed × 相同K及额外未见族 × 双席；K=6时每候选至少384局。小效应或尾部不确定则扩到64seed，仍不够就保留INCONCLUSIVE，不能多看几批直到显著。

## pairing

candidate、baseline使用相同seed和两席并保存引擎/配置/源码hash；一个seed内双席及相关对手不能当独立样本。主分析按seed聚合配对差，分族报告；需要外推新对手时做族层面的留出/重采样。

## worlds

固定seed不保证相同未来商店/杂草。官方环境测试估计真实策略效应；诊断若控制相同外生事件，应单列受控世界结果，不能冒充标准环境比赛。禁止从隐藏seed或未来事件构造在线特征。

## endpoints

主指标先登记为终局积分差（胜1、平0.5、负0）或终局现金差增益。同时记录己方、对手现金分别变化。研究早期经济须保存day1/3/6/10/12现金、流动性、在途/棚中/未成熟资产以及关键首产、首售、雇工、死亡事件。

## gates

增胜方案：预先登记的配对积分差95%下界>0，且12瓜/非12瓜和主要去同源族无超过预定2个百分点的明显退步。现金微调方案：配对现金差95%下界>0，并用预定1个百分点界限检验胜负非劣；不足以确认非劣时结论为不确定。阈值是实验决策约定，不是已证明最优。

## health

每局完整终态/步数、异常、实际PLANT/FEED/生产/交付/成交、仓储溢出、行动hash、加载binary/config、单步p99和最大耗时。生产错误不得仅因程序DONE或零未填市场订单而被忽略。

## stopping

先筛选后一次确认；每个机制独立消融。未触发、接口失败、超时、负效应与证据不足分别报告。R1/R2分开，不把不同经济分支差异全归因于工作流修复。

## opponents

重点包含实测12瓜开局的不同后续生产/市场控制、非12瓜动态经济、近镜像抢售、不同奶/羊毛供给和至少一个有独立活动实现的反应对手。名称和分数不能代替行为/源代码身份。


# 16项可执行实验卡

## T01 首日镜像供给先验开关消融

**目标：** B

**类别：** 马上验证

**优先级：** P0

**对应弱点：** 初始对手预测可能默认对方也采用我方经济计划。

**改动机制：** 仅比较 R2_STARTUP_SUPPLY_MODE 的 0/1/2：无先验、半权重、当前完整镜像。其余配置、候选和修复完全固定。不要把敌方12瓜当作初始可见事实。

**准备规模：** 小：构建开关；约半天准备（不含对局）

**前提：** 分别在R1和R2实际发布入口做对照；对手12瓜标签由已完成游戏实际行为离线标注。

**反例：** 镜像群体中取消先验可能变差；day0之后原先验已清除，因此不能解释所有后期问题。

**最小验证：** 共同协议S：每版3个先验候选，8个开发种子双席；按12瓜/非12瓜分层。只晋级一个设置至H，冻结后不反复挑种子。

**通过/否决：** 通过：H的12瓜组主要指标改善且整体胜负无实质退步；无动作差异则该先验不是此面板瓶颈，结果记未激活。

**指标：** day0目标作物/动物；实际前24/48步启动数；首次售货和可支配现金；day3/6/10/12现金；终局双方现金差

**公开出处：** [Thomas：五路线稀疏路由](https://www.kaggle.com/code/thomastschinkel/kaggriculture-95-5-win-rate-via-replay-routing), [分开生产与市场的行为分析](https://www.kaggle.com/code/destbreso/a-week-four-x-ray-of-the-top-twelve), [固定种子不固定商店](https://www.kaggle.com/code/yhay81/your-seed-does-not-fix-the-town)

**代码落点：** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/startup_supply.hpp:5](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/startup_supply.hpp#L5), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp:40](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp#L40)

## T02 开局先争自身增长，再检验竞争权重

**目标：** B

**类别：** 马上验证

**优先级：** P0

**对应弱点：** 共同评分竞争权重2可能牺牲早期自有回款。

**改动机制：** 限定day0–3，把最终评分的base.competition分别设2/1/0.5，随后恢复2。必须同时对齐候选尾部估值；只修改候选中的competition并不改变共同评分目标。

**准备规模：** 小到中：一个阶段开关与评分一致性检查

**前提：** 保留真实现金、对手现金两条账；先确认配置实际改变了被选候选。

**反例：** 羊毛/牛奶高度竞争时较低权重可能自己多赚、对手多赚更多；day3截止是待调参数，不是机制常数。

**最小验证：** S先固定day0–3不搜索截止日，比较2/1/0.5；H仅比较胜出设置与当前基线，R1/R2分别给结果。

**通过/否决：** 否决：仅己方现金上升但终局胜负或目标对手组下降；通过须满足H主指标与组别保护条件。

**指标：** 候选名及评分分解；首产/首售时间；day6/10双方现金；终局己方收入与对手收入；12瓜组胜负

**公开出处：** [Soil V34：劳力、补麦与牲畜](https://www.kaggle.com/code/prvsiyan/kaggriculture-frontier-the-soil-remembers-rain), [完整经济链与失败分支](https://www.kaggle.com/code/dmitriigluzdov/kc-what-we-learned-historical-lb-1637), [资金保护的失败实验](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit)

**代码落点：** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp:40](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp#L40), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp:63](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp#L63), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp:8](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp#L8)

## T03 启用已有的价格压力运输候选做单项对照

**目标：** B

**类别：** 马上验证

**优先级：** P1

**对应弱点：** 产品已产出却未及时入棚，早期缺现金；当前batch_delivery=1未启用额外价格压力触发。

**改动机制：** 单独试batch_delivery=2；配套记录已经可行的途中回棚是否增加。它是在既有调度上增加有条件送货，不能顺手修改雇工、售价或生产。

**准备规模：** 小：配置与日志；约半天准备

**前提：** 保持同一成交账与原子作业约束；day0没有可卖货时不应强制空跑。

**反例：** 更早回棚可能打断关键浇水/喂料；Soil公开delivery改动就有增失互抵和平均值变差的反例。

**最小验证：** S比较1/2；先看day1–12有货无钱案例是否触发，再做H。

**通过/否决：** 无有效触发不算改善；出现不可恢复的生产漏项否决；小额现金改善但置信不足记不确定。

**指标：** 货物在手滞留时长；实际入棚与成交额；新增路程；漏喂/漏水/死亡；day6/10现金

**公开出处：** [真实成交账本](https://www.kaggle.com/code/az05192000gmailcom/kaggriculture-from-orders-to-actual-trades), [资金保护的失败实验](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit), [Soil V34：劳力、补麦与牲畜](https://www.kaggle.com/code/prvsiyan/kaggriculture-frontier-the-soil-remembers-rain)

**代码落点：** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp:70](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp#L70), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp:545](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp#L545)

## T04 切换前做实态可行性门

**目标：** A

**类别：** 马上验证

**优先级：** P0

**对应弱点：** 树不使用现金/工人/资源特征，直接接相同时间索引后缀。

**改动机制：** 先在144/168/216旁路记录后缀未来24步的必需种子、地块、工人数和资金缺口，再试仅阻止确定不可执行的切换并KEEP。不要以影子专家假想状态通过检查。

**准备规模：** 中：半天至1天；先日志后最小门控

**前提：** 使用当步实际观测；资金预测只保守计可实现成交，跨午夜工人重新雇用不能继承旧编号。

**反例：** 有些强后缀允许少量失败或延后修复；过严门控会错杀，KEEP也可能输。

**最小验证：** S比较原树、只拦确定缺失资产、拦24步资金缺口；保存每次被拦的原分支反事实结果。H只晋级一项。

**通过/否决：** 通过须拦截实际有害切换且H净收益为正；只减少报错却少赢的门控否决。

**指标：** 分支触发与拒绝率；接续24步生产完成率；漏喂/整批播种失败；切换相对KEEP配对收益；终局胜负

**公开出处：** [三日片段与可接续状态](https://www.kaggle.com/code/yhay81/fieldbook-commit-for-three-days), [联合动作顺序与末期修复](https://www.kaggle.com/code/mohui666/kaggriculture-v66-public-agent), [资金保护的失败实验](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit)

**代码落点：** [agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py:59](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py#L59), [agents/route_clustering_switch_agent/runtime/meta_agent/src/teammate_expanded_routes.py:73](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/teammate_expanded_routes.py#L73), [agents/route_clustering_switch_agent/runtime/meta_agent/src/route_switch_features.py:269](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/route_switch_features.py#L269)

## T05 把市场提前/延迟的账改成实际成交账

**目标：** A+B

**类别：** 马上验证

**优先级：** P1

**对应弱点：** 公开多层覆盖常按请求量扣未来卖单；最终行动与影子账可能不一致。

**改动机制：** 首先审计当前载体是否存在请求债务；若有，只针对该层用下一观测、单位后库存及双边槽位重建实际成交，再扣后续欠额。B可用其账本检查预测与最终出单差。未发现该类账本时不做改动。

**准备规模：** 中：1天；跨两回合队列与数据契约

**前提：** 必须保留原订单槽位和双方同时报价语义；不能从净现金单独推每个商品数量。

**反例：** 持有库存下降可能来自取物或生产消耗；误把它当卖出同样会错扣。A底层此缺陷尚未在本轮确认。

**最小验证：** 先在现有完整记录离线对账；S只比较已确认的债务修复，冻结生产动作。H对近镜像与异族分别验收。

**通过/否决：** 确定性账本残差应为0；行为变更另过H，账本正确本身不能证明策略收益。

**指标：** 请求/成交/未来扣量差；槽位变化；现金与每商品库存残差；重复出售/过度抑制；终局净收益

**公开出处：** [真实成交账本](https://www.kaggle.com/code/az05192000gmailcom/kaggriculture-from-orders-to-actual-trades), [三日片段与可接续状态](https://www.kaggle.com/code/yhay81/fieldbook-commit-for-three-days), [联合动作顺序与末期修复](https://www.kaggle.com/code/mohui666/kaggriculture-v66-public-agent), [局部bandit与反例](https://www.kaggle.com/code/bruceqdu/two-reinforcement-learning-examples-from-kaito-v27), [高赞演进中的失败实验](https://www.kaggle.com/code/raykkretzschmar/kaggriculture-findings-from-zero-to-top-meta)

**代码落点：** [agents/route_clustering_switch_agent/runtime/meta_agent/src/teammate_expanded_routes.py:73](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/teammate_expanded_routes.py#L73), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/local_sale_timing.hpp:52](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/local_sale_timing.hpp#L52)

## E01 把12瓜作为候选组合，比较前缀后安全接管

**目标：** B

**类别：** 经济策略

**优先级：** P0

**对应弱点：** 尚不清楚是自主开局组合弱，还是任何12瓜状态都接管不好。

**改动机制：** 诊断三组：当前自主、经核对的12瓜短前缀后由同一B接管、B自己规划的12瓜目标候选。前缀只是定位价值上限，最终候选须按实际种子/水/工人完成计划。

**准备规模：** 中：1–2天准备；不等于直接照搬24步

**前提：** 明确我方开局与对手12瓜两个维度；不得用父报告的我方m12结果替代对手分组。

**反例：** 瓜占资金到收获，双方都集中卖瓜可能压价；第一天不应强行买齐导致雇工/浇水链失败。

**最小验证：** S用2×3分组：对手12瓜/非12瓜 × 三种我方开局；H仅验收实际可部署候选。

**通过/否决：** 若固定前缀强、自主候选弱，查组合枚举/估值；两者都弱查接管/市场。只有可部署组通过H才采纳。

**指标：** day1实际播种及水状态；第一批瓜的成熟量/采售时点；现金最低点；day10/12可再投资现金；终局胜负

**公开出处：** [作物、工时与早期现金回款](https://www.kaggle.com/code/georgymamarin/kaggriculture-visualized-what-every-crop-pays), [三日片段与可接续状态](https://www.kaggle.com/code/yhay81/fieldbook-commit-for-three-days), [Thomas：五路线稀疏路由](https://www.kaggle.com/code/thomastschinkel/kaggriculture-95-5-win-rate-via-replay-routing), [12瓜开局与劳动冲突复盘](https://www.kaggle.com/code/moushunchen/twelve-seeds-three-melons)

**代码落点：** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp:8](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp#L8), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp:426](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp#L426), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp:336](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp#L336)

## E02 预览淘汰后补选一小组便宜项目

**目标：** B

**类别：** 经济策略

**优先级：** P0

**对应弱点：** 昂贵高估值项目被预览剔除后，同循环没有重新枚举便宜替代。

**改动机制：** 在剔除发生时，仅对空出的近棚位试1–2个低资金/短回款候选，再用同一执行预览与共同估值比较KEEP。控制次数，保留已付款承诺；不重新优化整场。

**准备规模：** 中：1–2天；核心局部候选逻辑

**前提：** 先证明真实失败日出现剔除且日内admission没及时补回；若无该现象，不应优先实现。

**反例：** 小项目会占满工时或阻碍次日牲畜/土地投资；空位不总意味着闲置资源。

**最小验证：** S原规划与一次补选对照，不同时改变现金估值；H记录所有被替代项目的后续机会成本。

**通过/否决：** 通过须真实启动改善且H不损害原义务与终局收益；仅把空格种满不算成功。

**指标：** deferred与补选启动数；可用工时/现金闲置；首产首售；day3/6现金；原有义务完成率；最终胜负

**公开出处：** [资金保护的失败实验](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit), [独立生产骨架搜索](https://www.kaggle.com/code/destbreso/island-ga-an-owned-schedule-is-a-moat), [作物、工时与早期现金回款](https://www.kaggle.com/code/georgymamarin/kaggriculture-visualized-what-every-crop-pays)

**代码落点：** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp:426](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp#L426), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp:336](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp#L336)

## E03 短周期现金桥接：小麦/胡萝卜后转瓜或畜牧

**目标：** B

**类别：** 经济策略

**优先级：** P1

**对应弱点：** 长周期资产过早吃掉现金，下一轮采购和维护被拖延。

**改动机制：** 扩展已有少买牲畜→1/2格小麦→后继作物的联合候选：只新增小规模胡萝卜现金桥及2/4格容量。把销售到账后的种子和雇工成本逐时预约，比较相同事件终点。

**准备规模：** 中到大：2–3天准备；联合事件约束

**前提：** 按可实现成交价而非挂牌价计回款；后继不是无限轮作，也不能提前花尚未到账的收入。

**反例：** 市场中小麦也是饲料，先卖后高价买回可能亏；桥接耽误高价值首产时也可能更差。

**最小验证：** S当前joint、麦桥扩展、萝卜桥三个有限候选；统一终点至后继启动完成再比较，H验证其余世界。

**通过/否决：** 否决靠未兑现库存抬高预测值但没有改善后继启动的组合；通过需H实际经济增益。

**指标：** 第一笔可自由再投资现金；融资成本；后继实际启动延迟；缺料/缺工次数；day6/10/12净资产与现金；终局收益

**公开出处：** [作物、工时与早期现金回款](https://www.kaggle.com/code/georgymamarin/kaggriculture-visualized-what-every-crop-pays), [需求容量与经济推导](https://www.kaggle.com/code/destbreso/kaggriculture-how-much-money-is-in-this-game), [资金保护的失败实验](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit), [独立生产骨架搜索](https://www.kaggle.com/code/destbreso/island-ga-an-owned-schedule-is-a-moat)

**代码落点：** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/joint_candidates.hpp:7](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/joint_candidates.hpp#L7), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp:40](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp#L40)

## E04 按实际有效工时标定雇工与行动影子成本

**目标：** B

**类别：** 经济策略

**优先级：** P1

**对应弱点：** labor_hours=10和work_price=4可能与真实多工人效率失配。

**改动机制：** 记录每个项目的取物/走路/服务/回棚/闲置，先校准劳动预测误差，再试窄网格。保留工资与机会成本分项；不直接把work_price归零，也不按HIRE次数评价劳动价值。

**准备规模：** 中：1–2天数据整理；已有alternative第7组可作保守工时参照

**前提：** 真实雇工日边界、递增雇用费、同一天剩余工时及联合任务不得双计。

**反例：** 每次动作影子成本不是工资，它可能在压制冗余劳动；单纯减小会鼓励低效大畜群。

**最小验证：** S仅2×2窄网格（工时10/13，影子成本4/2），生产和市场机制保持一致；不用H继续调网格。

**通过/否决：** 通过需预测误差下降并带来H收益；工人多了/少了或模拟评分上升都不够。

**指标：** 预测/实际有效工时误差；新增工人的边际现金；重复任务与空跑；维护丢失；首回款与终局胜负

**公开出处：** [作物、工时与早期现金回款](https://www.kaggle.com/code/georgymamarin/kaggriculture-visualized-what-every-crop-pays), [资金保护的失败实验](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit), [完整经济链与失败分支](https://www.kaggle.com/code/dmitriigluzdov/kc-what-we-learned-historical-lb-1637), [12瓜开局与劳动冲突复盘](https://www.kaggle.com/code/moushunchen/twelve-seeds-three-melons)

**代码落点：** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp:48](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp#L48), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp:8](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp#L8)

## E05 首个生产周期内加强回款约束与滚动预演

**目标：** B

**类别：** 经济策略

**优先级：** P1

**对应弱点：** 默认一天条件预演后依赖近似尾部资产价值，可能提前兑现尚需运输的产出。

**改动机制：** 先仅day0–3比较scenario=1与3；再独立加入未来72步现金低点和最早可到账时间约束。保持负现金惩罚已有risk=1，新增的是时点可实现性。联合候选已有更长事件预演，不重复宣称所有路径只有一天。

**准备规模：** 中：开关小，时点约束1–2天；运行量可能显著增加

**前提：** 先冻结已验证引擎、统一尾值并检查单步时间；条件场景没有真实对手和未来杂草。

**反例：** 错模型多看两天会放大偏差；只增加horizon不一定改善。

**最小验证：** 先S比较1/3辨别视野收益，再将到账约束作为第二个独立实验；H只确认一个冻结实现。

**通过/否决：** 超过时间预算或预测更远却误差更大则否决；通过须H真实收益和完整执行同时成立。

**指标：** 候选排名翻转；预计/实际首售时点误差；最小现金；未兑现资产占比；day12资本；单步尾延迟；终局胜负

**公开出处：** [真实成交账本](https://www.kaggle.com/code/az05192000gmailcom/kaggriculture-from-orders-to-actual-trades), [资金保护的失败实验](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit), [三日片段与可接续状态](https://www.kaggle.com/code/yhay81/fieldbook-commit-for-three-days)

**代码落点：** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp:40](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp#L40), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/public_flow_scenario.hpp:7](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/public_flow_scenario.hpp#L7), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp:63](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp#L63)

## E06 按边际需求缺口分散生产，而非追逐当前最高价

**目标：** A+B

**类别：** 经济策略

**优先级：** P2

**对应弱点：** 新公开开局集中涌入会改变奶/羊毛/瓜的价格与再投资窗口。

**改动机制：** 按已经公开的商店、对手资产年龄及实际近期供给，比较未来3/6日增产的边际成交收入；把饲料与肥料副产品一并计入。优先在B现有候选中加受限少量番茄/草莓或牲畜比例候选，A只用于选后缀。

**准备规模：** 中到大：2–3天准备；需求/供给模型

**前提：** 同商品无商店仍有基础需求；公开资产产量与实际卖出量分开，不能猜对手私有库存。

**反例：** 盲目分散可能牺牲近棚布局与熟练物流；晚增牛在fresh样本未触发不证明一般有效。

**最小验证：** S比较当前收益与边际收入候选排序，分Yarn/奶类/其它已知商店；H新增未用于选择的对手族。

**通过/否决：** 通过须净现金和胜负改善；仅产量增加或对手现金下降而自己损失更多则否决。

**指标：** 单位增产带来的真实成交收入；饲料/劳工/配送成本；双方收益分解；未售库存；分族胜负

**公开出处：** [Soil V34：劳力、补麦与牲畜](https://www.kaggle.com/code/prvsiyan/kaggriculture-frontier-the-soil-remembers-rain), [需求容量与经济推导](https://www.kaggle.com/code/destbreso/kaggriculture-how-much-money-is-in-this-game), [作物、工时与早期现金回款](https://www.kaggle.com/code/georgymamarin/kaggriculture-visualized-what-every-crop-pays), [分开生产与市场的行为分析](https://www.kaggle.com/code/destbreso/a-week-four-x-ray-of-the-top-twelve), [未来商店的条件风险](https://www.kaggle.com/code/busyaprime/one-town-in-three-has-no-yarn-store-at-all)

**代码落点：** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp:63](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp#L63), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp:8](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp#L8), [agents/route_clustering_switch_agent/runtime/meta_agent/src/route_switch_features.py:269](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/route_switch_features.py#L269)

## O01 时间留出＋同源去重＋新对手反应测试

**目标：** A

**类别：** 其他值得尝试

**优先级：** P0

**对应弱点：** 旧回放代表的交叉验证无法覆盖之后出现的互动策略。

**改动机制：** 保持A现有seed/族CV，加按公开版本出现时间划分的外层留出；将生产带与市场控制分开聚类，对实际新公开Agent闭环验证。训练中仍保留旧强族，避免只记最新一批。

**准备规模：** 中：1–2天评估整理；不需先加大模型

**前提：** 基于时间与源码哈希冻结对手；日期字段是实际运行/版本时间，不用Notebook复制时间冒充策略新鲜度。

**反例：** 只换seed仍同一生态；11个名字高度同源会给虚假稳定性。

**最小验证：** 旧窗口训练，中间窗口选型，最后窗口固定验证；重复至少三个历史时间切分，记录每次允许使用的信息。当前没有新增Replay下载。

**通过/否决：** 通过须相对原A在未来窗口持续改善；若只有同源池上涨，不能声称延长有效期。

**指标：** 分日期/分族配对胜负；最差族及未见族收益；有效独立生产/市场簇数；切换激活率和收益衰减

**公开出处：** [局部胜率排名倒转](https://www.kaggle.com/code/dariushafshar/18-144-episodes-local-win-rate-ranks-backwards), [固定种子不固定商店](https://www.kaggle.com/code/yhay81/your-seed-does-not-fix-the-town), [路线同源与表面多样性](https://www.kaggle.com/code/destbreso/can-i-clone-you-from-your-dna), [分开生产与市场的行为分析](https://www.kaggle.com/code/destbreso/a-week-four-x-ray-of-the-top-twelve), [高分抢售方案的跨族失败](https://www.kaggle.com/code/boatlee/84-84-base-public-holdout-v14-clone-preemption)

**代码落点：** [agents/route_clustering_switch_agent/scripts/train_robust_search_route_trees.py:374](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/scripts/train_robust_search_route_trees.py#L374), [agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py:59](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py#L59)

## O02 族代表附近做执行质量筛选

**目标：** A

**类别：** 其他值得尝试

**优先级：** P1

**对应弱点：** 距离medoid未必是该族可执行性或实战最好的载体。

**改动机制：** 保留原意图距离和族定义，仅从medoid近邻中挑少量候选，用已确认生产失败、资本缺口及直接对战选择载体。质量不进入聚类距离，避免把赢家相似误当计划相似。

**准备规模：** 中：1天整理；对战规模取决于候选数

**前提：** G编号随整体聚类变化；若更新库须重建族→路线映射及模型，禁止直接拼旧编号。

**反例：** 只按历史输赢挑代表会带入对手/世界偏差；低支持长尾高收益也可能是偶然。

**最小验证：** 每个活跃族至多3个近邻，S冻结对手池后选一个，H测试；先4个实际在线输出族，不重跑全部175互打。

**通过/否决：** 通过须H收益并保留族语义；只降低距离或挑到历史高分不够。

**指标：** 实际生产硬失败；路由接续率；直接对战配对收益；族距离与覆盖；未来窗口稳定性

**公开出处：** [直接评价路线而非原选手分数](https://www.kaggle.com/code/rogerrogerroger3r/the-best-player-s-tape-is-not-the-best-tape), [三日片段与可接续状态](https://www.kaggle.com/code/yhay81/fieldbook-commit-for-three-days), [资金保护的失败实验](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit)

**代码落点：** [agents/route_clustering_switch_agent/docs/宏观路线去重聚类与切换搜参.md:106](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/docs/宏观路线去重聚类与切换搜参.md#L106), [agents/route_clustering_switch_agent/scripts/train_robust_search_route_trees.py:374](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/scripts/train_robust_search_route_trees.py#L374)

## O03 学习“切换增益”与拒绝区，而不是继续细化旧阈值

**目标：** A

**类别：** 其他值得尝试

**优先级：** P1

**对应弱点：** 147维输入实际由少数市场阈值决定，只有4个有效输出族且缺在线不确定性门。

**改动机制：** 将已配对反事实转成相对KEEP的收益/退步标签；用公开增量供给、资产年龄与接续缺口训练浅模型，保留拒绝切换区。先比较同样小模型，不默认上大LGBM。

**准备规模：** 中到大：2–3天训练管线整理

**前提：** 特征只截到决策时刻；同一seed/对手/座位反事实状态一致，未来实际成交不能进入当前输入。

**反例：** 胜负并列用细现金差挑标签可能噪声大；拒绝区过宽会只剩固定G001。

**最小验证：** 在O01时间留出协议下比较原树、相对收益树、加拒绝区，保持候选和切换次数相同。

**通过/否决：** 通过以H收益而非标签accuracy或R²；门控少切却没改善不能认定成功。

**指标：** 相对KEEP的收益校准；错误切换代价；覆盖率/拒绝率；未见族收益；未来窗口胜負

**公开出处：** [未来预测中的标签泄露反例](https://www.kaggle.com/code/jominurk21cs1077/opponent-economy-forecast-300-to-719-top40), [局部bandit与反例](https://www.kaggle.com/code/bruceqdu/two-reinforcement-learning-examples-from-kaito-v27), [局部胜率排名倒转](https://www.kaggle.com/code/dariushafshar/18-144-episodes-local-win-rate-ranks-backwards), [真实成交账本](https://www.kaggle.com/code/az05192000gmailcom/kaggriculture-from-orders-to-actual-trades)

**代码落点：** [agents/route_clustering_switch_agent/scripts/train_robust_search_route_trees.py:374](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/scripts/train_robust_search_route_trees.py#L374), [agents/route_clustering_switch_agent/runtime/meta_agent/src/route_switch_features.py:269](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/route_switch_features.py#L269), [agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py:59](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py#L59)

## O04 用路线意图给B提候选，由B完成真实工作链

**目标：** A+B

**类别：** 其他值得尝试

**优先级：** P2

**对应弱点：** A候选强但依赖动作带，B执行自适应但经济组合可能不够好。

**改动机制：** 从少量已验证路线抽取未来3日目标资产、扩地与回款事件，作为B额外候选；不把工人逐步动作带交给B。B按真实资源编译、与自主KEEP在同一事件终点竞争，只执行首步后重估。

**准备规模：** 大：3–5天以上；接口与执行验证为主要成本

**前提：** 先从1–2条经过O02选择的前缀一致路线做起；已付款和正在维护的资产是硬约束。

**反例：** 少量路由意图可能破坏B承诺/重新规划；直接照搬尚未成立的未来布局会放大失配。

**最小验证：** S自主B、原A、B加意图候选三组；额外分析候选被拒与执行后偏移。H采用新公开族和12瓜对手。

**通过/否决：** 通过须超越强的R1或A基线而非仅胜弱R2；若只复制原带或破坏义务则否决。

**指标：** 候选采纳率；计划/真实资产差；义务保留；早期资金和工时；跨族胜負；单步尾延迟

**公开出处：** [三日片段与可接续状态](https://www.kaggle.com/code/yhay81/fieldbook-commit-for-three-days), [分段路由与边界融资](https://www.kaggle.com/code/yhay81/six-day-public-state-fieldbook), [独立生产骨架搜索](https://www.kaggle.com/code/destbreso/island-ga-an-owned-schedule-is-a-moat), [资金保护的失败实验](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit)

**代码落点：** [agents/route_clustering_switch_agent/runtime/meta_agent/src/teammate_expanded_routes.py:73](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/teammate_expanded_routes.py#L73), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp:8](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp#L8), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/joint_candidates.hpp:7](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/joint_candidates.hpp#L7), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp:40](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp#L40)

## O05 让学习器先解决单个有证据的局部决策

**目标：** A+B

**类别：** 其他值得尝试

**优先级：** P2

**对应弱点：** 全季学习/大树投入高，旧数据误差会被长程放大。

**改动机制：** 选一个已有反例的卖出等待、末期采收或日内采购决策，用KEEP与一个可行动作做小型bandit/搜索；记录真实因果配对收益，再决定扩展。

**准备规模：** 中：1–2天局部样例；不含扩大训练

**前提：** 生产基线固定，修改最终实际动作并反馈状态；不可用随机奖励或预填表当训练结果。

**反例：** 公开教学中固定延迟平均为负，状态选择增益也仅小额；不能承诺局部赚钱就能进金牌。

**最小验证：** S固定单一事件和两个动作，不同时调多个时点；H保留全部未触发局，分别报触发条件下与总体效果。

**通过/否决：** H局部收益明确且整体无实质退步才扩展；只在筛选展示局有效则停留研究。

**指标：** 触发率；真实成交/收获；局部配对收益分布；总胜負；新对手迁移；运行时间

**公开出处：** [局部bandit与反例](https://www.kaggle.com/code/bruceqdu/two-reinforcement-learning-examples-from-kaito-v27), [局部终局搜索与蒸馏](https://www.kaggle.com/code/bruceqdu/reinforcement-learning-and-mcts-a-tutorial), [真实成交账本](https://www.kaggle.com/code/az05192000gmailcom/kaggriculture-from-orders-to-actual-trades)

**代码落点：** [agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py:59](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py#L59), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/local_sale_timing.hpp:52](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/local_sale_timing.hpp#L52), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp:40](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp#L40)

