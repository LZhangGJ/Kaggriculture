# Validate the evaluation setup and cash flow before expanding the model

The most transferable ideas in the public material concern **production plans, market transactions, executable task chains, and credible evaluation**. Repeated publication and upvotes do not establish that a strategy is independent. Even an impressive offline win rate may measure performance only against closely related action tapes. This report retains the reviewed sources and connects their findings to the two implementations selected by the team.

| Priority | Scheme A: route clustering and switching | Scheme B: three-layer planning |
|---|---|---|
| Strongest code evidence | Three shallow trees, at most one switch, five effective market/shop signals, four output families | Project-level DP, a greedy portfolio, and limited conditional lookahead; rotation and repetition are disabled by default |
| Hypotheses to test first | New interactive opponents invalidate old market thresholds; the final trees omit continuation-state compatibility; no route recovery after the first switch | A mirrored opening supply prior; a shared objective that heavily penalizes opponent profit; misalignment among cash arrival, hiring, and project startup windows |
| First experiments | T04 actual-state compatibility gate; O01 temporal and family holdouts; then O02 carrier selection | T01 opening-prior ablation; T02 opening competition weight; then E02 replacement candidates after preview rejection |
| Economic direction | Short-horizon goals and feasible continuation boundaries, rather than many more related full-season tapes | E01 a 12-melon candidate versus prefix takeover; E03 a short-cycle cash bridge; E04 actual marginal labor costs |
| Conclusions not established | The team reports roughly two-day decay, but no matched deployment time series establishes its cause | No per-game early-season ledger establishes the main cause; the execution repair reduced unresolved events without increasing wins in the saved panel |

**A 12-melon opening is not a complete opponent strategy.** It describes only part of the opening; subsequent livestock, hiring, cash realization, and preemptive selling can differ. Under the frozen constants that were inspected, seeds for 12 plants cost 960. With ideal water conditions, a plant can reach 6 units at age 10. This does not imply a guaranteed sale on day 10, and it excludes labor, delivery, and shared-market effects. Opponents using this opening and our own 12-melon prefix followed by takeover require separate experiments. [Crop and labor analysis](https://www.kaggle.com/code/georgymamarin/kaggriculture-visualized-what-every-crop-pays) · [Opening failure retrospective](https://www.kaggle.com/code/moushunchen/twelve-seeds-three-melons)

All 16 cards are **proposed experiments**, not patches with measured gains. The research did not modify the team's Agents, train a model, or run new matches. Effort estimates describe preparation complexity; actual elapsed time depends on the evaluation infrastructure.

## Transferable mechanisms in the public solutions

| Research area | Representative sources | Useful transfer to A and B | Claims that cannot be inherited |
|---|---|---|---|
| Production plans and segmented routing | Thomas, Ahmed, Shop Router, Six-Day, Fieldbook | Shared prefixes, continuation at specific boundaries, distinct production families | Different names do not prove different production plans; author-reported win rates are not live performance |
| Market control over fixed production | Kaito conditional memory, Boatlee preemption, Mohui | Preserve order slots, reconcile actual fills, verify behavior after exact triggers | Thirty memories are not thirty farms; exact signatures do not establish generalization |
| Active execution and logistics | Reactive, Mohui, funding-failure audit | Atomic planting, actual worker counts, actor-specific reservations, commitment completion | Removing invalid actions does not recover lost output; DONE does not establish economic health |
| Feedback between production and markets | Soil V34, Moon V39 | Separate output, own cash, opponent cash, and final outcomes | More production is not necessarily more profit; gains against related opponents may not transfer |
| Independent economic planning and search | Island GA, readable dynamic-task implementations, Scheme B | Independent season-level intent, bounded candidate sets, feasible execution | Missing private final executors prevent reproducing top claims; algorithm names are not execution evidence |
| Learning small decisions | Bruce's local bandit and endgame search | KEEP controls, actual transitions, limited interventions, failure cases | A small tutorial gain is not evidence of full-season RL or medal-level performance |
| Evaluation and population change | 18,144-game analysis, seed/town analysis, behavioral X-rays | Temporal holdouts, family deduplication, actual-fill labels, divergent worlds | Aggregate statistics, simulated examples, and leaderboard scores are different evidence types |

## Recent implementations and older analysis

Prioritize submittable Agents by their actual run/version time, scores tied to that version, and readable implementation: for example, Ahmed's recent production combinations, the latest reviewed Soil/Moon versions, and recent routing or market-control layers. Revisit superseded submissions when they explain a specific mechanism or failure. Retain valuable analysis regardless of age: order-to-fill reconciliation, a funding safeguard that lost all 48 games, same-seed world divergence, and local-bandit counterexamples can be more useful than a newly repackaged Agent.

"Recently run" may mean an old source was repackaged. Title scores, historical Best, current-version Public scores, and actual online Agent performance are recorded separately. Sorting this index is a research aid, not a live strength ranking.

## Suggested sequence

1. Establish O01 evaluation groups and cash/fill logs. Keep R1, R2, and the deployed A implementation as separate baselines.
2. Prepare T01, T02, and T04 independently. Screen each change separately; freeze only a clearly promising candidate for confirmation on fresh seeds.
3. Use the logs to prioritize E02 replacement candidates, E01 opening candidates, E03 cash bridging, or E04 labor calibration. Deprioritize interventions whose prerequisite symptom is absent.
4. If A still underperforms in a genuine future window, consider O02/O03. Consider O04 only after establishing stable gains. Do not combine every change into one experiment.


# The two selected implementations: provenance and targeted findings

Research date: September 11, 2026. This was static source inspection, literal-payload decoding, and recomputation of saved results. It did not execute Agents, train models, run matches, or make new Kaggle requests. Superseded early submittable Agents are no longer mandatory version-by-version reading. Independent mechanisms, experiments, and failure analyses remain in scope.

## Source identity and reading scope

**Scheme A** is the team-selected `main/agents/route_clustering_switch_agent`, pinned to commit `eec409775bc538cf65b3676172ee3ce741ca2469`. The 74 files were read from existing local Git objects and their Git blobs verified. This is not the separate local 710-route experiment. Full reads covered the README, SOURCE_PROVENANCE, route-methodology documentation, runtime entry point, three routing/feature/carrier-adapter modules, and robust-tree training script. The final single-file artifact was inspected only through AST and literal base85/zlib decoding: 17 function/class ASTs matched the runtime modules exactly, carrier source and action-tape bytes matched, and policy/metadata JSON matched. Embedded exec statements were not run. Binding 74 files is not a claim of reading every line. The 547,143-byte base executor was identity-bound in this pass; its unaudited branches are not confirmed defects.

**Scheme B** is the selected AFS workflow repair package, pinned to commit `4ef9875968f7104f26fc3140bd28b988101579f8`. All 130 manifest entries were SHA256-bound, including both actual `agent.so` binaries. Most matched existing experiment files byte-for-byte; a few were obtained through the GitHub connector. The 130 count measures manifest binding, not full reads. Full reads covered R1's `triad.hpp`, `planner.hpp`, `search.hpp`, `proposals.hpp`, `joint_candidates.hpp`, `startup_supply.hpp`, `public_flow_scenario.hpp`, `local_sale_timing.hpp`, configuration, parent report, and acceptance reports. All R1-to-R2 differences along these economic paths and the relevant projection-switch changes were inspected. The peripheral workflow-repair implementation and 120 KB executor are outside this pass's full-reading claim. `saved_result_audit178.json` validates 3,300 saved result rows and paired differences between the two R2 configurations. This is recomputation of result files, not a new experiment.

## A: robust training exists, but the deployed decision space is narrow

The team describes A as Top40 clustering plus LGBM. The designated artifact actually exports three shallow `DecisionTreeClassifier` trees. It opens with G001, checks at steps 144/168/216, and switches at most once. Its 175-route library, 11 training candidates, and effective online choices are different counts.

Feature-index mappings were checked against the feature definitions. Seven features appear structurally, but splits on wool inventory and wool price ultimately produce the same actions on both sides. Removing those redundant splits leaves five effective signals: the yarn shop, milk price, and tomato/strawberry/milk inventories. Effective outputs are only G001/G006/G036/G169. Own cash, opponent assets, historical losses, and future route funding requirements do not affect the final leaf selection among the 147 inputs. At step 216 the rule reduces to "yarn shop present: G036; otherwise: keep G001," provided no earlier switch occurred.

The training code does include seed-group and opponent-family cross-validation, threshold perturbation, and bootstrap. It would be incorrect to claim no overfitting safeguards. However, the author's 256-new-seed holdout still used the same 175 replay representatives; it did not establish transfer to later interactive opponents. The reported +8.44 percentage points is a saved author result, not an independently rerun or online gain from this research. The team's observations of three gold-zone runs and roughly two-day decay are retained as observations without a matched time series proving causation.

Priority hypotheses: new opponents alter supply and preemptive-sale timing, so old absolute inventory thresholds no longer imply the same future; route suffixes lack an explicit actual-state compatibility gate; and there is no recovery-route choice after the one permitted switch. These hypotheses do not yet explain all performance decay.

## B: a three-layer design, not exhaustive whole-farm planning

The three-layer structure is real, but the implemented process is project-lifecycle DP, incremental plot-by-plot portfolio construction, and a finite set of parameter candidates with conditional rolling lookahead. With `rotation=0` and `repeat=0`, the existence of rotation-DP interfaces does not imply that all season-long rotations are planned by default. `portfolio_passes=6` plus `candidate_extra=1` generates nine settings before deduplication by actual goals and queues; it does not always produce nine distinct economic routes.

With default `scenario=1`, ordinary candidates advance one day in a conditional scenario and then use a residual asset valuation. Joint candidates involving fewer livestock purchases, wheat, and a successor crop have a longer event-driven preview. Existing alternatives already include higher discounting, crop/animal preferences, competition weights at half and 1.5 times the base, higher reserves, and short-term financing settings. Recommendations must not present these as entirely missing features.

- At the first step, the opponent prior mirrors our planner on the opponent's visible empty farm. Startup supply mode 2 gives this prior full weight; it is cleared for `day>0`. It may distort the initial portfolio against different openings, but this requires an ablation.
- The cash budget includes current cash, 85% of quoted shed inventory, a reserve, and one feed wave. The profit model also penalizes negative daily cash with `risk=1`; liquidity constraints are not absent. However, output entering a daily revenue stream has not necessarily completed harvesting, delivery, storage, and sale. Execution preview corrects some of this mismatch; tail valuation remains approximate.
- After greedy project admission, at most three preview passes remove unpaid projects that cannot start. The loop revalues and prepares orders without re-enumerating cheap alternatives inside that same loop. Later intraday admission can still start projects. Investigate missed startup windows, rather than asserting permanent all-day idleness.
- Labor valuation combines nonlinear hiring cost based on `labor_hours=10` with an action shadow cost of `work_price=4`. The latter can represent opportunity cost; calling it erroneous double counting without calibration would be unjustified. Misalignment with actual multi-worker logistics is testable.
- The current competition weight is 2. It may favor slower own cash realization to suppress opponent profit. Candidates already explore weights 1 and 3, but final selection still uses the shared `base.competition=2` objective. Changing a candidate and changing the final objective are different ablations.
- `PublicFlowScenario` projects public supply with default arrival windows 1/17. It does not run the actual opponent, disables new weeds, and uses expected demand for unknown shops. Its scores are conditional predictions, not guaranteed future outcomes.
- Local sale timing mode 1 does not use rival quantity. Recording that quantity in a ledger does not establish that all decisions exploit the opponent's sale timing.

## What the saved evaluations establish

On the same 50-seed × 11-opponent-name × two-seat panel, R1 on recorded **856 wins / 4 ties / 240 losses**, versus **824 wins / 4 ties / 272 losses** for R2 on. R2 audit versus on changed the action hash in only the two seats of one seed. In each seat, own cash increased by 658, opponent cash fell by 815, and the margin improved by 1,473, from -2,360 to -887. Neither loss became a win. Unresolved workflow events fell from 40 to 0. This supports a local execution repair, not a stronger overall economy. R1/R2 also differ in economic candidates and workflow behavior; the 32-win gap cannot be assigned entirely to one switch.

The aggregate results for `aurax_reactive_v1` and `moon_v215` match exactly, as do those for `flexon_v5` and `seven_turn`. This establishes at least substantial outcome redundancy, not identical source code. Eleven names should not automatically count as eleven independent families. Both versions beat `nagatakengo_v70` in all 100 games, with a much larger mean margin than against the other opponents, materially inflating the overall average cash margin.

The parent report's 264 default-versus-m12 takeover games use only three seeds. Here m12 means **our own external 24-step opening**, not an opponent using 12 melons. New validation should classify opponents by actual planting during steps 24/48, subsequent livestock, and market control, not by names or titles alone.

## Completion under the revised scope

The main archive contains 514 reviewed Notebooks: 508 individual reviews and six exact-duplicate inheritances. There are also 37 early supplements and 119 accepted targeted historical originals. These do not constitute 670 independent Agents. Old followups track evidence; missing raw matches, unpublished private components, and unresolved historical identities remain explicit, but each is not automatically a new mandatory solution to read.

Jocelyn still has 210 nonempty peripheral modules that were not read in full. Its active entry point and two dependency chains already expose disconnected position, seed, and memory interfaces; current evidence does not require exhaustive reading of every inactive component for these strategy goals. Unrelated cross-competition analysis, superseded submittable versions, and unbound score-only claims are classified separately, not claimed as fully read.


# Shared experiment protocol

## S

Screening: 8 preregistered development seeds × K opponent groups deduplicated by source and behavior × both seats, or 16K games per candidate. Planned K=6 gives 96 games. Report the actual K if fewer independent groups are available; do not pad the pool with related forks. S is directional screening, not statistical confirmation.

## H

Freeze one promoted candidate, then test at least 32 fresh seeds unused in training, tuning, or screening × the same K groups plus unseen families × both seats. With K=6, this is at least 384 games per candidate. Expand to 64 seeds for small effects or uncertain tails if prespecified; otherwise retain INCONCLUSIVE. Do not keep checking batches until significance appears.

## pairing

Use matching seeds and both seats for candidate and baseline, preserving engine/config/source hashes. Seats and related opponents within a seed are not independent samples. Aggregate paired differences by seed for the primary analysis and report family-specific results. Use family-level holdouts/resampling when claiming transfer to new opponents.

## worlds

A fixed seed does not guarantee the same future shops or weeds. Standard environment tests estimate actual policy effects. Diagnostics with controlled exogenous events must be reported separately, not presented as standard matches. Never construct online features from hidden seeds or future events.

## endpoints

Preregister either final match-score improvement (win=1, tie=0.5, loss=0) or improvement in final cash margin. Record own and opponent cash changes separately. For early economics, preserve cash and liquidity on days 1/3/6/10/12, assets in transit/in the shed/not yet mature, and first-production, first-sale, hiring, and death events.

## gates

Win-improvement changes: the 95% lower confidence bound of the preregistered paired score difference must exceed zero, with no material deterioration beyond the preset 2-percentage-point guardrail in 12-melon/non-12-melon groups and major deduplicated families. Cash refinements: the paired cash-margin improvement must have a 95% lower bound above zero, plus match-score noninferiority within a preset 1-percentage-point margin. Insufficient power to establish noninferiority means INCONCLUSIVE. These thresholds are proposed decision rules, not proven optimal constants.

## health

Preserve complete terminal states/step counts, exceptions, actual PLANT/FEED/production/delivery/fills, storage overflow, action hashes, loaded binary/config identities, and per-step p99/max latency. DONE or zero unfilled market orders does not justify ignoring production failures.

## stopping

Screen first, then perform one confirmation stage. Ablate each mechanism independently. Report nonactivation, interface failures, timeouts, negative effects, and insufficient evidence separately. Keep R1/R2 separate; do not attribute different economic branches entirely to workflow repair.

## opponents

Include observed 12-melon openings with different later production/market control, non-12-melon dynamic economies, closely related preemptive sellers, different milk/wool supply patterns, and at least one reactive opponent with an independent active implementation. Names and scores do not substitute for behavior and source identity.


# Experiment cards

## T01 — Ablate the first-day mirrored supply prior

**Target:** B

**Group:** Quick experiments

**Priority:** P0

**Weakness:** The initial opponent forecast may assume that the opponent follows our economic plan.

**Mechanism:** Compare only R2_STARTUP_SUPPLY_MODE=0/1/2: no prior, half weight, and the current full mirrored prior. Keep all other settings, candidates, and repairs fixed. An opponent's eventual 12-melon opening is not initially visible information.

**Cost:** Small: a build switch; roughly half a day of preparation, excluding matches.

**Preconditions:** Run separate controls using the actual R1 and R2 release entry points. Label 12-melon opponents offline from actual behavior in completed games.

**Counterexample:** Removing the prior may hurt against a mirrored population. The prior is already cleared after day 0, so it cannot explain every late-game problem.

**Experiment:** Protocol S: three prior settings per version, 8 development seeds and both seats, stratified by 12-melon/non-12-melon opponents. Promote only one setting to H and freeze it without repeatedly selecting favorable seeds.

**Pass Fail:** Pass if H improves the primary endpoint in the 12-melon group without material overall match-score regression. If actions never change, the prior is not an active bottleneck in this panel; report nonactivation.

**Metrics:** Day-0 crop/animal targets; Actual projects started in the first 24/48 steps; First sale and spendable cash; Cash on days 3/6/10/12; Final own-minus-opponent cash

**Sources:** [Thomas: sparse routing across five routes](https://www.kaggle.com/code/thomastschinkel/kaggriculture-95-5-win-rate-via-replay-routing), [Separate production and market behavior](https://www.kaggle.com/code/destbreso/a-week-four-x-ray-of-the-top-twelve), [Your seed does not fix the town](https://www.kaggle.com/code/yhay81/your-seed-does-not-fix-the-town)

**Code:** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/startup_supply.hpp:5](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/startup_supply.hpp#L5), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp:40](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp#L40)

## T02 — Test a lower competition weight during the opening

**Target:** B

**Group:** Quick experiments

**Priority:** P0

**Weakness:** The shared competition weight of 2 may sacrifice early own cash realization.

**Mechanism:** Only during days 0–3, compare base.competition=2/1/0.5 in the final scoring objective, then restore 2. Align candidate tail valuation as well. Changing competition inside a candidate alone does not change the shared selection objective.

**Cost:** Small to medium: one phase switch and a scoring-consistency check.

**Preconditions:** Maintain separate own-cash and opponent-cash ledgers. First confirm that the setting changes the selected candidate.

**Counterexample:** In strongly contested wool/milk markets, a lower weight may increase our profit but increase the opponent's profit even more. The day-3 cutoff is a parameter to test, not a mechanism constant.

**Experiment:** In S, fix the day-0–3 window and compare 2/1/0.5 without searching cutoff days. H compares only the selected setting with the current baseline, reporting R1 and R2 separately.

**Pass Fail:** Reject if own cash rises but final match performance or the target opponent group deteriorates. Passing requires H's primary endpoint and family guardrails.

**Metrics:** Selected candidate and score decomposition; First production/first sale; Both players' cash on days 6/10; Final own and opponent revenue; Match outcomes against 12-melon openings

**Sources:** [Soil V34: labor, wheat replenishment, and livestock](https://www.kaggle.com/code/prvsiyan/kaggriculture-frontier-the-soil-remembers-rain), [Complete economic chains and failed branches](https://www.kaggle.com/code/dmitriigluzdov/kc-what-we-learned-historical-lb-1637), [A failed funding safeguard](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit)

**Code:** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp:40](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp#L40), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp:63](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp#L63), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp:8](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp#L8)

## T03 — Test the existing price-pressure delivery option

**Target:** B

**Group:** Quick experiments

**Priority:** P1

**Weakness:** Produced goods may remain outside the shed while cash is scarce. Current batch_delivery=1 does not enable the extra price-pressure trigger.

**Mechanism:** Test batch_delivery=2 alone and log whether already-feasible en-route returns to the shed increase. This adds conditional delivery to existing scheduling; do not simultaneously change hiring, pricing, or production.

**Cost:** Small: configuration and logging; roughly half a day of preparation.

**Preconditions:** Keep the fill ledger and atomic task constraints unchanged. Do not force empty trips on day 0 when there is nothing to sell.

**Counterexample:** Earlier returns may interrupt critical watering or feeding. Public Soil delivery changes include offsetting gains/losses and worse averages.

**Experiment:** S compares modes 1/2. First check whether days 1–12 cases with goods but no cash actually activate the change, then proceed to H.

**Pass Fail:** No meaningful activation is not an improvement. Reject irreversible production failures. Small cash gains without sufficient confidence remain inconclusive.

**Metrics:** Time goods remain carried; Actual shed deliveries and sales; Additional travel; Missed feeding/watering/deaths; Cash on days 6/10

**Sources:** [From orders to actual trades](https://www.kaggle.com/code/az05192000gmailcom/kaggriculture-from-orders-to-actual-trades), [A failed funding safeguard](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit), [Soil V34: labor, wheat replenishment, and livestock](https://www.kaggle.com/code/prvsiyan/kaggriculture-frontier-the-soil-remembers-rain)

**Code:** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp:70](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp#L70), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp:545](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp#L545)

## T04 — Gate route switches on actual-state feasibility

**Target:** A

**Group:** Quick experiments

**Priority:** P0

**Weakness:** The trees omit cash/worker/resource features and attach a suffix at the same time index.

**Mechanism:** First log, without changing decisions, the seeds, plots, workers, and funding needed by the next 24 suffix steps at 144/168/216. Then test blocking only demonstrably infeasible switches and choosing KEEP. Do not validate against a hypothetical shadow-expert state.

**Cost:** Medium: half a day to one day; logging first, then a minimal gate.

**Preconditions:** Use the actual current observation. Count only conservatively realizable sales in funding forecasts. Workers rehired across midnight cannot inherit old worker IDs.

**Counterexample:** Some strong suffixes tolerate small failures or delayed repair. An overly strict gate can reject useful switches, and KEEP may also lose.

**Experiment:** S compares the original tree, a gate for definitely missing assets, and a 24-step funding-gap gate. Save counterfactual outcomes for blocked branches. Promote only one version to H.

**Pass Fail:** Pass only if the gate blocks actually harmful switches and produces positive net gain in H. Reject a gate that reduces errors but also wins fewer games.

**Metrics:** Branch activation and rejection rates; Production completion in the next 24 steps; Missed feeding/whole-batch planting failures; Paired switching gain over KEEP; Final match outcomes

**Sources:** [Three-day fragments and feasible continuation states](https://www.kaggle.com/code/yhay81/fieldbook-commit-for-three-days), [Mohui: joint-action ordering and endgame repair](https://www.kaggle.com/code/mohui666/kaggriculture-v66-public-agent), [A failed funding safeguard](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit)

**Code:** [agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py:59](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py#L59), [agents/route_clustering_switch_agent/runtime/meta_agent/src/teammate_expanded_routes.py:73](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/teammate_expanded_routes.py#L73), [agents/route_clustering_switch_agent/runtime/meta_agent/src/route_switch_features.py:269](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/route_switch_features.py#L269)

## T05 — Reconcile shifted market orders against actual fills

**Target:** A+B

**Group:** Quick experiments

**Priority:** P1

**Weakness:** Public control layers often debit future orders by requested quantity even when final actions and shadow accounting diverge.

**Mechanism:** First audit whether the current carrier actually has request-based debt. If confirmed, reconstruct actual fills using the next observation, post-unit inventory, and both players' order slots, then debit future quantities. B can use its ledger to check predicted versus final orders. Do not change an implementation without this defect.

**Cost:** Medium: about one day for cross-turn queues and the data contract.

**Preconditions:** Preserve original order slots and simultaneous bilateral order semantics. Net cash alone cannot identify each commodity's filled quantity.

**Counterexample:** Inventory can fall because of worker pickup or production consumption. Treating that as a sale creates another accounting error. This defect in A's base executor was not confirmed in this research.

**Experiment:** Reconcile existing complete records offline first. S compares only a confirmed debt fix, with production actions frozen. H separately covers closely related and independent opponent families.

**Pass Fail:** Deterministic ledger residuals should be zero. Any behavioral change must separately pass H; correct accounting alone does not establish a strategic gain.

**Metrics:** Requested/filled/future-debited quantity differences; Order-slot changes; Cash and per-commodity inventory residuals; Repeated selling or excessive suppression; Final net gain

**Sources:** [From orders to actual trades](https://www.kaggle.com/code/az05192000gmailcom/kaggriculture-from-orders-to-actual-trades), [Three-day fragments and feasible continuation states](https://www.kaggle.com/code/yhay81/fieldbook-commit-for-three-days), [Mohui: joint-action ordering and endgame repair](https://www.kaggle.com/code/mohui666/kaggriculture-v66-public-agent), [Local bandits and counterexamples](https://www.kaggle.com/code/bruceqdu/two-reinforcement-learning-examples-from-kaito-v27), [Failures during a highly upvoted Agent's evolution](https://www.kaggle.com/code/raykkretzschmar/kaggriculture-findings-from-zero-to-top-meta)

**Code:** [agents/route_clustering_switch_agent/runtime/meta_agent/src/teammate_expanded_routes.py:73](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/teammate_expanded_routes.py#L73), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/local_sale_timing.hpp:52](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/local_sale_timing.hpp#L52)

## E01 — Compare a 12-melon candidate with safe prefix takeover

**Target:** B

**Group:** Economic strategies

**Priority:** P0

**Weakness:** It is unclear whether the autonomous opening portfolio is weak or whether takeover from a 12-melon state also performs poorly.

**Mechanism:** Diagnose three groups: current autonomous planning; a verified short 12-melon prefix followed by the same B; and a 12-melon goal candidate planned by B itself. The fixed prefix diagnoses potential value; the deployable candidate must satisfy actual seed, water, and worker constraints.

**Cost:** Medium: 1–2 days of preparation; this is not simply copying 24 actions.

**Preconditions:** Separate our opening from the opponent's 12-melon opening. The parent report's own-side m12 results cannot replace opponent stratification.

**Counterexample:** Melons tie up cash until harvest. Both players concentrating melon sales can depress prices. Buying every seed immediately must not break hiring or watering.

**Experiment:** S uses a 2×3 design: opponent 12-melon/non-12-melon × our three openings. H validates only the actually deployable candidate.

**Pass Fail:** If the fixed prefix is strong but the autonomous candidate is weak, inspect enumeration/valuation. If both are weak, inspect takeover/markets. Adopt only a deployable version that passes H.

**Metrics:** Actual planting and water state on day 1; First melon batch maturity/harvest/sale timing; Minimum cash; Reinvestable cash on days 10/12; Final match outcomes

**Sources:** [Crops, labor, and early cash realization](https://www.kaggle.com/code/georgymamarin/kaggriculture-visualized-what-every-crop-pays), [Three-day fragments and feasible continuation states](https://www.kaggle.com/code/yhay81/fieldbook-commit-for-three-days), [Thomas: sparse routing across five routes](https://www.kaggle.com/code/thomastschinkel/kaggriculture-95-5-win-rate-via-replay-routing), [A 12-melon opening and labor conflicts](https://www.kaggle.com/code/moushunchen/twelve-seeds-three-melons)

**Code:** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp:8](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp#L8), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp:426](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp#L426), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp:336](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp#L336)

## E02 — Refill rejected preview slots with a few cheap projects

**Target:** B

**Group:** Economic strategies

**Priority:** P0

**Weakness:** After preview rejects an expensive, highly valued project, the same loop does not re-enumerate cheap alternatives.

**Mechanism:** Only when rejection occurs, test 1–2 low-capital, fast-payback candidates for freed plots near the shed. Compare them with KEEP using the same execution preview and shared valuation. Limit attempts and preserve paid commitments; do not reoptimize the whole farm.

**Cost:** Medium: 1–2 days for local candidate logic.

**Preconditions:** First establish that real failing days contain rejections that intraday admission does not replace promptly. Without that symptom, implementation should not be a priority.

**Counterexample:** Small projects can consume labor or prevent next-day livestock/land investment. Empty plots do not always imply idle resources.

**Experiment:** S compares the original planner with one refill pass, without simultaneously changing cash valuation. H records the later opportunity cost of replaced projects.

**Pass Fail:** Pass only if actual starts improve without harming commitments or final returns in H. Merely filling empty plots is not success.

**Metrics:** Deferred and replacement project starts; Idle available labor/cash; First production and first sale; Cash on days 3/6; Completion of existing commitments; Final match outcomes

**Sources:** [A failed funding safeguard](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit), [Searching independent production plans](https://www.kaggle.com/code/destbreso/island-ga-an-owned-schedule-is-a-moat), [Crops, labor, and early cash realization](https://www.kaggle.com/code/georgymamarin/kaggriculture-visualized-what-every-crop-pays)

**Code:** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp:426](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp#L426), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp:336](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/triad.hpp#L336)

## E03 — Bridge cash with wheat/carrots before melons or livestock

**Target:** B

**Group:** Economic strategies

**Priority:** P1

**Weakness:** Long-cycle assets may consume cash too early, delaying the next purchase and maintenance cycle.

**Mechanism:** Extend the existing fewer-livestock → 1/2 wheat plots → successor-crop joint candidate with a small carrot bridge and 2/4-plot sizes. Reserve seed and hiring costs by hour after sales actually settle, and compare at the same event endpoint.

**Cost:** Medium to large: 2–3 preparation days for joint event constraints.

**Preconditions:** Value realizable fills rather than quoted prices. A successor is not unlimited rotation, and revenue cannot be spent before it arrives.

**Counterexample:** Wheat is also feed. Selling it and buying it back at a higher price may lose money. A bridge can also delay a valuable first production cycle.

**Experiment:** S compares the current joint candidate, an extended wheat bridge, and a carrot bridge. Compare at a common endpoint after successor startup completes; H tests other worlds.

**Pass Fail:** Reject combinations that inflate predicted value through unrealized inventory without improving successor startup. Passing requires an actual economic gain in H.

**Metrics:** First freely reinvestable cash; Financing cost; Actual successor startup delay; Material/worker shortages; Net assets and cash on days 6/10/12; Final return

**Sources:** [Crops, labor, and early cash realization](https://www.kaggle.com/code/georgymamarin/kaggriculture-visualized-what-every-crop-pays), [Demand capacity and economic estimates](https://www.kaggle.com/code/destbreso/kaggriculture-how-much-money-is-in-this-game), [A failed funding safeguard](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit), [Searching independent production plans](https://www.kaggle.com/code/destbreso/island-ga-an-owned-schedule-is-a-moat)

**Code:** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/joint_candidates.hpp:7](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/joint_candidates.hpp#L7), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp:40](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp#L40)

## E04 — Calibrate hiring and action shadow costs against effective labor

**Target:** B

**Group:** Economic strategies

**Priority:** P1

**Weakness:** labor_hours=10 and work_price=4 may not match actual multi-worker efficiency.

**Mechanism:** Log pickup, travel, service, return-to-shed, and idle time per project. Calibrate labor prediction error before a narrow parameter grid. Keep wages separate from opportunity cost; do not simply zero work_price or infer labor value from HIRE counts.

**Cost:** Medium: 1–2 days of data preparation. Existing alternative setting 7 provides a conservative labor reference.

**Preconditions:** Account for actual day-boundary hiring, increasing hire costs, remaining hours that day, and shared tasks without double counting.

**Counterexample:** Action shadow cost is not wages; it may suppress redundant work. Reducing it indiscriminately can encourage inefficient large herds.

**Experiment:** S uses only a 2×2 grid: labor hours 10/13 and shadow cost 4/2. Keep production and market mechanisms consistent. Do not continue tuning the grid on H.

**Pass Fail:** Prediction error must fall and H must improve. More/fewer workers or a higher simulated score alone is insufficient.

**Metrics:** Predicted versus actual effective labor error; Marginal cash from an additional worker; Duplicate tasks and empty trips; Missed maintenance; First cash realization and final match outcomes

**Sources:** [Crops, labor, and early cash realization](https://www.kaggle.com/code/georgymamarin/kaggriculture-visualized-what-every-crop-pays), [A failed funding safeguard](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit), [Complete economic chains and failed branches](https://www.kaggle.com/code/dmitriigluzdov/kc-what-we-learned-historical-lb-1637), [A 12-melon opening and labor conflicts](https://www.kaggle.com/code/moushunchen/twelve-seeds-three-melons)

**Code:** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp:48](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp#L48), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp:8](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp#L8)

## E05 — Strengthen cash-arrival constraints and early rolling lookahead

**Target:** B

**Group:** Economic strategies

**Priority:** P1

**Weakness:** Default one-day conditional lookahead relies on approximate tail asset value and may recognize output before its delivery chain finishes.

**Mechanism:** First compare scenario=1 versus 3 only during days 0–3. Separately test a cash-floor and earliest-realizable-revenue constraint over the next 72 steps. Keep existing risk=1; the addition concerns timing feasibility. Joint candidates already have longer event-driven previews, so not every path has a one-day horizon.

**Cost:** Medium: a small switch; 1–2 days for timing constraints. Runtime may increase substantially.

**Preconditions:** Freeze the validated engine, align terminal valuation, and check per-step runtime first. The conditional scenario lacks the real opponent and future weeds.

**Counterexample:** Two extra days in an incorrect model may amplify bias. A longer horizon does not necessarily help.

**Experiment:** S first compares horizons 1/3 to isolate horizon value. Test cash-arrival constraints as a second independent experiment. H confirms only one frozen implementation.

**Pass Fail:** Reject time-budget violations or longer forecasts with greater error. Passing requires actual H gains and complete execution.

**Metrics:** Candidate ranking reversals; Predicted versus actual first-sale timing; Minimum cash; Unrealized asset share; Capital on day 12; Per-step tail latency; Final match outcomes

**Sources:** [From orders to actual trades](https://www.kaggle.com/code/az05192000gmailcom/kaggriculture-from-orders-to-actual-trades), [A failed funding safeguard](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit), [Three-day fragments and feasible continuation states](https://www.kaggle.com/code/yhay81/fieldbook-commit-for-three-days)

**Code:** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp:40](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp#L40), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/public_flow_scenario.hpp:7](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/public_flow_scenario.hpp#L7), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp:63](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp#L63)

## E06 — Diversify by marginal demand gaps, not the highest current price

**Target:** A+B

**Group:** Economic strategies

**Priority:** P2

**Weakness:** New popular openings can shift milk/wool/melon prices and reinvestment windows.

**Mechanism:** Use visible shops, opponent asset ages, and actual recent supply to compare marginal realized revenue from added output over 3/6 days. Include feed and fertilizer byproducts. First add a few bounded tomato/strawberry or livestock-ratio candidates to B; use the signal only for suffix selection in A.

**Cost:** Medium to large: 2–3 preparation days for demand/supply modeling.

**Preconditions:** A commodity without a specialty shop still has base demand. Separate production implied by visible assets from actual sales, and do not guess private opponent inventory.

**Counterexample:** Blind diversification can sacrifice compact layouts and efficient logistics. A late-cow intervention that never activates in a fresh sample does not establish general usefulness.

**Experiment:** S compares current-value and marginal-revenue candidate rankings, stratified by known yarn/milk/other shops. H adds opponent families not used during selection.

**Pass Fail:** Require net-cash and match-performance improvement. Reject higher output alone, or lower opponent cash achieved by losing even more ourselves.

**Metrics:** Actual marginal sales revenue per additional output unit; Feed/labor/delivery cost; Own and opponent return decomposition; Unsold inventory; Family-specific match outcomes

**Sources:** [Soil V34: labor, wheat replenishment, and livestock](https://www.kaggle.com/code/prvsiyan/kaggriculture-frontier-the-soil-remembers-rain), [Demand capacity and economic estimates](https://www.kaggle.com/code/destbreso/kaggriculture-how-much-money-is-in-this-game), [Crops, labor, and early cash realization](https://www.kaggle.com/code/georgymamarin/kaggriculture-visualized-what-every-crop-pays), [Separate production and market behavior](https://www.kaggle.com/code/destbreso/a-week-four-x-ray-of-the-top-twelve), [Conditional risk of future shops](https://www.kaggle.com/code/busyaprime/one-town-in-three-has-no-yarn-store-at-all)

**Code:** [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp:63](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/planner.hpp#L63), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp:8](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp#L8), [agents/route_clustering_switch_agent/runtime/meta_agent/src/route_switch_features.py:269](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/route_switch_features.py#L269)

## O01 — Add temporal holdouts, family deduplication, and new reactive opponents

**Target:** A

**Group:** Other approaches

**Priority:** P0

**Weakness:** Cross-validation on old replay representatives does not cover interactive strategies that appear later.

**Mechanism:** Retain A's seed/family CV and add outer holdouts based on public version appearance time. Cluster production tapes separately from market-control behavior and evaluate actual new public Agents in closed-loop matches. Retain older strong families in training rather than memorizing only the latest batch.

**Cost:** Medium: 1–2 days to organize evaluation; no larger model is needed first.

**Preconditions:** Freeze opponents by time and source hash. Use actual run/version dates; a Notebook copy date is not proof of strategic freshness.

**Counterexample:** New seeds can still represent the same ecosystem. Eleven highly related names can create false confidence in stability.

**Experiment:** Train on an older window, select on an intermediate window, and confirm on a final frozen window. Repeat at least three historical time splits and log information available at each split. This research downloaded no additional replays.

**Pass Fail:** Require sustained improvement over original A in future windows. Gains only in related-source pools do not establish a longer useful lifetime.

**Metrics:** Paired outcomes by date/family; Worst-family and unseen-family gains; Effective independent production/market cluster counts; Switch activation and gain decay

**Sources:** [Local win-rate rankings reversed](https://www.kaggle.com/code/dariushafshar/18-144-episodes-local-win-rate-ranks-backwards), [Your seed does not fix the town](https://www.kaggle.com/code/yhay81/your-seed-does-not-fix-the-town), [Route ancestry and superficial diversity](https://www.kaggle.com/code/destbreso/can-i-clone-you-from-your-dna), [Separate production and market behavior](https://www.kaggle.com/code/destbreso/a-week-four-x-ray-of-the-top-twelve), [Cross-family failure of a high-scoring preemptive seller](https://www.kaggle.com/code/boatlee/84-84-base-public-holdout-v14-clone-preemption)

**Code:** [agents/route_clustering_switch_agent/scripts/train_robust_search_route_trees.py:374](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/scripts/train_robust_search_route_trees.py#L374), [agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py:59](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py#L59)

## O02 — Screen execution quality among neighbors of each family medoid

**Target:** A

**Group:** Other approaches

**Priority:** P1

**Weakness:** The distance medoid need not be the family's most executable or strongest carrier.

**Mechanism:** Keep the original intent distance and family definitions. Choose a small set of medoid neighbors using confirmed production failures, capital shortfalls, and direct matches. Do not put quality into clustering distance and confuse similar winners with similar plans.

**Cost:** Medium: roughly one preparation day; match cost depends on candidate count.

**Preconditions:** G identifiers can change after reclustering. Rebuild family-to-route mappings and the model when updating the library; do not splice old identifiers into a new clustering.

**Counterexample:** Selecting representatives only by historical wins introduces opponent/world bias. High returns with little support may be chance.

**Experiment:** Use at most three neighbors per active family. Select one in S on a frozen opponent pool, then test H. Start with the four actual online output families, not a new all-versus-all over all 175 routes.

**Pass Fail:** Require H gains while preserving family meaning. Lower distance or a historically high-scoring representative is insufficient.

**Metrics:** Hard production failures; Successful route continuation; Paired direct-match gains; Family distance and coverage; Future-window stability

**Sources:** [Evaluate the route, not the original player's rating](https://www.kaggle.com/code/rogerrogerroger3r/the-best-player-s-tape-is-not-the-best-tape), [Three-day fragments and feasible continuation states](https://www.kaggle.com/code/yhay81/fieldbook-commit-for-three-days), [A failed funding safeguard](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit)

**Code:** [agents/route_clustering_switch_agent/docs/%E5%AE%8F%E8%A7%82%E8%B7%AF%E7%BA%BF%E5%8E%BB%E9%87%8D%E8%81%9A%E7%B1%BB%E4%B8%8E%E5%88%87%E6%8D%A2%E6%90%9C%E5%8F%82.md:106](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/docs/%E5%AE%8F%E8%A7%82%E8%B7%AF%E7%BA%BF%E5%8E%BB%E9%87%8D%E8%81%9A%E7%B1%BB%E4%B8%8E%E5%88%87%E6%8D%A2%E6%90%9C%E5%8F%82.md#L106), [agents/route_clustering_switch_agent/scripts/train_robust_search_route_trees.py:374](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/scripts/train_robust_search_route_trees.py#L374)

## O03 — Learn gain over KEEP and a rejection region

**Target:** A

**Group:** Other approaches

**Priority:** P1

**Weakness:** A few market thresholds dominate the 147 inputs; only four families are effective outputs, with no online uncertainty gate.

**Mechanism:** Convert paired counterfactuals into gain/regression relative to KEEP. Train a small model on public incremental supply, asset age, and continuation shortfalls, preserving a no-switch rejection region. Compare similarly small models first; do not default to a larger LGBM.

**Cost:** Medium to large: 2–3 days to organize the training pipeline.

**Preconditions:** Cut features off at the decision time. Counterfactual states must match for the same seed/opponent/seat. Future actual fills must not enter current inputs.

**Counterexample:** Using tiny cash differences to break tied match outcomes can produce noisy labels. An overly wide rejection region may reduce everything to fixed G001.

**Experiment:** Under O01 temporal holdouts, compare the original tree, a relative-gain tree, and a rejection-gated version. Keep candidates and permitted switch counts unchanged.

**Pass Fail:** Judge by H returns, not label accuracy or R². Fewer switches without improved returns do not establish success.

**Metrics:** Gain calibration relative to KEEP; Cost of incorrect switches; Coverage/rejection rates; Unseen-family gains; Future-window match outcomes

**Sources:** [Label leakage in future-economy forecasts](https://www.kaggle.com/code/jominurk21cs1077/opponent-economy-forecast-300-to-719-top40), [Local bandits and counterexamples](https://www.kaggle.com/code/bruceqdu/two-reinforcement-learning-examples-from-kaito-v27), [Local win-rate rankings reversed](https://www.kaggle.com/code/dariushafshar/18-144-episodes-local-win-rate-ranks-backwards), [From orders to actual trades](https://www.kaggle.com/code/az05192000gmailcom/kaggriculture-from-orders-to-actual-trades)

**Code:** [agents/route_clustering_switch_agent/scripts/train_robust_search_route_trees.py:374](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/scripts/train_robust_search_route_trees.py#L374), [agents/route_clustering_switch_agent/runtime/meta_agent/src/route_switch_features.py:269](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/route_switch_features.py#L269), [agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py:59](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py#L59)

## O04 — Feed route intent into B's candidates and let B execute the task chain

**Target:** A+B

**Group:** Other approaches

**Priority:** P2

**Weakness:** A has strong candidates but depends on action tapes; B adapts execution but may miss valuable economic portfolios.

**Mechanism:** Extract target assets, expansion, and cash events over the next three days from a few validated routes as extra B candidates. Do not pass worker-by-worker action tapes to B. Compile against actual resources, compare with autonomous KEEP at a shared event endpoint, execute only the first step, then replan.

**Cost:** Large: at least 3–5 days; interface and execution validation dominate.

**Preconditions:** Start with 1–2 prefix-compatible routes selected through O02. Paid commitments and maintained assets are hard constraints.

**Counterexample:** Route intent may disrupt B's commitments/replanning. Copying a future layout that has not materialized can amplify state mismatch.

**Experiment:** S compares autonomous B, original A, and B plus intent candidates. Analyze rejected candidates and post-execution drift separately. H uses new public families and 12-melon opponents.

**Pass Fail:** Require improvement over a strong R1 or A baseline, not merely weak R2. Reject simple tape duplication or broken commitments.

**Metrics:** Candidate adoption; Planned versus actual assets; Commitment preservation; Early cash and labor; Cross-family match outcomes; Per-step tail latency

**Sources:** [Three-day fragments and feasible continuation states](https://www.kaggle.com/code/yhay81/fieldbook-commit-for-three-days), [Segmented routing and financing at boundaries](https://www.kaggle.com/code/yhay81/six-day-public-state-fieldbook), [Searching independent production plans](https://www.kaggle.com/code/destbreso/island-ga-an-owned-schedule-is-a-moat), [A failed funding safeguard](https://www.kaggle.com/code/muelsyse111/kaggriculture-exp20260908-01-funding-audit)

**Code:** [agents/route_clustering_switch_agent/runtime/meta_agent/src/teammate_expanded_routes.py:73](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/teammate_expanded_routes.py#L73), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp:8](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/proposals.hpp#L8), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/joint_candidates.hpp:7](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/joint_candidates.hpp#L7), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp:40](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp#L40)

## O05 — Start learning with one evidence-backed local decision

**Target:** A+B

**Group:** Other approaches

**Priority:** P2

**Weakness:** Full-season learning or large trees are costly, and errors in old data compound over long horizons.

**Mechanism:** Choose one sale-delay, endgame-harvest, or intraday-purchase decision with an existing counterexample. Use KEEP and one feasible alternative in a small bandit/search setup. Record actual paired causal gains before expanding.

**Cost:** Medium: 1–2 days for a local example, excluding larger training.

**Preconditions:** Freeze the production baseline, modify the actual final action, and feed the resulting state back. Random rewards or prefilled tables are not training results.

**Counterexample:** In the public tutorial, fixed delay has negative average value and state-dependent selection yields only a small gain. Local profit does not promise a gold medal.

**Experiment:** S fixes one event and two actions without tuning several timings at once. Retain all nonactivated games in H and report both conditional-on-activation and overall effects.

**Pass Fail:** Expand only after clear local H gains with no material overall regression. If it works only in selected showcase games, retain it as research.

**Metrics:** Activation rate; Actual fills/harvest; Distribution of local paired gains; Overall match outcomes; Transfer to new opponents; Runtime

**Sources:** [Local bandits and counterexamples](https://www.kaggle.com/code/bruceqdu/two-reinforcement-learning-examples-from-kaito-v27), [Local endgame search and distillation](https://www.kaggle.com/code/bruceqdu/reinforcement-learning-and-mcts-a-tutorial), [From orders to actual trades](https://www.kaggle.com/code/az05192000gmailcom/kaggriculture-from-orders-to-actual-trades)

**Code:** [agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py:59](https://github.com/LZhangGJ/Kaggriculture/blob/eec409775bc538cf65b3676172ee3ce741ca2469/agents/route_clustering_switch_agent/runtime/meta_agent/src/search_route_policy.py#L59), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/local_sale_timing.hpp:52](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/local_sale_timing.hpp#L52), [nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp:40](https://github.com/LZhangGJ/Kaggriculture/blob/4ef9875968f7104f26fc3140bd28b988101579f8/nt/latest_20260911_afs_workflow_repair_r1_r2/r1/policy/search.hpp#L40)

