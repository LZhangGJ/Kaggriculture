"""Two known G001 games check the rebuilt T1 wrapper against supplier cash."""
import run_match as test
import json
import time


def main():
    expected = json.loads((test.ORIGINAL / "runs/release_holdout100/rows.json").read_text())
    expected = [r for r in expected if r["seed"] == 260909000 and r["opponent"] == 0]
    assert len(expected) == 2
    _, assets = test.arena.load_opponents()
    rows = []
    for ref in expected:
        seat = ref["seat"]
        env = test.arena.native.Env(ref["seed"])
        other = test.arena.Opponent("g001", assets)
        own = test.triad.Agent()
        before = time.perf_counter()
        for step in range(719):
            actions = [None, None]
            actions[seat] = own(env.observation(seat))
            actions[1-seat] = other.act(env, 1-seat)
            env.step(actions)
        cash = [f["money"] for f in env.observation(0)["farms"]]
        row = dict(seed=ref["seed"], seat=seat, steps=env.step_count,
                   cash=cash[seat], opponent_cash=cash[1-seat],
                   expected_cash=ref["cash"], expected_opponent_cash=ref["opponent_cash"],
                   seconds=time.perf_counter()-before)
        row["exact_cash_match"] = env.done and row["cash"] == row["expected_cash"] and row["opponent_cash"] == row["expected_opponent_cash"]
        own.close()
        rows.append(row)
    result = {"status": "PASS" if all(r["exact_cash_match"] for r in rows) else "FAIL", "games": 2,
              "scope": "Known supplier G001 seed, two seats; final cash reproduction, not all 1400 games or action-level parity", "rows": rows}
    test.dump(test.P / "SUPPLIER_ANCHOR.json", result)
    print(json.dumps(result), flush=True)
    if result["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
