"""Locate earliest divergence on the supplier's fixed known G001 trace."""
import run_match as t
import gzip
import json


def main():
    trace_path = t.ORIGINAL / "runs/release_official14/trace_260909000_0_0.json.gz"
    trace = json.loads(gzip.decompress(trace_path.read_bytes()))
    _, assets = t.arena.load_opponents()
    enemy = t.arena.Opponent("g001", assets)
    env = t.arena.native.Env(trace["seed"])
    official = t.LocalGame(trace["seed"])
    own = t.triad.Agent()
    result = {"trace": str(trace_path), "first_t1_action_difference": None,
              "first_g001_action_difference": None, "first_engine_difference": None}
    for step, joint in enumerate(trace["actions"]):
        if result["first_t1_action_difference"] is None:
            got = own(env.observation(0))
            if t.norm(got) != t.norm(joint[0]):
                result["first_t1_action_difference"] = {"step": step, "actual": got, "expected": joint[0], "debug": own.debug()}
        if result["first_g001_action_difference"] is None:
            got = enemy.act(env, 1)
            if t.norm(got) != t.norm(joint[1]):
                result["first_g001_action_difference"] = {"step": step, "actual": got, "expected": joint[1]}
        env.step(joint)
        official.advance(joint)
        for p in (0, 1):
            for field in ("farms", "private", "market", "town", "day", "hour"):
                if json.loads(json.dumps(env.observation(p)[field])) != json.loads(json.dumps(official.observation(p)[field])):
                    result["first_engine_difference"] = {"step": step, "seat": p, "field": field}
                    raise AssertionError(result["first_engine_difference"])
    result["steps"] = env.step_count
    result["cash_replayed"] = [f["money"] for f in env.observation(0)["farms"]]
    own.close()
    t.dump(t.P / "ANCHOR_FIRST_DIVERGENCE.json", result)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
