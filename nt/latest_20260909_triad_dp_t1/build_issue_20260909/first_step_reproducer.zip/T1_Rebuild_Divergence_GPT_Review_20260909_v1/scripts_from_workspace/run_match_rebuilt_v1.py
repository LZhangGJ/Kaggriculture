"""Frozen T1 versus original 94/710. Live actions; no training or route oracle."""
import os
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "1"
import argparse
import gzip
import hashlib
import importlib.util
import json
import multiprocessing as mp
from pathlib import Path
import sys
import time
import traceback

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
PRE = ROOT / "experiments/top40_cluster_switch_20260906_v1"
ORIGINAL = ROOT / "gpt_review/gpt_code/Kaggriculture_Triad_DP_T1_20260908/Kaggriculture_Triad_DP_T1"
sys.path.insert(0, str(PRE))
import seven_arena as arena
from arena_statistics import report_group
sys.path.insert(0, str(ORIGINAL / "arena/gpt_review/codex/G001_CPU_FOR_GPT_20260903"))
from cpu_runtime import LocalGame, load_engine, load_agent
spec = importlib.util.spec_from_file_location("triad_test_policy", P / "t1/policy/agent.py")
triad = importlib.util.module_from_spec(spec)
spec.loader.exec_module(triad)
VARIANTS = {"94": PRE / "candidates/nonsingleton94_20260907_v1",
            "710": PRE / "candidates/full710_20260907_v1"}
AGENTS = {}
OUT = None


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def norm(action):
    # Same canonicalization as the existing validated arena, without importing
    # the replay exporter and its unrelated orjson dependency.
    def canonical(order):
        if not isinstance(order, list) or not order:
            return ["PASS"]
        if order[0] in {"PASS", "NORTH", "SOUTH", "EAST", "WEST", "DROP", "WATER", "HARVEST", "FERTILIZE", "DIG", "BUILD_COOP", "BUILD_PASTURE", "FEED", "COLLECT_FERTILIZER", "CARE", "HIRE", "BUY_LAND"}:
            return order[:1]
        if order[0] == "PLANT":
            return order[:2]
        return order
    def unit(value):
        value = canonical(value)
        return [*value, 1] if len(value) == 2 and value[0] in ("PICKUP", "PLACE") else value
    return {"farmer": unit(action.get("farmer")),
            "hands": [unit(v) for v in action.get("hands", [])],
            "market": [canonical(v) for v in action.get("market", [])]}


def source_files():
    files = [Path(__file__), P / "t1/policy/agent.so", P / "t1/policy/agent.build.json",
             Path(arena.native.__file__), PRE / "seven_arena.py", PRE / "export_library.py"]
    manifest = json.loads((ORIGINAL / "MANIFEST_T1.json").read_text())
    for rel, meta in manifest.items():
        if rel.replace("\\", "/").startswith("policy/") and Path(rel).suffix in (".hpp", ".cpp", ".py", ".json") and not rel.endswith(".build.json"):
            f = P / "t1" / rel
            if sha(f) != meta["sha256"]:
                raise ValueError("T1 source/config changed: " + rel)
            files.append(f)
    for folder in VARIANTS.values():
        manifest = json.loads((folder / "MANIFEST.json").read_text())
        for rel, expected in manifest["file_hashes"].items():
            f = folder / rel
            if sha(f) != expected:
                raise ValueError("Opponent export changed: " + str(f))
            files.append(f)
    official = ORIGINAL / "arena/gpt_review/codex/G001_CPU_FOR_GPT_20260903"
    files.extend(official / f for f in ("cpu_runtime.py", "official/kaggriculture.py", "official/seed_utils.py"))
    return {str(f.relative_to(ROOT)): sha(f) for f in sorted(set(files))}


def game(job):
    name, seed, seat, parity = job
    tic = time.perf_counter()
    row = {"opponent": name, "seed": seed, "seat": seat, "status": "RUNNING"}
    env = arena.native.Env(seed)
    other, asset = AGENTS[name]
    state = arena.native.G001State()
    own = triad.Agent()
    reference_own = triad.Agent() if parity else None
    official = LocalGame(seed) if parity else None
    reference_other = load_agent(VARIANTS[name] / "main.py") if parity else None
    actions, daily, switches = [], [], []
    latency = []
    try:
        for step in range(719):
            obs = env.observation(seat)
            if step % 24 == 0:
                daily.append({"step": step, "day": obs["day"],
                              "cash": obs["farms"][seat]["money"],
                              "other_cash": obs["farms"][1-seat]["money"],
                              "hands": len(obs["farms"][seat]["hands"])})
            if parity:
                for p in (0, 1):
                    nobs, oobs = env.observation(p), official.observation(p)
                    for field in ("farms", "private", "market", "town", "day", "hour"):
                        if json.loads(json.dumps(nobs[field])) != json.loads(json.dumps(oobs[field])):
                            raise AssertionError({"kind": "state", "step": step, "seat": p, "field": field})
            before = time.perf_counter()
            ours = own(obs)
            latency.append(time.perf_counter() - before)
            theirs = other.act(env, 1-seat, state)
            if parity:
                r_ours = reference_own(official.observation(seat), official.configuration)
                r_theirs = reference_other(official.observation(1-seat), official.configuration)
                if norm(ours) != norm(r_ours):
                    raise AssertionError({"kind": "T1 wrapper", "step": step, "actual": ours, "expected": r_ours})
                if norm(theirs) != norm(r_theirs):
                    raise AssertionError({"kind": "opponent Python/native", "step": step, "actual": theirs, "expected": r_theirs})
            joint = [None, None]
            joint[seat], joint[1-seat] = ours, theirs
            actions.append(joint)
            if step in (0, 144, 216, 718):
                switches.append({"step": step, "route": asset["families"][state.current], "switched": bool(state.switched)})
            env.step(joint)
            if parity:
                official.advance(joint)
        assert env.done and env.step_count == 719
        cash = [f["money"] for f in env.observation(0)["farms"]]
        if parity:
            assert official.done
            for p in (0, 1):
                for field in ("farms", "private", "market", "town", "day", "hour"):
                    assert json.loads(json.dumps(official.observation(p)[field])) == json.loads(json.dumps(env.observation(p)[field])), ("terminal", p, field)
        row.update(status="PASS", steps=719, cash=cash[seat], opponent_cash=cash[1-seat],
                   margin=cash[seat]-cash[1-seat], win=cash[seat]>cash[1-seat],
                   switches=switches, daily=daily, t1_debug=own.debug(),
                   t1_seconds=sum(latency), max_action_ms=1000*max(latency),
                   parity_steps=719 if parity else 0)
    except Exception:
        row.update(status="ERROR", steps=env.step_count, error=traceback.format_exc())
    finally:
        own.close()
        if reference_own:
            reference_own.close()
    row["seconds"] = time.perf_counter()-tic
    dump(OUT / "games" / f"{name}_{seed}_{seat}.json", row)
    trace = json.dumps({"row": row, "actions": actions}, separators=(",", ":")).encode()
    (OUT / "traces" / f"{name}_{seed}_{seat}.json.gz").write_bytes(gzip.compress(trace, compresslevel=1))
    return row


def main():
    global OUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", required=True, choices=("smoke", "full"))
    parser.add_argument("--workers", type=int, default=16)
    args = parser.parse_args()
    OUT = P / args.mode
    OUT.mkdir(exist_ok=False)
    (OUT / "games").mkdir()
    (OUT / "traces").mkdir()
    if args.mode == "full":
        assert json.loads((P / "smoke/RESULT.json").read_text())["status"] == "PASS"
    seeds = [260909990] if args.mode == "smoke" else list(range(260909100, 260909200))
    jobs = [(n, s, p, args.mode == "smoke") for n in VARIANTS for s in seeds for p in (0, 1)]
    hashes = source_files()
    protocol = {"mode": args.mode, "seeds": seeds, "games": len(jobs), "workers": min(args.workers, len(jobs)),
                "opponents": {n: str(p.relative_to(ROOT)) for n, p in VARIANTS.items()},
                "config": json.loads((P / "t1/policy/config.json").read_text()), "sources": hashes,
                "live_opponents": True, "training": False, "source_strategy_modified": False}
    dump(OUT / "PROTOCOL.json", protocol)
    before = time.perf_counter()
    for n, folder in VARIANTS.items():
        policy = json.loads((folder / "runtime/route_policy.json").read_text())
        cpp, _, asset = arena.make_candidate("G001", policy)
        AGENTS[n] = cpp, asset
        print("Loaded", n, "routes", len(asset["families"]), flush=True)
    started = time.perf_counter()
    rows = []
    with mp.get_context("fork").Pool(min(args.workers, len(jobs))) as pool:
        for r in pool.imap_unordered(game, jobs):
            rows.append(r)
            if r["status"] != "PASS" or len(rows) % 20 == 0 or args.mode == "smoke":
                print(json.dumps({"completed": len(rows), "total": len(jobs), "opponent": r["opponent"],
                                  "status": r["status"], "cash": r.get("cash"), "other": r.get("opponent_cash"),
                                  "elapsed": time.perf_counter()-started}), flush=True)
            dump(OUT / "PROGRESS.json", {"completed": len(rows), "total": len(jobs),
                 "elapsed": time.perf_counter()-started, "errors": sum(v["status"] != "PASS" for v in rows)})
            if r["status"] != "PASS":
                pool.terminate()
                dump(OUT / "RESULT.json", {"status": "FAIL", "row": r})
                raise RuntimeError(r["error"])
    assert source_files() == hashes, "Source mutated during execution"
    result = {"status": "PASS", "games": len(rows), "seeds": len(seeds),
              "seconds_games_and_trace_io": time.perf_counter()-started,
              "seconds_including_load": time.perf_counter()-before, "errors": 0,
              "all_steps": 719, "source_hashes_unchanged": True,
              "parity_steps": sum(r["parity_steps"] for r in rows),
              "max_action_ms": max(r["max_action_ms"] for r in rows)}
    if args.mode == "full":
        import numpy as np
        result["per_opponent"] = {}
        for name in VARIANTS:
            rr = [r for r in rows if r["opponent"] == name]
            stats = report_group(rr)
            stats["median_margin"] = float(np.median([r["margin"] for r in rr]))
            stats["by_t1_seat"] = {str(p): {"games": 100, "wins": sum(r["win"] for r in rr if r["seat"] == p)} for p in (0, 1)}
            result["per_opponent"][name] = stats
        lines = ["# T1 对原版94、710实时对战结果", "", "100个新seed × 双座位，每个对手200局。T1发布参数与对手均冻结；未训练、未挑选最优参数。", "",
                 "| 对手 | T1胜/平/负 | 胜率 | T1平均现金 | 对手平均现金 | 平均分差 | 分差中位数 |", "|---|---|---:|---:|---:|---:|---:|"]
        for n, s in result["per_opponent"].items():
            lines.append(f"| {n} | {s['wins']}/{s['ties']}/{s['losses']} | {s['win_rate']:.2%} | {s['mean_cash']:,.0f} | {s['mean_opponent_cash']:,.0f} | {s['mean_margin']:+,.0f} | {s['median_margin']:+,.0f} |")
        lines += ["", "4局先行检查包含官方1.32.7逐步状态、对手导出Python/C++动作及T1观测桥接一致性，共2876步；正式400局走C++规则与C++对手，T1通过Python观测包装器调用C++。", "", "双方实时读取真实盘面，不使用冻结对手动作流。94为非单例原版切换Agent，不是ECP94动态版；710为全量原版。", "", "全部719步完成、运行错误0、策略源码前后哈希未变。统计区间按100个独立seed成组重采样；两座位不是200个独立seed。", "", f"400局与动作存档用时{result['seconds_games_and_trace_io']:.2f}秒，含载入{result['seconds_including_load']:.2f}秒，16进程。该测量包含Python观测转换/存档，不是纯C++模拟器速度，也不是Kaggle沙箱时限认证。", "", "完整统计见RESULT.json，逐局见games/，双方实际动作见traces/。本轮不推Git、不提交Public。"]
        (OUT / "REPORT_ZH.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
    dump(OUT / "RESULT.json", result)
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
