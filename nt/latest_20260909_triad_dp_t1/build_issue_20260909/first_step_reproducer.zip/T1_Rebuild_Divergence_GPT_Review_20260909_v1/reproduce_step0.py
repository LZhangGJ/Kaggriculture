"""Standard-library-only first-action comparison; one fresh process per binary."""
import argparse
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def one(binary):
    sys.path.insert(0, str(ROOT / "referee"))
    from cpu_runtime import LocalGame
    path = ROOT / "source_release/policy/agent.py"
    spec = importlib.util.spec_from_file_location("isolated_triad", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    config = json.loads((path.parent / "config.json").read_text())
    game = LocalGame(260909000)
    obs = game.observation(0)
    packed = module._pack(obs)
    agent = module.Agent(config=config, binary_path=binary)
    try:
        action = agent(obs, game.configuration)
        return {"binary": str(binary), "binary_sha256": digest(binary),
                "input_wire_sha256": hashlib.sha256(bytes(packed)).hexdigest(),
                "config_sha256": digest(path.parent / "config.json"),
                "step": obs["step"], "seed_fixture": 260909000, "seat": 0,
                "action": action, "debug": agent.debug()}
    finally:
        agent.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--one", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--extra-binary", type=Path)
    parser.add_argument("--out", type=Path, help="Optional new output path; no overwrite")
    args = parser.parse_args()
    if args.one:
        print(json.dumps(one(args.one.resolve())))
        return
    choices = {"supplier_original": ROOT / "binaries/supplier_original.so",
               "local_rebuilt_gcc13": ROOT / "binaries/local_rebuilt_gcc13.so"}
    if args.extra_binary:
        choices["extra"] = args.extra_binary.resolve()
    results = {}
    for name, path in choices.items():
        child = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--one", str(path)],
                               capture_output=True, text=True, timeout=60)
        if child.returncode:
            raise RuntimeError(f"{name}: binary could not be tested (exit {child.returncode})\n{child.stderr}")
        results[name] = json.loads(child.stdout)
    same_input = len({r["input_wire_sha256"] for r in results.values()}) == 1
    same_config = len({r["config_sha256"] for r in results.values()}) == 1
    if not same_input or not same_config:
        raise AssertionError("Comparison was not made with identical input/configuration")
    trace = json.loads(gzip.decompress((ROOT / "evidence/supplier/trace_260909000_0_0.json.gz").read_bytes()))
    expected = trace["actions"][0][0]
    report = {"scope": "first action only; independent child processes; no full matches",
              "same_wire_input": same_input, "same_config": same_config,
              "supplier_matches_frozen_trace": results["supplier_original"]["action"] == expected,
              "action_divergence_reproduced": results["supplier_original"]["action"] != results["local_rebuilt_gcc13"]["action"],
              "results": results}
    output = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.out:
        with args.out.open("x", encoding="utf-8") as handle:
            handle.write(output)
    print(output, end="")


if __name__ == "__main__":
    main()
