"""Read-only verification of all original files listed in MANIFEST.json."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
for name, meta in manifest.items():
    path = (root / name).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise SystemExit("Missing/unsafe path: " + name)
    raw = path.read_bytes()
    if len(raw) != meta["bytes"] or hashlib.sha256(raw).hexdigest() != meta["sha256"]:
        raise SystemExit("Mismatch: " + name)
print(json.dumps({"status": "PASS", "verified_files": len(manifest),
                  "scope": "manifest file hashes only; not game/rule verification"}))
