# T1 重编译行为不一致：GPT排查包

请先读 [GPT排查问题](GPT_REVIEW_PROMPT_ZH.md)，再读 [问题证据](documents/REPRODUCIBILITY_WARNING_ZH.md) 和 [最终强度口径](documents/RESULT_SUMMARY_ZH.md)。

本包导航：[原库400局报告](evidence/local/full_supplied/REPORT_ZH.md)、[原库统计](evidence/local/full_supplied/RESULT.json)、[重编译400局报告（非原T1强度）](evidence/local/full/REPORT_ZH.md)、[首步差异](evidence/local/ANCHOR_FIRST_DIVERGENCE.json)、[原库锚点](evidence/local/SUPPLIER_ANCHOR_ORIGINAL.json)、[重编译锚点](evidence/local/SUPPLIER_ANCHOR.json)、[原构建记录](binaries/supplier_original.build.json)、[本机构建记录](binaries/local_rebuilt_gcc13.build.json)。原文档按字节保留，其中旧工作区路径和相对链接未重写，以本行导航为准。

## 核心现象

同一个观察包装器、同一份配置、相同第0步观测，**只换二进制，首步决策即改变**：

| 产物 | 第0步市场订单 | 已知G001对局现金（我方:对手） |
|---|---|---|
| 原发布库 | 小麦6、牛3、羊3、小麦种3、雇2人 | 113939 : 99080 |
| 本机重编译库 | 瓜种20、草莓种5、雇3人 | 73266 : 147603 |

两份构建记录的 source_hash 相同。原构建记录GCC14.2，本机GCC13.3。**原因未知，不能据此断言编译器bug。**

最先400局0胜是重编译产物的成绩，不能作为原发布T1强度。使用原发布库后，同样400局：对原版94为77/200胜，对原版710为80/200胜。

## 包含什么

- `documents/`：问题说明、最终结论、原计划和两组对战报告。
- `evidence/local/`：首步差异、两种库的G001锚点、官方有限预检、两组400局协议/统计/逐局结果。
- `evidence/supplier/`：原发布验收、构建环境、构建/源码记录、原G001动作流、原包无缓存重建的声明/记录。
- `source_release/`：原T1全套策略源码与原构建脚本，未改参数/算法。仅缺省不放运行库，以免误覆盖证据。
- `binaries/`：原发布与本机重编译的两份Linux x86-64 `.so`，原样保留；各自构建记录独立保存。
- `referee/`：冻结官方1.32.7规则、配置、种子工具与原CPU宿主；首步复现不需要7对手或全量arena。
- `scripts_from_workspace/`：原完整实验/锚点审计脚本，供阅读。它们仍依赖原工作区，不承诺独立运行；独立入口是根目录的 `reproduce_step0.py`。
- `PROBE_RESULT.json`：本次在交接目录重新运行首步最小复现的结果。
- `MANIFEST.json`、`verify_package.py`：文件SHA256校验；`COPY_PROVENANCE.json`保存原路径/原文件哈希。

没有包含整个120MB原包、全量回放缓存、编译缓存或其他未完成实验。保留了与本问题相关的源码和两个实际产物，便于GPT直接定位，而不只是看结论。

## 独立复现（Linux / WSL2）

无需GPU，首步脚本只用Python标准库和两个已有C++库：

```bash
python3 verify_package.py
python3 reproduce_step0.py
```

两个库分别在独立子进程加载，使用相同配置、相同初始公开观测和自有库存；记录实际编码输入的SHA256。脚本只验证第0步，**不声称重跑全局对战**。本机可加载两份库，不保证另一台Linux的glibc/libstdc++兼容；如加载失败，应保存报错，不要悄悄重编译后当作原库。

需要另行重编译进行实验：

```bash
cd source_release
python3 build_policy.py
cd ..
python3 reproduce_step0.py --extra-binary source_release/policy/agent.so
```

新编译输出在 `source_release/`，不会覆盖 `binaries/` 的两份冻结证据。构建需要支持C++20的g++。新增输出会让清单中已修改的原源码校验失败，这是正常的版本差异；修改时应保留原版和变更记录。

完整对手强度复验仍需要原工作区/完整T1与94/710的arena资产。本包优先支持最早偏离定位，不用下载任何网络资源。
