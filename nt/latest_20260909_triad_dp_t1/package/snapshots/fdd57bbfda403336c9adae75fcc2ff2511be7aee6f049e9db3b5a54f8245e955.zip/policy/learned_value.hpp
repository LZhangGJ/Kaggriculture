#pragma once
#include <vector>
// Replaced only after an actual training/export step. Never pretend a placeholder
// has learned anything; callers fall back to the original candidate when false.
namespace triad::learned {
constexpr bool available=false;
inline double predict(const std::vector<double>&){return 0.;}
}
