#pragma once
#include "triad.hpp"
#include "public_flow_scenario.hpp"
namespace triad {
// Bounded public-information MPC above the existing Bellman recurrences.
// It does NOT call a real opponent, access real future shops, or clone an arena.
// Candidate intervention lasts ONLY the current day; all branches use the same
// base economic policy afterwards. A single common tail-value model scores them.
struct SearchController {
 Settings base;Controller live;
 int searches=0,scenarios=0,changes=0;double predicted_gain=0;
 std::array<int,10>chosen{};
 explicit SearchController(Settings s={}):base(s),live(s){}
 void choose(const View&o){
  searches++;int horizon=std::clamp(int(base.scenario),1,5);
  int width=std::clamp(int(base.portfolio_passes),2,9);
  std::vector<Settings>settings(width,base);
  if(width>1){settings[1].discount=std::max(.08,base.discount*2);settings[1].capital_power=std::max(.5,base.capital_power);}
  if(width>2){settings[2].animal_bias*=.6;}
  if(width>3){settings[3].animal_bias*=1.6;settings[3].capital_power=std::max(0.,base.capital_power-.2);}
  if(width>4){settings[4].competition*=.5;}
  if(width>5){settings[5].competition*=1.5;}
  if(width>6){settings[6].labor_hours=std::max(6.,base.labor_hours*.8);}
  if(width>7){settings[7].land_rent*=2;}
  if(width>8){settings[8].max_land=4;}
  Controller best=live;double bestscore=-1e100,baseline=-1e100;int winner=0;
  std::set<std::vector<int>>seen;
  for(int i=0;i<width;i++){
   Controller proposal=live;auto ps=settings[i];ps.scenario=0;proposal.configure(ps);proposal.plan(o);
   std::vector<int>key;for(auto[p,k]:proposal.core.target){key.push_back(p);key.push_back(k);key.push_back(proposal.core.triad_crop_age[p]);}
   key.push_back(proposal.core.planned_land);for(auto a:proposal.core.queue){key.push_back(int(a.op));key.push_back(int(a.item));key.push_back(a.quantity);}
   // These policies may change service even with equal portfolios, so include
   // current planned service bits rather than deduplicating by crop counts.
   for(int p=0;p<100;p++){key.push_back(proposal.core.service_feed[p]);key.push_back(proposal.core.service_care[p]);key.push_back(proposal.core.crop_water[p]);key.push_back(proposal.core.crop_fertilize[p]);}
   if(!seen.insert(key).second)continue;
   auto roll=proposal;roll.previous_step=o.step-1;
   fastkag::PublicFlowScenario world(o,proposal.model.rival,base.supply);
   int stop=std::min(719,o.step+24*horizon);Settings common=base;common.scenario=0;
   while(world.view().step<stop&&!world.done()){
    auto v=world.view();if(v.day!=o.day)roll.configure(common);
    auto act=roll.act(v);world.advance(act);
   }
   double score=world.own_cash()-base.competition*world.rival_cash();
   if(!world.done()){
    auto v=world.view();Controller tail=live;tail.configure(common);tail.book=roll.book;tail.plan(v);
    score+=tail.predicted;
   }
   scenarios++;if(i==0)baseline=score;
   if(score>bestscore+1e-6){best=std::move(proposal);bestscore=score;winner=i;}
  }
  changes+=winner!=0;chosen[winner]++;predicted_gain+=bestscore-baseline;
  live=std::move(best);
 }
 PlayerAction act(const View&o){
  if(base.scenario>0&&o.day!=live.core.day)choose(o);
  return live.act(o);
 }
 std::string debug()const{
  auto text=live.debug();text.pop_back();std::ostringstream s;s<<text<<",\"search_calls\":"<<searches<<",\"search_scenarios\":"<<scenarios<<",\"search_changes\":"<<changes<<",\"search_predicted_gain\":"<<predicted_gain<<",\"search_choices\":[";
  for(int i=0;i<10;i++){if(i)s<<",";s<<chosen[i];}s<<"]}";return s.str();
 }
};
}
