from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from .constants import ITEMS, MARKET_OPS, MAX_MARKET_ORDERS, MAX_MARKET_QTY, MAX_UNIT_QTY, UNIT_OPS


@dataclass(slots=True)
class EncodedObservation:
    continuous: torch.Tensor
    token_type: torch.Tensor
    category_a: torch.Tensor
    category_b: torch.Tensor
    category_c: torch.Tensor
    x: torch.Tensor
    y: torch.Tensor
    owner: torch.Tensor
    own_unit_token_indices: tuple[int, ...]

    @property
    def num_tokens(self) -> int:
        return int(self.continuous.shape[0])


@dataclass(slots=True)
class ActionRecord:
    unit_ops: tuple[int, ...]
    unit_items: tuple[int, ...]
    unit_quantities: tuple[int, ...]
    market_ops: tuple[int, ...]
    market_items: tuple[int, ...]
    market_quantities: tuple[int, ...]


@dataclass(slots=True)
class ActionMasks:
    unit_ops: torch.Tensor
    unit_items: torch.Tensor
    unit_quantities: torch.Tensor
    market_ops: torch.Tensor
    market_items: torch.Tensor
    market_quantities: torch.Tensor


@dataclass(slots=True)
class ActOutput:
    env_action: dict[str, Any]
    encoded: EncodedObservation
    record: ActionRecord
    masks: ActionMasks
    log_prob: float
    entropy: float
    value: float
    # Present only for a temporal policy.  It is deliberately not packed into
    # PPO transitions: sequence training reconstructs memory from observations
    # and actions so gradients never flow through stale rollout embeddings.
    history_state: Any | None = None


@dataclass(slots=True)
class Transition:
    encoded: EncodedObservation
    action: ActionRecord
    masks: ActionMasks
    old_log_prob: float
    old_value: float
    reward: float
    done: bool
    episode_id: int = 0
    player_id: int = 0
    timestep: int = 0
    trajectory_id: int = 0
    # Recurrent hidden immediately before this observation is consumed.
    # Recurrent PPO uses it as the detached initial state of a training chunk,
    # avoiding an overlapping burn-in prefix for every chunk.
    recurrent_hidden: torch.Tensor | None = None
    # Privileged training-only label reconstructed from the other replay
    # viewpoint.  It is never part of the policy observation or rollout state.
    opponent_belief_target: tuple[float, ...] | None = None
    advantage: float = 0.0
    return_: float = 0.0


@dataclass(slots=True)
class PackedTransitionBatch:
    """A small number of contiguous tensors suitable for actor IPC."""

    num_tokens: torch.Tensor
    continuous: torch.Tensor
    token_type: torch.Tensor
    category_a: torch.Tensor
    category_b: torch.Tensor
    category_c: torch.Tensor
    x: torch.Tensor
    y: torch.Tensor
    owner: torch.Tensor
    unit_counts: torch.Tensor
    unit_token_indices: torch.Tensor
    unit_ops: torch.Tensor
    unit_items: torch.Tensor
    unit_quantities: torch.Tensor
    market_ops: torch.Tensor
    market_items: torch.Tensor
    market_quantities: torch.Tensor
    unit_op_masks: torch.Tensor
    unit_item_masks: torch.Tensor
    unit_quantity_masks: torch.Tensor
    market_op_masks: torch.Tensor
    market_item_masks: torch.Tensor
    market_quantity_masks: torch.Tensor
    old_log_prob: torch.Tensor
    old_value: torch.Tensor
    reward: torch.Tensor
    done: torch.Tensor
    episode_id: torch.Tensor
    player_id: torch.Tensor
    timestep: torch.Tensor
    trajectory_id: torch.Tensor
    recurrent_hidden: torch.Tensor
    advantage: torch.Tensor
    return_: torch.Tensor

    def __len__(self) -> int:
        return int(self.num_tokens.shape[0])


class PackedRolloutStorage:
    """Preallocated trajectory-major storage written directly during rollout."""

    def __init__(
        self,
        *,
        num_envs: int,
        players: int,
        horizon: int,
        continuous_width: int,
        max_tokens: int = 320,
        max_units: int = 32,
        recurrent_width: int = 0,
        shared: bool = False,
    ) -> None:
        if min(num_envs, players, horizon, continuous_width, max_tokens, max_units) < 1:
            raise ValueError("Packed rollout dimensions must be positive.")
        self.num_envs = int(num_envs)
        self.players = int(players)
        self.horizon = int(horizon)
        self.max_tokens = int(max_tokens)
        self.max_units = int(max_units)
        count = self.num_envs * self.players * self.horizon
        zeros = torch.zeros
        fields: dict[str, torch.Tensor] = {
            "num_tokens": zeros(count, dtype=torch.int16),
            "continuous": zeros((count, max_tokens, continuous_width), dtype=torch.float32),
            "token_type": zeros((count, max_tokens), dtype=torch.long),
            "category_a": zeros((count, max_tokens), dtype=torch.long),
            "category_b": zeros((count, max_tokens), dtype=torch.long),
            "category_c": zeros((count, max_tokens), dtype=torch.long),
            "x": zeros((count, max_tokens), dtype=torch.long),
            "y": zeros((count, max_tokens), dtype=torch.long),
            "owner": zeros((count, max_tokens), dtype=torch.long),
            "unit_counts": zeros(count, dtype=torch.int16),
            "unit_token_indices": zeros((count, max_units), dtype=torch.long),
            "unit_ops": zeros((count, max_units), dtype=torch.long),
            "unit_items": zeros((count, max_units), dtype=torch.long),
            "unit_quantities": zeros((count, max_units), dtype=torch.long),
            "market_ops": zeros((count, MAX_MARKET_ORDERS), dtype=torch.long),
            "market_items": zeros((count, MAX_MARKET_ORDERS), dtype=torch.long),
            "market_quantities": zeros((count, MAX_MARKET_ORDERS), dtype=torch.long),
            "unit_op_masks": zeros((count, max_units, len(UNIT_OPS)), dtype=torch.bool),
            "unit_item_masks": zeros((count, max_units, len(ITEMS)), dtype=torch.bool),
            "unit_quantity_masks": zeros((count, max_units, MAX_UNIT_QTY), dtype=torch.bool),
            "market_op_masks": zeros((count, MAX_MARKET_ORDERS, len(MARKET_OPS)), dtype=torch.bool),
            "market_item_masks": zeros((count, MAX_MARKET_ORDERS, len(ITEMS)), dtype=torch.bool),
            "market_quantity_masks": zeros((count, MAX_MARKET_ORDERS, MAX_MARKET_QTY), dtype=torch.bool),
            "old_log_prob": zeros(count, dtype=torch.float32),
            "old_value": zeros(count, dtype=torch.float32),
            "reward": zeros(count, dtype=torch.float32),
            "done": zeros(count, dtype=torch.bool),
            "episode_id": zeros(count, dtype=torch.int32),
            "player_id": zeros(count, dtype=torch.int32),
            "timestep": zeros(count, dtype=torch.int32),
            "trajectory_id": zeros(count, dtype=torch.int32),
            "recurrent_hidden": zeros((count, recurrent_width), dtype=torch.float32),
            "advantage": zeros(count, dtype=torch.float32),
            "return_": zeros(count, dtype=torch.float32),
        }
        if shared:
            for tensor in fields.values():
                tensor.share_memory_()
        self.batch = PackedTransitionBatch(**fields)

    def reset(self) -> None:
        # Every active scalar and prefix is overwritten. Only recurrent rows
        # can be intentionally absent between chunk boundaries.
        if self.batch.recurrent_hidden.numel():
            self.batch.recurrent_hidden.zero_()

    def index(self, env_index: int, player_id: int, timestep: int) -> int:
        if not 0 <= env_index < self.num_envs:
            raise IndexError("env_index outside packed rollout storage")
        if not 0 <= player_id < self.players:
            raise IndexError("player_id outside packed rollout storage")
        if not 0 <= timestep < self.horizon:
            raise IndexError("timestep outside packed rollout storage")
        return (env_index * self.players + player_id) * self.horizon + timestep

    def write(
        self,
        *,
        env_index: int,
        player_id: int,
        timestep: int,
        output: ActOutput,
        reward: float,
        done: bool,
        episode_id: int,
        recurrent_hidden: torch.Tensor | None = None,
    ) -> None:
        row = self.index(env_index, player_id, timestep)
        encoded, action, masks = output.encoded, output.record, output.masks
        tokens = encoded.num_tokens
        units = len(action.unit_ops)
        if tokens > self.max_tokens:
            raise RuntimeError(
                f"Rollout observation has {tokens} tokens, above fixed maximum {self.max_tokens}."
            )
        if units > self.max_units:
            raise RuntimeError(
                f"Rollout observation has {units} units, above fixed maximum {self.max_units}."
            )
        batch = self.batch
        batch.num_tokens[row] = tokens
        batch.unit_counts[row] = units
        batch.continuous[row, :tokens].copy_(encoded.continuous)
        for target, source in zip(
            (
                batch.token_type, batch.category_a, batch.category_b, batch.category_c,
                batch.x, batch.y, batch.owner,
            ),
            (
                encoded.token_type, encoded.category_a, encoded.category_b, encoded.category_c,
                encoded.x, encoded.y, encoded.owner,
            ),
            strict=True,
        ):
            target[row, :tokens].copy_(source)
        batch.unit_token_indices[row, :units] = torch.as_tensor(
            encoded.own_unit_token_indices, dtype=torch.long
        )
        for target, source in zip(
            (batch.unit_ops, batch.unit_items, batch.unit_quantities),
            (action.unit_ops, action.unit_items, action.unit_quantities),
            strict=True,
        ):
            target[row, :units] = torch.as_tensor(source, dtype=torch.long)
        for target, source in zip(
            (batch.market_ops, batch.market_items, batch.market_quantities),
            (action.market_ops, action.market_items, action.market_quantities),
            strict=True,
        ):
            target[row].copy_(torch.as_tensor(source, dtype=torch.long))
        batch.unit_op_masks[row, :units].copy_(masks.unit_ops)
        batch.unit_item_masks[row, :units].copy_(masks.unit_items)
        batch.unit_quantity_masks[row, :units].copy_(masks.unit_quantities)
        batch.market_op_masks[row].copy_(masks.market_ops)
        batch.market_item_masks[row].copy_(masks.market_items)
        batch.market_quantity_masks[row].copy_(masks.market_quantities)
        batch.old_log_prob[row] = float(output.log_prob)
        batch.old_value[row] = float(output.value)
        batch.reward[row] = float(reward)
        batch.done[row] = bool(done)
        batch.episode_id[row] = int(episode_id)
        batch.player_id[row] = int(player_id)
        batch.timestep[row] = int(timestep)
        batch.trajectory_id[row] = int(env_index)
        if recurrent_hidden is not None:
            target = batch.recurrent_hidden[row]
            source = recurrent_hidden.detach().to(dtype=torch.float32, device="cpu").reshape(-1)
            if source.numel() != target.numel():
                raise RuntimeError("Recurrent hidden width does not match packed rollout storage.")
            target.copy_(source)

    def finalize(self, *, gamma: float, gae_lambda: float) -> PackedTransitionBatch:
        if not 0.0 <= gamma <= 1.0 or not 0.0 <= gae_lambda <= 1.0:
            raise ValueError("gamma and gae_lambda must be in [0, 1].")
        if bool((self.batch.num_tokens == 0).any()):
            missing = int((self.batch.num_tokens == 0).sum())
            raise RuntimeError(f"Packed rollout storage has {missing} unwritten rows.")
        trajectories = self.num_envs * self.players
        rewards = self.batch.reward.view(trajectories, self.horizon)
        values = self.batch.old_value.view(trajectories, self.horizon)
        dones = self.batch.done.view(trajectories, self.horizon)
        advantages = self.batch.advantage.view(trajectories, self.horizon)
        running = torch.zeros(trajectories, dtype=torch.float32)
        for timestep in range(self.horizon - 1, -1, -1):
            nonterminal = (~dones[:, timestep]).to(torch.float32)
            next_value = (
                values[:, timestep + 1]
                if timestep + 1 < self.horizon
                else torch.zeros_like(running)
            )
            delta = rewards[:, timestep] + gamma * next_value * nonterminal - values[:, timestep]
            running = delta + gamma * gae_lambda * nonterminal * running
            advantages[:, timestep] = running
        self.batch.return_.copy_(self.batch.advantage + self.batch.old_value)
        return self.batch


def concatenate_packed_batches(
    batches: list[PackedTransitionBatch],
) -> PackedTransitionBatch:
    """Concatenate actor batches without rebuilding Python transitions.

    Actor shards can have different token/unit padding widths.  Only those two
    dimensions need padding; all other fields have fixed schema widths.
    """
    if not batches:
        raise ValueError("Cannot concatenate an empty packed-batch list.")
    if len(batches) == 1:
        return batches[0]

    max_tokens = max(int(batch.continuous.shape[1]) for batch in batches)
    max_units = max(int(batch.unit_ops.shape[1]) for batch in batches)

    def pad(tensor: torch.Tensor, dimension: int, width: int) -> torch.Tensor:
        if tensor.shape[dimension] == width:
            return tensor
        shape = list(tensor.shape)
        shape[dimension] = width
        padded = torch.zeros(shape, dtype=tensor.dtype, device=tensor.device)
        slices = [slice(None)] * tensor.ndim
        slices[dimension] = slice(0, tensor.shape[dimension])
        padded[tuple(slices)].copy_(tensor)
        return padded

    token_fields = {
        "continuous", "token_type", "category_a", "category_b", "category_c",
        "x", "y", "owner",
    }
    unit_fields = {
        "unit_token_indices", "unit_ops", "unit_items", "unit_quantities",
        "unit_op_masks", "unit_item_masks", "unit_quantity_masks",
    }
    vector_fields = {"recurrent_hidden"}
    values: dict[str, torch.Tensor] = {}
    for name in PackedTransitionBatch.__dataclass_fields__:
        tensors = [getattr(batch, name) for batch in batches]
        if name in token_fields:
            tensors = [pad(tensor, 1, max_tokens) for tensor in tensors]
        elif name in unit_fields:
            tensors = [pad(tensor, 1, max_units) for tensor in tensors]
        elif name in vector_fields:
            width = max(int(tensor.shape[1]) for tensor in tensors)
            tensors = [pad(tensor, 1, width) for tensor in tensors]
        values[name] = torch.cat(tensors, dim=0)
    return PackedTransitionBatch(**values)


def pack_transitions(transitions: list[Transition]) -> PackedTransitionBatch:
    """Pack Python trajectory objects into contiguous CPU tensors."""
    if not transitions:
        raise ValueError("Cannot pack an empty transition batch.")
    count = len(transitions)
    max_tokens = max(t.encoded.num_tokens for t in transitions)
    max_units = max(len(t.action.unit_ops) for t in transitions)
    continuous_width = int(transitions[0].encoded.continuous.shape[1])

    continuous = torch.zeros((count, max_tokens, continuous_width), dtype=torch.float32)
    token_fields = [
        torch.zeros((count, max_tokens), dtype=torch.long) for _ in range(7)
    ]
    unit_token_indices = torch.zeros((count, max_units), dtype=torch.long)
    unit_actions = [torch.zeros((count, max_units), dtype=torch.long) for _ in range(3)]
    market_actions = [
        torch.zeros((count, MAX_MARKET_ORDERS), dtype=torch.long) for _ in range(3)
    ]
    unit_op_masks = torch.zeros((count, max_units, len(UNIT_OPS)), dtype=torch.bool)
    unit_item_masks = torch.zeros((count, max_units, len(ITEMS)), dtype=torch.bool)
    unit_quantity_masks = torch.zeros((count, max_units, MAX_UNIT_QTY), dtype=torch.bool)
    market_op_masks = torch.zeros(
        (count, MAX_MARKET_ORDERS, len(MARKET_OPS)), dtype=torch.bool
    )
    market_item_masks = torch.zeros(
        (count, MAX_MARKET_ORDERS, len(ITEMS)), dtype=torch.bool
    )
    market_quantity_masks = torch.zeros(
        (count, MAX_MARKET_ORDERS, MAX_MARKET_QTY), dtype=torch.bool
    )
    num_tokens = torch.zeros(count, dtype=torch.int16)
    unit_counts = torch.zeros(count, dtype=torch.int16)
    scalar_float = [torch.zeros(count, dtype=torch.float32) for _ in range(5)]
    done = torch.zeros(count, dtype=torch.bool)
    scalar_int = [torch.zeros(count, dtype=torch.int32) for _ in range(4)]
    recurrent_width = max(
        (int(t.recurrent_hidden.numel()) for t in transitions if t.recurrent_hidden is not None),
        default=0,
    )
    recurrent_hidden = torch.zeros((count, recurrent_width), dtype=torch.float32)

    for index, transition in enumerate(transitions):
        encoded = transition.encoded
        tokens = encoded.num_tokens
        units = len(transition.action.unit_ops)
        num_tokens[index] = tokens
        unit_counts[index] = units
        continuous[index, :tokens].copy_(encoded.continuous)
        for target, source in zip(
            token_fields,
            (
                encoded.token_type,
                encoded.category_a,
                encoded.category_b,
                encoded.category_c,
                encoded.x,
                encoded.y,
                encoded.owner,
            ),
            strict=True,
        ):
            target[index, :tokens].copy_(source)
        unit_token_indices[index, :units] = torch.tensor(
            encoded.own_unit_token_indices, dtype=torch.long
        )
        for target, source in zip(
            unit_actions,
            (
                transition.action.unit_ops,
                transition.action.unit_items,
                transition.action.unit_quantities,
            ),
            strict=True,
        ):
            target[index, :units] = torch.tensor(source, dtype=torch.long)
        for target, source in zip(
            market_actions,
            (
                transition.action.market_ops,
                transition.action.market_items,
                transition.action.market_quantities,
            ),
            strict=True,
        ):
            target[index].copy_(torch.tensor(source, dtype=torch.long))
        unit_op_masks[index, :units].copy_(transition.masks.unit_ops)
        unit_item_masks[index, :units].copy_(transition.masks.unit_items)
        unit_quantity_masks[index, :units].copy_(transition.masks.unit_quantities)
        market_op_masks[index].copy_(transition.masks.market_ops)
        market_item_masks[index].copy_(transition.masks.market_items)
        market_quantity_masks[index].copy_(transition.masks.market_quantities)
        for target, value in zip(
            scalar_float,
            (
                transition.old_log_prob,
                transition.old_value,
                transition.reward,
                transition.advantage,
                transition.return_,
            ),
            strict=True,
        ):
            target[index] = float(value)
        done[index] = transition.done
        for target, value in zip(
            scalar_int,
            (
                transition.episode_id,
                transition.player_id,
                transition.timestep,
                transition.trajectory_id,
            ),
            strict=True,
        ):
            target[index] = int(value)
        if transition.recurrent_hidden is not None:
            recurrent_hidden[index].copy_(
                transition.recurrent_hidden.detach().to(dtype=torch.float32, device="cpu").reshape(-1)
            )

    return PackedTransitionBatch(
        num_tokens=num_tokens,
        continuous=continuous,
        token_type=token_fields[0], category_a=token_fields[1],
        category_b=token_fields[2], category_c=token_fields[3],
        x=token_fields[4], y=token_fields[5], owner=token_fields[6],
        unit_counts=unit_counts, unit_token_indices=unit_token_indices,
        unit_ops=unit_actions[0], unit_items=unit_actions[1],
        unit_quantities=unit_actions[2], market_ops=market_actions[0],
        market_items=market_actions[1], market_quantities=market_actions[2],
        unit_op_masks=unit_op_masks, unit_item_masks=unit_item_masks,
        unit_quantity_masks=unit_quantity_masks, market_op_masks=market_op_masks,
        market_item_masks=market_item_masks, market_quantity_masks=market_quantity_masks,
        old_log_prob=scalar_float[0], old_value=scalar_float[1], reward=scalar_float[2],
        done=done, episode_id=scalar_int[0], player_id=scalar_int[1],
        timestep=scalar_int[2], trajectory_id=scalar_int[3],
        recurrent_hidden=recurrent_hidden,
        advantage=scalar_float[3], return_=scalar_float[4],
    )


def unpack_transitions(batch: PackedTransitionBatch) -> list[Transition]:
    """Rebuild lightweight views over a packed actor batch."""
    transitions: list[Transition] = []
    for index in range(int(batch.num_tokens.shape[0])):
        tokens = int(batch.num_tokens[index])
        units = int(batch.unit_counts[index])
        encoded = EncodedObservation(
            continuous=batch.continuous[index, :tokens],
            token_type=batch.token_type[index, :tokens],
            category_a=batch.category_a[index, :tokens],
            category_b=batch.category_b[index, :tokens],
            category_c=batch.category_c[index, :tokens],
            x=batch.x[index, :tokens], y=batch.y[index, :tokens],
            owner=batch.owner[index, :tokens],
            own_unit_token_indices=tuple(
                int(v) for v in batch.unit_token_indices[index, :units].tolist()
            ),
        )
        transitions.append(
            Transition(
                encoded=encoded,
                action=ActionRecord(
                    unit_ops=tuple(int(v) for v in batch.unit_ops[index, :units].tolist()),
                    unit_items=tuple(int(v) for v in batch.unit_items[index, :units].tolist()),
                    unit_quantities=tuple(int(v) for v in batch.unit_quantities[index, :units].tolist()),
                    market_ops=tuple(int(v) for v in batch.market_ops[index].tolist()),
                    market_items=tuple(int(v) for v in batch.market_items[index].tolist()),
                    market_quantities=tuple(int(v) for v in batch.market_quantities[index].tolist()),
                ),
                masks=ActionMasks(
                    unit_ops=batch.unit_op_masks[index, :units],
                    unit_items=batch.unit_item_masks[index, :units],
                    unit_quantities=batch.unit_quantity_masks[index, :units],
                    market_ops=batch.market_op_masks[index],
                    market_items=batch.market_item_masks[index],
                    market_quantities=batch.market_quantity_masks[index],
                ),
                old_log_prob=float(batch.old_log_prob[index]),
                old_value=float(batch.old_value[index]), reward=float(batch.reward[index]),
                done=bool(batch.done[index]), episode_id=int(batch.episode_id[index]),
                player_id=int(batch.player_id[index]), timestep=int(batch.timestep[index]),
                trajectory_id=int(batch.trajectory_id[index]),
                recurrent_hidden=(
                    batch.recurrent_hidden[index]
                    if batch.recurrent_hidden.shape[1] > 0 else None
                ),
                advantage=float(batch.advantage[index]), return_=float(batch.return_[index]),
            )
        )
    return transitions
