import os
import sys
from pathlib import Path
os.environ.setdefault('TORCH_DEVICE_BACKEND_AUTOLOAD', '0')
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ.setdefault(name, '1')
root = Path(__file__).resolve().parent if '__file__' in globals() else Path(sys.path[-1])
os.environ['STUDENT_R1_BINARY'] = str(root / 'policy/r1/agent.so')
os.environ['STUDENT_CHECKPOINT'] = str(root / 'models/student-v306/v3-ppo-native-job-economic-v1-v306-1536g.pt')
os.environ['STUDENT_V3_MANIFEST'] = str(root / 'models/student-v306/manifest.json')
import torch
torch.set_num_threads(1)
from experiments.student_action_event_agent import agent
